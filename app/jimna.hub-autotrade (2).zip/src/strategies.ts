import { TickData, MarketAnalysis, StrategyType } from './types';

export const getSymbolPrecision = (symbol: string): number => {
  if (!symbol) return 2;
  const s = symbol.toLowerCase();
  if (s.startsWith('frx')) return 5;
  if (s === 'r_10' || s === 'r_25' || s === 'r_50' || s === 'r_75' || s === 'r_100') return 2;
  if (s.startsWith('1hz') || s.includes('1s')) return 3;
  return 2;
};

export const calculateSMA = (data: number[], period: number) => {
  if (data.length < period) return data.length > 0 ? data[data.length - 1] : 0;
  const slice = data.slice(-period);
  return slice.reduce((a, b) => a + b, 0) / period;
};

export const calculateRSI = (data: number[], period: number = 14) => {
  if (data.length <= period) return 50;
  let gains = 0, losses = 0;
  for (let i = data.length - period; i < data.length; i++) {
    const diff = data[i] - data[i - 1];
    if (diff > 0) gains += diff;
    else losses -= diff;
  }
  const avgGain = gains / period;
  const avgLoss = Math.abs(losses) / period;
  if (avgLoss === 0) return 100;
  if (avgGain === 0) return 0;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
};

export const calculateMACDSeries = (data: number[]) => {
  if (data.length < 26) return { main: 0, signal: 0, hist: 0 };
  const emaCalc = (vals: number[], p: number) => {
    let emaArr = [vals[0]];
    const k = 2 / (p + 1);
    for (let i = 1; i < vals.length; i++) {
      emaArr.push(vals[i] * k + emaArr[i - 1] * (1 - k));
    }
    return emaArr;
  };
  const ema12 = emaCalc(data, 12);
  const ema26 = emaCalc(data, 26);
  const macdLine = data.map((_, i) => ema12[i] - ema26[i]);
  const signalLine = emaCalc(macdLine, 9);
  const curMacd = macdLine[macdLine.length - 1];
  const curSignal = signalLine[signalLine.length - 1];
  return { main: curMacd, signal: curSignal, hist: curMacd - curSignal };
};

export const calculateStandardDeviation = (data: number[], period: number) => {
  if (data.length < period) return 0;
  const slice = data.slice(-period);
  const mean = slice.reduce((a, b) => a + b, 0) / period;
  const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / period;
  return Math.sqrt(variance);
};

export const calculateBollingerBands = (data: number[], period: number = 20, stdDevMult: number = 2) => {
  if (data.length < period) return { middle: 0, upper: 0, lower: 0 };
  const smaValue = calculateSMA(data, period);
  const stdDev = calculateStandardDeviation(data, period);
  return {
    middle: smaValue,
    upper: smaValue + (stdDevMult * stdDev),
    lower: smaValue - (stdDevMult * stdDev)
  };
};

export const calculateStochastic = (data: number[], period: number = 14) => {
  if (data.length < period) return { k: 50, d: 50 };
  const slice = data.slice(-period);
  const low = Math.min(...slice);
  const high = Math.max(...slice);
  const current = data[data.length - 1];
  if (high === low) return { k: 50, d: 50 };
  const k = ((current - low) / (high - low)) * 100;
  return { k, d: k };
};

export const performMarketAnalysis = (ticks: TickData[], strategy: string, symbol?: string): MarketAnalysis | null => {
  if (!ticks || ticks.length === 0) return null;
  const digits = ticks.map(t => t.lastDigit);
  const quotes = ticks.map(t => t.quote);
  if (ticks.length < 5) return null;

  const evens = digits.filter(d => d % 2 === 0).length;
  const odds = digits.length - evens;
  let parityChanges = 0;
  for (let i = 1; i < digits.length; i++) {
    if ((digits[i] % 2 === 0) !== (digits[i-1] % 2 === 0)) parityChanges++;
  }
  const entropy = Math.max(5, Math.min(100, Math.round((parityChanges / digits.length) * 100)));
  const volatility = Math.max(8, Math.min(100, Math.round(entropy * 1.2)));
  const parityDominance = Math.abs(evens - odds) / digits.length;
  const strength = Math.min(100, Math.round((100 - entropy) * 0.7 + (parityDominance * 100) * 1.5));
  
  const rsi = calculateRSI(quotes, 14);
  const sma = calculateSMA(quotes, 20);
  const macd = calculateMACDSeries(quotes);
  const bb = calculateBollingerBands(quotes, 20);
  const stoch = calculateStochastic(quotes, 14);

  const recentChanges = quotes.slice(-10).map((q, i, arr) => i > 0 ? q - arr[i-1] : 0).slice(1);
  const avgChange = recentChanges.length > 0 ? recentChanges.reduce((a, b) => a + b, 0) / recentChanges.length : 0;
  const velocity = avgChange;
  const acceleration = recentChanges.length >= 6 ? (recentChanges.slice(-3).reduce((a, b) => a + b, 0) / 3 - recentChanges.slice(0, 3).reduce((a, b) => a + b, 0) / 3) : 0;
  
  const lastQuote = quotes[quotes.length - 1];
  const isForex = symbol && symbol.startsWith('frx');
  let scale = 1;
  if (isForex) scale = lastQuote > 50 ? 100 : 10000;
  const scaledVelocity = velocity * scale;
  const scaledAcceleration = acceleration * scale;
  const scaledMacdHist = macd.hist * scale;

  let trend: 'UP' | 'DOWN' | 'NEUTRAL' = 'NEUTRAL';
  if (scaledVelocity > 0.002) trend = 'UP';
  else if (scaledVelocity < -0.002) trend = 'DOWN';

  const isDirectionalMatch = (trend === 'UP' && scaledMacdHist > 0) || (trend === 'DOWN' && scaledMacdHist < 0);
  const volStability = 1 - (volatility / 100);
  const confidence = Math.min(95, Math.max(10, Math.round((volStability * 60) + (isDirectionalMatch ? 30 : 0) + (Math.abs(scaledAcceleration) * 1000))));
  const projection = lastQuote + (velocity * 2) + (acceleration * 2);

  const stressVelocity = Math.abs(quotes[quotes.length - 1] - quotes[Math.max(0, quotes.length - 15)]) / (quotes[Math.max(0, quotes.length - 15)] || 1) * 100;
  const stressBase = (volatility * 0.35) + (stressVelocity * 5) + (entropy * 0.15);
  const stress = Math.min(100, Math.max(0, Math.round(stressBase)));

  const trendScore = Math.min(100, Math.max(0, (isDirectionalMatch ? 40 : 0) + (Math.abs(scaledMacdHist) * 500) + (confidence * 0.3)));
  const meanReversionScore = Math.min(100, Math.max(0, ((rsi > 70 || rsi < 30) ? 40 : 0) + ((stoch.k > 80 || stoch.k < 20) ? 30 : 0) + (Math.abs(lastQuote - bb.middle) / (bb.upper - bb.lower || 0.0001) * 30)));
  const momentumScore = Math.min(100, Math.max(0, (Math.abs(scaledVelocity) * 2000) + (Math.abs(scaledAcceleration) * 5000) + (volatility * 0.2)));
  const parityScore = Math.min(100, Math.max(0, 50 + (parityDominance * 100 * 2.5)));

  let aiConfidence = 0;
  if (strategy.includes('E/O') || strategy.includes('Bias') || strategy.includes('Python') || strategy === 'Even' || strategy === 'Odd' || strategy === 'Alternate' || strategy === 'Flow Market') {
    aiConfidence = Math.min(100, Math.max(0, parityScore * 0.8 + (confidence * 0.2)));
  } else if (strategy.includes('Smart O/U')) {
    aiConfidence = Math.min(100, meanReversionScore * 0.7 + (confidence * 0.3));
  } else if (strategy.includes('Rise/Fall') || strategy.includes('Momentum') || strategy.includes('Flow')) {
    aiConfidence = Math.min(100, (trendScore * 0.6) + (momentumScore * 0.4));
  } else {
    aiConfidence = Math.min(100, Math.max(0, (1 - (volatility / 100)) * 30 + (confidence * 0.5)));
  }

  if (stress > 80) aiConfidence *= (1 - ((stress - 80) / 100));

  let bestBot = 'Python Ultimate E/O';
  if (volatility > 82) bestBot = 'Python Safe E/O';
  else if (strength < 32) bestBot = 'Sniper Switch';
  else if (strength > 78) bestBot = 'Python Ultimate E/O';
  else if (Math.abs(evens - odds) > 5) bestBot = 'Python Bias O/U';
  else bestBot = 'Python Fast E/O';

  return { 
    volatility, strength, bestBot, rsi, sma, macd, bb, stoch,
    forecast: { trend, confidence, projection: projection },
    aiConfidence, stress,
    strategies: {
      trend: Math.round(trendScore),
      meanReversion: Math.round(meanReversionScore),
      momentum: Math.round(momentumScore),
      parity: Math.round(parityScore)
    }
  };
};

export const getStrategySignal = (
  strategy: StrategyType,
  tick: TickData,
  analysis: MarketAnalysis,
  history: TickData[],
  config: {
    targetDigit: number;
    pythonTradeType: string;
    pythonUltimateEvenOnly: boolean;
    evenMomentum: number;
    effectiveConfidenceFilter: number;
    symbol: string;
  }
): { contractType: string; barrier?: string } | null => {
  const { aiConfidence, stress, rsi, forecast } = analysis;
  const { lastDigit } = tick;
  const { effectiveConfidenceFilter, symbol } = config;
  const isForex = symbol.startsWith('frx');

  let contractType = '';
  let barrier: string | undefined = undefined;

  if (isForex) {
    if (strategy === 'Forex Scalper Pro') {
        const macdValue = analysis.macd.hist;
        const trendDirection = forecast.trend;
        const oversoldRecov = rsi < 35 && macdValue > 0;
        const overboughtRecov = rsi > 65 && macdValue < 0;
        if (oversoldRecov) contractType = 'CALL';
        else if (overboughtRecov) contractType = 'PUT';
        else if (aiConfidence >= (effectiveConfidenceFilter + 5) && trendDirection !== 'NEUTRAL') {
            contractType = trendDirection === 'UP' ? 'CALL' : 'PUT';
        }
    } else {
        const trendStrength = analysis.strategies.trend;
        const momentumStrength = analysis.strategies.momentum;
        const direction = forecast.trend;
        if (trendStrength > 70 && direction !== 'NEUTRAL') contractType = direction === 'UP' ? 'CALL' : 'PUT';
        else if (momentumStrength > 75 && direction !== 'NEUTRAL') {
             if (direction === 'UP' && rsi < 65) contractType = 'CALL';
             else if (direction === 'DOWN' && rsi > 35) contractType = 'PUT';
        }
        if (!contractType && aiConfidence >= (effectiveConfidenceFilter + 10) && direction !== 'NEUTRAL') {
            contractType = direction === 'UP' ? 'CALL' : 'PUT';
        }
    }
  } else {
    // Synthetic Digit Logic
    if (strategy === 'Even') {
        const evenBias = (analysis.strategies.parity > 55);
        if (aiConfidence >= (effectiveConfidenceFilter - 5) || evenBias) contractType = 'DIGITEVEN';
    }
    else if (strategy === 'Odd') {
        const oddBias = (analysis.strategies.parity < 45);
        if (aiConfidence >= (effectiveConfidenceFilter - 5) || oddBias) contractType = 'DIGITODD';
    }
    else if (strategy === 'Even/Odd') {
        const trendDirection = forecast.trend;
        const predictedDigit = trendDirection === 'UP' ? Math.min(9, lastDigit + 1) : 
                               trendDirection === 'DOWN' ? Math.max(0, lastDigit - 1) : lastDigit;
        const isEven = predictedDigit % 2 === 0;
        if (aiConfidence >= (effectiveConfidenceFilter - 5) || trendDirection !== 'NEUTRAL') {
            contractType = isEven ? 'DIGITEVEN' : 'DIGITODD';
        }
    }
    else if (strategy === 'Python Logic') {
        const isTargetDigitEven = lastDigit % 2 === 0;
        if (aiConfidence >= (effectiveConfidenceFilter - 5) || (isTargetDigitEven && analysis.strategies.trend > 55)) {
            contractType = config.pythonTradeType || 'DIGITOVER';
            barrier = config.targetDigit.toString();
        }
    }
    else if (strategy === 'Alternate') {
        const isExplosiveEntropy = analysis.volatility > 55;
        if (aiConfidence >= (effectiveConfidenceFilter - 5) || isExplosiveEntropy) {
            contractType = lastDigit % 2 === 0 ? 'DIGITODD' : 'DIGITEVEN';
        }
    }
    else if (strategy === 'Flow Market') {
        const isClustering = analysis.volatility < 45;
        if (aiConfidence >= (effectiveConfidenceFilter - 5) || isClustering) {
            contractType = lastDigit % 2 === 0 ? 'DIGITEVEN' : 'DIGITODD';
        }
    }
    else if (strategy === 'Python Fast E/O') {
        if (aiConfidence >= (effectiveConfidenceFilter - 15)) {
            contractType = lastDigit % 2 === 0 ? 'DIGITEVEN' : 'DIGITODD';
        }
    }
    else if (strategy === 'Python Safe E/O') {
        if (history.length < 3) return null;
        const r3 = history.slice(-3).map((t: any) => t.lastDigit % 2 === 0);
        if (r3.every(v => v === true)) contractType = 'DIGITEVEN';
        else if (r3.every(v => v === false)) contractType = 'DIGITODD';
    }
    else if (strategy === 'Python Ultimate E/O') {
        const isEven = lastDigit % 2 === 0;
        const isOdd = !isEven;
        if (history.length < 25) return null;
        const recent25 = history.slice(-25).map((t: any) => t.lastDigit % 2 === 0);
        const evenCount = recent25.filter(e => e).length;
        const parityBias = evenCount / 25;
        let switches = 0;
        for (let i = 1; i < recent25.length; i++) if (recent25[i] !== recent25[i-1]) switches++;
        const patternEntropy = switches / recent25.length;
        const recent3 = history.slice(-3).map((t: any) => t.lastDigit % 2 === 0);
        const isConsistent3 = recent3.every(v => v === recent3[0]);
        if (patternEntropy > 0.75) contractType = isEven ? 'DIGITODD' : 'DIGITEVEN';
        else if (patternEntropy < 0.28) contractType = isEven ? 'DIGITEVEN' : 'DIGITODD';
        else {
            if (isEven && (config.evenMomentum > 0.02 || (parityBias > 0.54 && isConsistent3))) contractType = 'DIGITEVEN';
            else if (isOdd && (config.evenMomentum < -0.02 || (parityBias < 0.46 && isConsistent3 && !config.pythonUltimateEvenOnly))) contractType = 'DIGITODD';
        }
        if (!contractType && aiConfidence >= (effectiveConfidenceFilter - 10)) contractType = isEven ? 'DIGITEVEN' : 'DIGITODD';
    }
    else if (strategy === 'Smart O/U') {
        const overbought = (rsi > 65 || analysis.stoch.k > 80);
        const oversold = (rsi < 35 || analysis.stoch.k < 20);
        if (overbought) contractType = 'DIGITUNDER';
        else if (oversold) contractType = 'DIGITOVER';
        else if (aiConfidence >= (effectiveConfidenceFilter - 5)) contractType = rsi > 50 ? 'DIGITOVER' : 'DIGITUNDER';
        barrier = config.targetDigit.toString();
    }
    else if (strategy === 'Sniper Switch') {
        if (history.length < 4) return null;
        const r4 = history.slice(-4).map((t: any) => t.lastDigit % 2 === 0);
        if (r4[0] === r4[1] && r4[1] === r4[2] && r4[3] !== r4[2]) contractType = r4[3] ? 'DIGITEVEN' : 'DIGITODD';
    }
    else if (strategy === 'Python Bias O/U') {
        const recent10 = history.slice(-10).map((t: any) => t.lastDigit);
        const avgDigit = recent10.reduce((a, b) => a + b, 0) / 10;
        if (avgDigit > 5.5) contractType = 'DIGITOVER';
        else if (avgDigit < 3.5) contractType = 'DIGITUNDER';
        barrier = "4";
    }
    else if (strategy === 'Momentum Rise/Fall') {
        const trendDir = forecast.trend;
        const momentum = analysis.strategies.momentum;
        if (momentum > 70 && trendDir !== 'NEUTRAL') contractType = trendDir === 'UP' ? 'CALL' : 'PUT';
    }
    else if (strategy === 'Reversal Rise/Fall') {
        const meanReversion = analysis.strategies.meanReversion;
        const trendDir = forecast.trend;
        if (meanReversion > 75) {
            if (trendDir === 'UP') contractType = 'PUT';
            else if (trendDir === 'DOWN') contractType = 'CALL';
        }
    }
    else if (strategy === 'Digit Diff') {
        if (aiConfidence >= (effectiveConfidenceFilter - 10)) {
            contractType = 'DIGITDIFF';
            barrier = config.targetDigit.toString();
        }
    }
    else if (strategy === 'Digit Match') {
        if (aiConfidence >= (effectiveConfidenceFilter + 10)) {
            contractType = 'DIGITMATCH';
            barrier = config.targetDigit.toString();
        }
    }
  }

  return contractType ? { contractType, barrier } : null;
};
