export type LogSeverity = 'info' | 'success' | 'warning' | 'error' | 'trade-loss' | 'critical';

export interface LogEntry {
  id: string;
  message: string;
  severity: LogSeverity;
  advice?: string;
  timestamp: string;
}

export type TradeLog = {
  id: string;
  type: string;
  buyPrice: number;
  profit: number;
  status: 'WON' | 'LOST' | 'PENDING';
  time: string;
  symbol?: string;
  lastDigit?: number;
};

export type TickData = {
  time: string;
  quote: number;
  lastDigit: number;
  epoch: number;
};

export interface MarketAnalysis {
  volatility: number;
  strength: number;
  bestBot: string;
  rsi: number;
  sma: number;
  macd: { main: number; signal: number; hist: number };
  bb: { upper: number; middle: number; lower: number };
  stoch: { k: number; d: number };
  forecast: { trend: 'UP' | 'DOWN' | 'NEUTRAL'; confidence: number; projection: number };
  aiConfidence: number;
  stress: number;
  strategies: {
    trend: number;
    meanReversion: number;
    momentum: number;
    parity: number;
  };
}

export type StrategyType = 
  | 'Even' 
  | 'Odd' 
  | 'Even/Odd' 
  | 'Python Logic' 
  | 'Alternate' 
  | 'Flow Market' 
  | 'Python Fast E/O' 
  | 'Python Safe E/O' 
  | 'Python Ultimate E/O' 
  | 'Smart O/U' 
  | 'Sniper Switch' 
  | 'Python Bias O/U' 
  | 'Momentum Rise/Fall' 
  | 'Reversal Rise/Fall'
  | 'Forex Scalper Pro'
  | 'Digit Diff'
  | 'Digit Match';
