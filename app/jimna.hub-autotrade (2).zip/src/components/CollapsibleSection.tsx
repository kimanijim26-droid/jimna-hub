import React, { useState } from 'react';
import { ChevronUp, ChevronDown } from 'lucide-react';

export function CollapsibleSection({ title, icon: Icon, children, defaultOpen = false }: { title: string, icon: any, children: React.ReactNode, defaultOpen?: boolean }) {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-[rgba(0,255,65,0.05)] last:border-0 overflow-hidden">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full flex items-center justify-between p-4 hover:bg-white/[0.02] transition-all duration-300 ${isOpen ? 'bg-white/[0.01]' : ''}`}
      >
        <div className="flex items-center gap-3">
          <div className={`p-1.5 rounded-[4px] transition-colors ${isOpen ? 'bg-[#00ff41]/10 text-[#00ff41]' : 'bg-white/5 text-text-dim'}`}>
            <Icon className="w-3.5 h-3.5" />
          </div>
          <span className={`text-[10px] font-bold uppercase tracking-[2.5px] ${isOpen ? 'text-text-main' : 'text-text-dim'}`}>{title}</span>
        </div>
        {isOpen ? <ChevronUp className="w-4 h-4 text-[#00ff41]/50" /> : <ChevronDown className="w-4 h-4 text-text-dim" />}
      </button>
      <div className={`transition-all duration-500 ease-in-out ${isOpen ? 'max-h-[1200px] opacity-100 p-4 pt-2' : 'max-h-0 opacity-0 p-0'}`}>
        <div className="space-y-6">
          {children}
        </div>
      </div>
    </div>
  );
}
