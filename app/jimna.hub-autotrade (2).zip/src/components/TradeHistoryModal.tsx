import React from 'react';
import { 
  X, 
  History, 
  Download, 
  Search,
  Filter,
  TrendingDown,
  TrendingUp,
  Clock,
  LayoutList,
  ChevronRight,
  ChevronLeft
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface TradeLog {
  id: string;
  type: string;
  buyPrice: number;
  profit: number;
  status: 'WON' | 'LOST' | 'PENDING';
  time: string;
  symbol?: string;
  lastDigit?: number;
}

interface TradeHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  trades: TradeLog[];
  currency: string;
}

export const TradeHistoryModal: React.FC<TradeHistoryModalProps> = ({ 
  isOpen, 
  onClose, 
  trades,
  currency 
}) => {
  const [searchTerm, setSearchTerm] = React.useState('');
  const [filterStatus, setFilterStatus] = React.useState<'ALL' | 'WON' | 'LOST'>('ALL');
  const [currentPage, setCurrentPage] = React.useState(1);
  const itemsPerPage = 10;

  if (!isOpen) return null;

  const filteredTrades = trades.filter(t => {
    const matchesSearch = t.symbol?.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          t.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'ALL' || t.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const sortedTrades = [...filteredTrades].sort((a, b) => 
    new Date(b.time).getTime() - new Date(a.time).getTime()
  );

  const totalPages = Math.ceil(sortedTrades.length / itemsPerPage);
  const paginatedTrades = sortedTrades.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const exportToCSV = () => {
    const headers = ['ID', 'Timestamp', 'Asset', 'Direction', 'Entry Price', 'Profit', 'Status'];
    const data = trades.map(t => [
      t.id,
      t.time,
      t.symbol || 'N/A',
      t.type,
      t.buyPrice.toFixed(2),
      t.profit.toFixed(2),
      t.status
    ]);
    
    const csvContent = [headers, ...data].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `trade_history_${new Date().toISOString()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-[#141417] border border-white/10 shadow-2xl rounded-lg w-full max-w-5xl h-full max-h-[85vh] flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/5 bg-black/20">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-accent/10 rounded-lg">
              <History className="w-5 h-5 text-accent" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white tracking-tight">Trade History Ledger</h3>
              <p className="text-[10px] text-text-dim uppercase tracking-[2px] font-medium">Verified Execution Archives</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={exportToCSV}
              className="flex items-center gap-2 px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded text-[11px] font-bold text-text-main uppercase tracking-wider transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </button>
            <button 
              onClick={onClose}
              className="p-2 text-text-dim hover:text-white transition-colors rounded-full hover:bg-white/5"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="px-6 py-4 flex flex-col sm:flex-row items-center gap-4 border-b border-white/5">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-dim" />
            <input 
              type="text"
              placeholder="Search by Symbol or ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded pl-10 pr-4 py-2 text-xs text-white focus:border-accent/50 outline-none"
            />
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="flex items-center gap-1.5 p-1 bg-black/40 border border-white/10 rounded">
              {(['ALL', 'WON', 'LOST'] as const).map(status => (
                <button
                  key={status}
                  onClick={() => setFilterStatus(status)}
                  className={`px-3 py-1 rounded text-[10px] font-bold tracking-widest transition-all ${
                    filterStatus === status 
                      ? 'bg-accent text-bg' 
                      : 'text-text-dim hover:text-white'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Table Content */}
        <div className="flex-1 overflow-x-auto custom-scrollbar">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead className="sticky top-0 bg-[#141417] z-10">
              <tr className="border-b border-white/5">
                <th className="px-6 py-4 text-[10px] uppercase font-bold text-text-dim tracking-widest">Timestamp</th>
                <th className="px-6 py-4 text-[10px] uppercase font-bold text-text-dim tracking-widest">ID / Asset</th>
                <th className="px-6 py-4 text-[10px] uppercase font-bold text-text-dim tracking-widest">Type</th>
                <th className="px-6 py-4 text-[10px] uppercase font-bold text-text-dim tracking-widest">Entry Price</th>
                <th className="px-6 py-4 text-[10px] uppercase font-bold text-text-dim tracking-widest">Profit/Loss</th>
                <th className="px-6 py-4 text-[10px] uppercase font-bold text-text-dim tracking-widest text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.02]">
              {paginatedTrades.length > 0 ? (
                paginatedTrades.map((trade) => (
                  <tr key={trade.id} className="group hover:bg-white/[0.02] transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex flex-col">
                        <span className="text-[11px] font-mono text-white">
                          {new Date(trade.time).toLocaleTimeString()}
                        </span>
                        <span className="text-[9px] text-text-dim">
                          {new Date(trade.time).toLocaleDateString()}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col">
                        <span className="text-[11px] font-bold text-accent uppercase tracking-tighter">
                          {trade.symbol || 'SYNTHETIC'}
                        </span>
                        <span className="text-[9px] font-mono text-text-dim">
                          #{trade.id.slice(0, 10)}...
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-white/5 border border-white/10 text-text-main">
                        {trade.type}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-[11px] font-mono text-white">
                        {currency} {trade.buyPrice.toFixed(2)}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className={`flex items-center gap-1.5 font-mono text-[11px] font-bold ${trade.profit >= 0 ? 'text-profit' : 'text-loss'}`}>
                        {trade.profit >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                        {trade.profit >= 0 ? '+' : ''}{currency} {trade.profit.toFixed(2)}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className={`text-[9px] font-bold uppercase tracking-[2px] px-2 py-1 rounded-sm ${
                        trade.status === 'WON' 
                          ? 'bg-profit/10 text-profit border border-profit/20' 
                          : trade.status === 'LOST'
                          ? 'bg-loss/10 text-loss border border-loss/20'
                          : 'bg-white/5 text-text-dim border border-white/10'
                      }`}>
                        {trade.status}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="py-20 text-center">
                    <div className="flex flex-col items-center gap-4 opacity-30">
                      <LayoutList className="w-12 h-12" />
                      <div>
                        <p className="text-sm font-bold text-white">No Execution Records Found</p>
                        <p className="text-[10px] uppercase tracking-widest text-text-dim">History is empty or filtered out</p>
                      </div>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Footer / Pagination */}
        <div className="px-6 py-4 border-t border-white/5 bg-black/40 flex items-center justify-between">
          <div className="text-[10px] text-text-dim uppercase tracking-widest font-bold">
            Showing {Math.min(paginatedTrades.length, itemsPerPage)} of {filteredTrades.length} Records
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <button 
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-1.5 bg-white/5 rounded hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
              >
                <ChevronLeft className="w-4 h-4 text-white" />
              </button>
              <div className="px-4 text-[11px] font-mono text-white">
                Page {currentPage} of {totalPages || 1}
              </div>
              <button 
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages || totalPages === 0}
                className="p-1.5 bg-white/5 rounded hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
              >
                <ChevronRight className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
