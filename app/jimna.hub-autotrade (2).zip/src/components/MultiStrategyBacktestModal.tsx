import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, 
  Play, 
  BarChart3, 
  Target, 
  TrendingUp, 
  Zap, 
  AlertTriangle,
  Info,
  CheckCircle2,
  Settings2,
  ChevronRight
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';

interface MultiStrategyBacktestModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialStake: number;
  martingaleMultiplier: number;
  symbol: string;
}

type Strategy = 
  | 'Even' 
  | 'Odd' 
  | 'Even/Odd' 
  | 'Alternate' 
  | 'Smart O/U' 
  | 'Flow Market' 
  | 'Python Logic' 
  | 'Python Bias O/U' 
  | 'Sniper Switch' 
  | 'Python Fast E/O' 
  | 'Python Safe E/O' 
  | 'Python Ultimate E/O' 
  | 'Momentum Rise/Fall' 
  | 'Reversal Rise/Fall';

const STRATEGIES: Strategy[] = [
  'Python Ultimate E/O',
  'Python Safe E/O',
  'Python Fast E/O',
  'Flow Market',
  'Even/Odd',
  'Smart O/U',
  'Sniper Switch',
  'Momentum Rise/Fall',
  'Reversal Rise/Fall'
];

const STRATEGY_COLORS: Record<string, string> = {
  'Python Ultimate E/O': '#00ff88',
  'Python Safe E/O': '#4dffb8',
  'Python Fast E/O': '#80ffcc',
  'Flow Market': '#00f2fe',
  'Even/Odd': '#ff00ff',
  'Smart O/U': '#f8ff00',
  'Sniper Switch': '#ff5e3a',
  'Momentum Rise/Fall': '#0070ff',
  'Reversal Rise/Fall': '#ff9f0a'
};

export const MultiStrategyBacktestModal: React.FC<MultiStrategyBacktestModalProps> = ({ 
  isOpen, 
  onClose, 
  initialStake, 
  martingaleMultiplier,
  symbol
}) => {
  const [isRunning, setIsRunning] = useState(false);
  const [results, setResults] = useState<any[]>([]);
  const [chartData, setChartData] = useState<any[]>([]);
  const [selectedStrategies, setSelectedStrategies] = useState<Strategy[]>([...STRATEGIES]);
  const [tickCount, setTickCount] = useState(1000);

  if (!isOpen) return null;

  const runComparison = async () => {
    setIsRunning(true);
    setResults([]);
    setChartData([]);

    // Generate mock ticks (same for all strategies)
    const ticksData = Array.from({ length: tickCount }, () => 1000 + Math.random() * 10);
    const precision = 2; // Default for mock

    const allResults: any[] = [];
    const trends: Record<string, number[]> = {};

    selectedStrategies.forEach(strategy => {
      let simStake = initialStake;
      let simWins = 0;
      let simLosses = 0;
      let simProfit = 0;
      const profitTrend = [0];
      
      let ultState: any = 'neutral';

      for (let i = 25; i < ticksData.length; i++) {
        const lastDigit = parseInt(ticksData[i].toFixed(precision).slice(-1), 10);
        let contractType: string | null = null;
        let barrier: number | undefined = undefined;

        // Simplified Strategy Logic (from App.tsx)
        if (strategy === 'Even') contractType = 'DIGITEVEN';
        else if (strategy === 'Odd') contractType = 'DIGITODD';
        else if (strategy === 'Even/Odd') {
            const delta = ticksData[i] - ticksData[i-3];
            const predictedDigit = delta > 0 ? Math.min(9, lastDigit + 1) : Math.max(0, lastDigit - 1);
            contractType = predictedDigit % 2 === 0 ? 'DIGITEVEN' : 'DIGITODD';
        }
        else if (strategy === 'Alternate') contractType = lastDigit % 2 === 0 ? 'DIGITODD' : 'DIGITEVEN';
        else if (strategy === 'Flow Market' || strategy === 'Python Fast E/O') contractType = lastDigit % 2 === 0 ? 'DIGITEVEN' : 'DIGITODD';
        else if (strategy === 'Python Safe E/O') {
            const prevState = ticksData[i-1].toFixed(precision).slice(-1);
            if (parseInt(prevState) % 2 === lastDigit % 2) {
              contractType = lastDigit % 2 === 0 ? 'DIGITEVEN' : 'DIGITODD';
            }
        }
        else if (strategy === 'Python Ultimate E/O') {
            const isEven = lastDigit % 2 === 0;
            const recent25 = ticksData.slice(i - 25, i).map(t => parseInt(t.toFixed(precision).slice(-1), 10));
            const parityBias = recent25.filter(d => d % 2 === 0).length / 25;

            if (ultState === 'neutral') {
                if (isEven && parityBias > 0.4) ultState = 'waiting_even';
                else if (!isEven && parityBias < 0.6) ultState = 'waiting_odd';
                continue;
            }
            if (ultState === 'waiting_even') {
                if (isEven) contractType = 'DIGITEVEN';
                ultState = 'neutral';
            } else if (ultState === 'waiting_odd') {
                if (!isEven) contractType = 'DIGITODD';
                ultState = 'neutral';
            }
        }
        else if (strategy === 'Smart O/U') {
           contractType = (ticksData[i] > ticksData[i-4]) ? 'DIGITOVER' : 'DIGITUNDER';
           barrier = 4;
        }
        else if (strategy === 'Sniper Switch') {
           if ((ticksData[i] % 2 === 0) !== (ticksData[i-1] % 2 === 0)) {
               contractType = (lastDigit % 2 === 0) ? 'DIGITEVEN' : 'DIGITODD';
           }
        }
        else if (strategy === 'Momentum Rise/Fall') {
           if (ticksData[i] > ticksData[i-1] && ticksData[i-1] > ticksData[i-2]) contractType = 'CALL';
           else if (ticksData[i] < ticksData[i-1] && ticksData[i-1] < ticksData[i-2]) contractType = 'PUT';
        }
        else if (strategy === 'Reversal Rise/Fall') {
           if (ticksData[i] < ticksData[i-1] && ticksData[i-1] < ticksData[i-2]) contractType = 'CALL';
           else if (ticksData[i] > ticksData[i-1] && ticksData[i-1] > ticksData[i-2]) contractType = 'PUT';
        }

        if (contractType) {
          const execIdx = i + 1;
          if (execIdx < ticksData.length) {
            const execDigit = parseInt(ticksData[execIdx].toFixed(precision).slice(-1), 10);
            let isWin = false;
            
            if (contractType === 'DIGITEVEN') isWin = execDigit % 2 === 0;
            else if (contractType === 'DIGITODD') isWin = execDigit % 2 !== 0;
            else if (contractType === 'DIGITOVER') isWin = execDigit > (barrier || 4);
            else if (contractType === 'DIGITUNDER') isWin = execDigit < (barrier || 4);
            else if (contractType === 'CALL') isWin = ticksData[execIdx] > ticksData[i];
            else if (contractType === 'PUT') isWin = ticksData[execIdx] < ticksData[i];

            const payout = 0.95;
            const pnl = isWin ? simStake * payout : -simStake;
            simProfit += pnl;
            
            if (isWin) {
              simWins++;
              simStake = initialStake;
            } else {
              simLosses++;
              simStake *= martingaleMultiplier;
            }
            profitTrend.push(Number(simProfit.toFixed(2)));
          }
        }
      }

      allResults.push({
        strategy,
        wins: simWins,
        losses: simLosses,
        profit: simProfit,
        winRate: (simWins / (simWins + simLosses || 1)) * 100,
        trades: simWins + simLosses
      });
      trends[strategy] = profitTrend;
    });

    // Prepare chart data - finding the maximum number of trades across all strategies
    const maxTrades = Math.max(...Object.values(trends).map(t => t.length));
    const combinedChartData = Array.from({ length: maxTrades }, (_, i) => {
      const dataPoint: any = { trade: i };
      selectedStrategies.forEach(s => {
        dataPoint[s] = trends[s][i] !== undefined ? trends[s][i] : trends[s][trends[s].length - 1];
      });
      return dataPoint;
    });

    setChartData(combinedChartData);
    setResults(allResults.sort((a, b) => b.profit - a.profit));
    setIsRunning(false);
  };

  const toggleStrategy = (s: Strategy) => {
    setSelectedStrategies(prev => 
      prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]
    );
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 lg:p-8">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-[#141417] border border-white/10 shadow-2xl rounded-lg w-full max-w-6xl h-full max-h-[90vh] flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/5 bg-black/20">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-accent/10 rounded-lg">
              <BarChart3 className="w-5 h-5 text-accent" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white tracking-tight">Strategy Efficiency Visualizer</h3>
              <p className="text-[10px] text-text-dim uppercase tracking-[2px] font-medium">Comparative Performance Analytics</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 text-text-dim hover:text-white transition-colors rounded-full hover:bg-white/5"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-hidden flex flex-col lg:flex-row">
          {/* Sidebar / Controls */}
          <div className="w-full lg:w-80 border-b lg:border-b-0 lg:border-r border-white/5 p-6 space-y-6 flex flex-col overflow-y-auto custom-scrollbar">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Settings2 className="w-4 h-4 text-accent/60" />
                <h4 className="text-[11px] uppercase tracking-widest text-text-dim font-bold">Simulator Params</h4>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] text-text-dim uppercase mb-1.5 block">Tick Samples</label>
                  <select 
                    value={tickCount}
                    onChange={(e) => setTickCount(Number(e.target.value))}
                    className="w-full bg-black/40 border border-white/10 rounded p-2 text-xs text-white focus:border-accent/50 outline-none"
                  >
                    <option value={500}>500 Ticks</option>
                    <option value={1000}>1,000 Ticks</option>
                    <option value={1500}>1,500 Ticks</option>
                    <option value={2000}>2,000 Ticks</option>
                    <option value={5000}>5,000 Ticks (Slow)</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-white/5 p-2 rounded border border-white/5">
                    <div className="text-[9px] text-text-dim uppercase mb-0.5">Base Stake</div>
                    <div className="text-xs font-mono text-white">${initialStake}</div>
                  </div>
                  <div className="bg-white/5 p-2 rounded border border-white/5">
                    <div className="text-[9px] text-text-dim uppercase mb-0.5">Multiplier</div>
                    <div className="text-xs font-mono text-white">x{martingaleMultiplier}</div>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-accent/60" />
                  <h4 className="text-[11px] uppercase tracking-widest text-text-dim font-bold">Strategy Pool</h4>
                </div>
                <button 
                  onClick={() => setSelectedStrategies(selectedStrategies.length === STRATEGIES.length ? [] : [...STRATEGIES])}
                  className="text-[9px] text-accent hover:underline uppercase tracking-wider"
                >
                  {selectedStrategies.length === STRATEGIES.length ? 'Deselect All' : 'Select All'}
                </button>
              </div>

              <div className="space-y-1">
                {STRATEGIES.map(s => (
                  <button
                    key={s}
                    onClick={() => toggleStrategy(s)}
                    className={`w-full flex items-center justify-between p-2 rounded text-[11px] transition-all group ${
                      selectedStrategies.includes(s) 
                        ? 'bg-accent/10 border border-accent/20 text-white' 
                        : 'bg-transparent border border-transparent text-text-dim hover:bg-white/5'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: STRATEGY_COLORS[s] }} />
                      <span className="truncate">{s}</span>
                    </div>
                    {selectedStrategies.includes(s) && <CheckCircle2 className="w-3 h-3 text-accent" />}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-4">
              <button
                onClick={runComparison}
                disabled={isRunning || selectedStrategies.length === 0}
                className="w-full bg-accent text-bg font-bold uppercase tracking-widest text-[12px] py-4 rounded-lg flex items-center justify-center gap-2 hover:bg-white transition-all disabled:opacity-50 disabled:grayscale"
              >
                {isRunning ? (
                  <>
                    <div className="w-4 h-4 border-2 border-bg border-t-transparent animate-spin rounded-full" />
                    Calculating...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    Launch Analysis
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Main Chart Area */}
          <div className="flex-1 flex flex-col min-w-0 bg-black/10">
            <div className="flex-1 p-6 flex flex-col min-h-0">
              {chartData.length > 0 ? (
                <>
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-4">
                      <div className="bg-profit/10 border border-profit/20 px-3 py-1.5 rounded flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-profit" />
                        <div>
                          <p className="text-[9px] text-text-dim uppercase tracking-tighter">Leader Net Profit</p>
                          <p className="text-sm font-mono text-profit font-bold">${results[0]?.profit.toFixed(2)}</p>
                        </div>
                      </div>
                      <div className="bg-accent/10 border border-accent/20 px-3 py-1.5 rounded flex items-center gap-2">
                        <Zap className="w-4 h-4 text-accent" />
                        <div>
                          <p className="text-[9px] text-text-dim uppercase tracking-tighter">Highest Accuracy</p>
                          <p className="text-sm font-mono text-accent font-bold">
                            {Math.max(...results.map(r => r.winRate)).toFixed(1)}%
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-[10px] text-text-dim flex items-center gap-3 italic">
                      <Info className="w-3.5 h-3.5" />
                      Results based on {tickCount.toLocaleString()} simulated ticks.
                    </div>
                  </div>

                  <div className="flex-1 min-h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                        <XAxis 
                          dataKey="trade" 
                          stroke="rgba(255,255,255,0.3)" 
                          fontSize={10} 
                          tickLine={false}
                          axisLine={false}
                          label={{ value: 'TRADE EXECUTION COUNT', position: 'insideBottom', offset: -5, fontSize: 9, fill: 'rgba(255,255,255,0.3)', fontWeight: 'bold' }}
                        />
                        <YAxis 
                          stroke="rgba(255,255,255,0.3)" 
                          fontSize={10} 
                          tickLine={false}
                          axisLine={false}
                          tickFormatter={(v) => `$${v}`}
                        />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#141417', border: '1px solid rgba(255,255,255,0.1)', fontSize: '12px' }}
                          itemStyle={{ padding: '2px 0' }}
                          cursor={{ stroke: 'rgba(255,255,255,0.1)', strokeWidth: 1 }}
                        />
                        <Legend iconType="circle" wrapperStyle={{ fontSize: '10px', paddingTop: '20px' }} />
                        <ReferenceLine y={0} stroke="#ff4444" strokeDasharray="3 3" opacity={0.3} />
                        {selectedStrategies.map(s => (
                          <Line
                            key={s}
                            type="monotone"
                            dataKey={s}
                            stroke={STRATEGY_COLORS[s]}
                            strokeWidth={results[0]?.strategy === s ? 3 : 1.5}
                            dot={false}
                            animationDuration={1000}
                            activeDot={{ r: 4, strokeWidth: 0 }}
                            opacity={results[0]?.strategy === s ? 1 : 0.6}
                          />
                        ))}
                      </LineChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="mt-8 overflow-x-auto custom-scrollbar">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-white/5">
                          <th className="pb-3 text-[10px] uppercase font-bold text-text-dim tracking-widest pl-2">Rank</th>
                          <th className="pb-3 text-[10px] uppercase font-bold text-text-dim tracking-widest">Strategy</th>
                          <th className="pb-3 text-[10px] uppercase font-bold text-text-dim tracking-widest">Total Trades</th>
                          <th className="pb-3 text-[10px] uppercase font-bold text-text-dim tracking-widest">W / L</th>
                          <th className="pb-3 text-[10px] uppercase font-bold text-text-dim tracking-widest">Accuracy</th>
                          <th className="pb-3 text-[10px] uppercase font-bold text-text-dim tracking-widest pr-2 text-right">Net Profit</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/[0.02]">
                        {results.map((res, idx) => (
                          <tr key={res.strategy} className={`group hover:bg-white/[0.02] transition-colors ${idx === 0 ? 'bg-accent/5' : ''}`}>
                            <td className="py-4 pl-2 font-mono text-xs text-text-dim">#{idx + 1}</td>
                            <td className="py-4">
                              <div className="flex items-center gap-2">
                                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: STRATEGY_COLORS[res.strategy] }} />
                                <span className={`text-[12px] font-bold ${idx === 0 ? 'text-accent' : 'text-text-main'}`}>{res.strategy}</span>
                              </div>
                            </td>
                            <td className="py-4 font-mono text-[11px] text-text-main">{res.trades}</td>
                            <td className="py-4 font-mono text-[11px] text-text-main">
                              <span className="text-profit">{res.wins}</span> / <span className="text-loss">{res.losses}</span>
                            </td>
                            <td className="py-4">
                              <div className="flex items-center gap-2">
                                <span className="font-mono text-xs text-white">{res.winRate.toFixed(1)}%</span>
                                <div className="w-16 h-1bg-white/5 rounded-full overflow-hidden hidden sm:block">
                                  <div className="h-full bg-accent" style={{ width: `${res.winRate}%` }} />
                                </div>
                              </div>
                            </td>
                            <td className={`py-4 pr-2 text-right font-mono text-sm font-bold ${res.profit >= 0 ? 'text-profit' : 'text-loss'}`}>
                              {res.profit >= 0 ? '+' : ''}${res.profit.toFixed(2)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center space-y-4 opacity-50">
                  <div className="p-6 bg-white/5 rounded-full ring-8 ring-white/[0.02]">
                    <BarChart3 className="w-12 h-12 text-text-dim" />
                  </div>
                  <div>
                    <h5 className="text-lg font-bold text-white mb-2">Ready to Compare?</h5>
                    <p className="text-sm text-text-dim max-w-sm mx-auto">
                      Select your preferred target strategies from the sidebar and click "Launch Analysis" to visualize their performance trajectory.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-white/5 bg-black/40 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-[10px] text-text-dim uppercase tracking-widest font-bold">
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-profit" />
              <span>Profit Scaling</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-loss" />
              <span>Drawdown Risk</span>
            </div>
          </div>
          
          <div className="text-[10px] text-text-dim italic bg-white/5 px-3 py-1 rounded-full border border-white/5">
            Note: Results are simulated using historical probability and standard Deriv payout rates.
          </div>
        </div>
      </motion.div>
    </div>
  );
};
