import { signInWithPopup, signOut } from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import { useState, useEffect } from 'react';
import { LogIn, LogOut, ShieldCheck, User, ExternalLink } from 'lucide-react';

export const GoogleSignIn = ({ isDerivLinked, onLinkDeriv }: { isDerivLinked?: boolean, onLinkDeriv?: () => void }) => {
    const [user, setUser] = useState(auth.currentUser);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged((u) => {
            setUser(u);
            setIsLoading(false);
        });
        return () => unsubscribe();
    }, []);

    const handleSignIn = async () => {
        if (isLoading) return;
        setIsLoading(true);
        setError(null);
        try {
            await signInWithPopup(auth, googleProvider);
        } catch (error: any) {
            console.error('Sign-in error', error);
            if (error.code === 'auth/cancelled-popup-request' || error.code === 'auth/popup-blocked') {
                setError('Popup blocked! Please allow popups for this site or open in a new tab.');
            } else if (error.message?.includes('INTERNAL ASSERTION FAILED')) {
                setError('Security session sync failed. Please refresh the page.');
            } else {
                setError('Connection failed. Please try again.');
            }
            setIsLoading(false);
        }
    };
    
    const handleSignOut = async () => {
        setIsLoading(true);
        setError(null);
        try {
            await signOut(auth);
        } catch (error) {
            console.error('Sign-out error', error);
        }
        setIsLoading(false);
    };

    const openInNewTab = () => {
        window.open(window.location.href, '_blank');
    };

    return (
        <div className="flex flex-col items-end gap-1">
            <div className="flex items-center gap-3">
                {user ? (
                    <div className="flex items-center gap-3 bg-card-bg border border-border px-3 py-1.5 rounded-[8px] shadow-[0_0_20px_rgba(0,255,65,0.05)] border-accent/20">
                        <div className="flex flex-col items-end">
                            <div className="flex items-center gap-1">
                                <span className={`text-[9px] uppercase leading-none font-black tracking-widest ${isDerivLinked ? 'text-accent' : 'text-loss animate-pulse'}`}>
                                    {isDerivLinked ? 'Linked & Verified' : 'Deriv Unlinked'}
                                </span>
                            </div>
                            <span className="text-[11px] text-text-main font-mono font-bold leading-tight mt-0.5">{user.email}</span>
                        </div>
                        
                        {!isDerivLinked && onLinkDeriv && (
                            <button 
                                onClick={onLinkDeriv}
                                className="px-3 py-1.5 bg-accent text-bg text-[10px] font-black uppercase tracking-wider rounded-[6px] hover:bg-[#00e039] transition-all hover:scale-105 active:scale-95 shadow-[0_4px_12px_rgba(0,255,65,0.2)]"
                            >
                                Link Deriv
                            </button>
                        )}

                        <div className="relative">
                            <img 
                                src={user.photoURL || `https://ui-avatars.com/api/?name=${user.email}&background=030803&color=00ff41`} 
                                alt="User" 
                                className="w-8 h-8 rounded-full border border-accent shadow-[0_0_10px_rgba(0,255,65,0.2)]" 
                            />
                            {isDerivLinked && (
                                <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-accent rounded-full border-2 border-bg flex items-center justify-center">
                                    <div className="w-1 h-1 bg-bg rounded-full animate-ping" />
                                </div>
                            )}
                        </div>
                        <button 
                            onClick={handleSignOut} 
                            disabled={isLoading}
                            className="p-2 bg-loss/10 border border-loss/30 text-loss rounded-[4px] hover:bg-loss hover:text-white transition-all active:scale-95 disabled:opacity-50"
                            title="Sign Out"
                        >
                            <LogOut className="w-3.5 h-3.5" />
                        </button>
                    </div>
                ) : (
                    <div className="flex flex-col items-center gap-4 w-full">
                        <button 
                            onClick={handleSignIn} 
                            disabled={isLoading}
                            className="group w-full flex items-center justify-center gap-3 text-[13px] bg-accent text-bg px-8 py-4 rounded-[12px] hover:bg-[#00e039] transition-all hover:scale-[1.02] active:scale-95 font-black uppercase tracking-[2px] shadow-[0_10px_30px_rgba(0,255,65,0.2)] disabled:opacity-50"
                        >
                            {isLoading ? (
                                <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                            ) : (
                                <LogIn className="w-5 h-5 group-hover:-translate-y-0.5 transition-transform" />
                            )}
                            {isLoading ? 'SECURELY LOGGING IN...' : 'Continue with Google'}
                        </button>
                        
                        {error && (
                            <button 
                                onClick={openInNewTab}
                                className="text-[11px] bg-white/5 text-text-dim px-4 py-2 rounded-[6px] hover:bg-white/10 font-bold flex items-center gap-2 transition-all"
                            >
                                <ExternalLink className="w-3.5 h-3.5" />
                                Browser Permission Fix
                            </button>
                        )}
                    </div>
                )}
            </div>
            {error && !isLoading && (
                <div className="flex items-center gap-1.5 px-3 py-1 bg-loss/10 border border-loss/20 rounded-[4px] mt-2">
                    <div className="w-1 h-1 bg-loss rounded-full animate-pulse" />
                    <span className="text-[10px] text-loss font-bold uppercase tracking-tight">{error}</span>
                </div>
            )}
        </div>
    );
};
