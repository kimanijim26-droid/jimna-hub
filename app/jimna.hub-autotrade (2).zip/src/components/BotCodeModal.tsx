import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Copy, Check, Terminal, Code2 } from 'lucide-react';
import { StrategyType } from '../types';

interface BotCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  strategy: StrategyType;
}

const STRATEGY_CODES: Record<StrategyType, { ts: string, py: string, xml: string, description: string }> = {
  'Python Ultimate E/O': {
    description: 'Advanced pattern recognition and parity momentum tracking.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="procedures_defreturn" id="pattern_entropy">
    <field name="NAME">calculate_entropy</field>
    <comment pinned="false" h="80" w="160">Analyze 25 ticks for alternation vs clustering</comment>
    <value name="RETURN">
      <block type="logic_ternary">
        <value name="IF"><block type="logic_compare"><field name="OP">GT</field><value name="A"><block type="variables_get"><field name="VAR">entropy</field></block></value><value name="B"><block type="math_number"><field name="NUM">0.75</field></block></value></block></value>
        <value name="THEN"><block type="text"><field name="TEXT">SWITCH</field></block></value>
        <value name="ELSE"><block type="text"><field name="TEXT">TREND</field></block></value>
      </block>
    </value>
  </block>
</xml>`,
    ts: `// TypeScript Implementation
const recent25 = history.slice(-25).map(t => t.lastDigit % 2 === 0);
const evenCount = recent25.filter(e => e).length;
const parityBias = evenCount / 25;

let switches = 0;
for (let i = 1; i < recent25.length; i++) {
  if (recent25[i] !== recent25[i-1]) switches++;
}
const patternEntropy = switches / recent25.length;

if (patternEntropy > 0.75) {
  // High alternation - Play the switch
  return isEven ? 'DIGITODD' : 'DIGITEVEN';
} else if (patternEntropy < 0.28) {
  // High clustering - Play the trend
  return isEven ? 'DIGITEVEN' : 'DIGITODD';
}`,
    py: `# Python Implementation
def get_signal(history, is_even):
    recent_25 = [t['last_digit'] % 2 == 0 for t in history[-25:]]
    even_count = sum(1 for e in recent_25 if e)
    parity_bias = even_count / 25
    
    switches = 0
    for i in range(1, len(recent_25)):
        if recent_25[i] != recent_25[i-1]:
            switches += 1
    
    pattern_entropy = switches / len(recent_25)
    
    if pattern_entropy > 0.75:
        return 'DIGITODD' if is_even else 'DIGITEVEN'
    elif pattern_entropy < 0.28:
        return 'DIGITEVEN' if is_even else 'DIGITODD'
    return None`
  },
  'Python Fast E/O': {
    description: 'Aggressive parity scaling based on immediate ai confidence.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="controls_if">
    <value name="IF0">
      <block type="logic_compare">
        <field name="OP">GTE</field>
        <value name="A"><block type="variables_get"><field name="VAR">ai_confidence</field></block></value>
        <value name="B"><block type="math_arithmetic"><field name="OP">MINUS</field><value name="A"><block type="variables_get"><field name="VAR">filter</field></block></value><value name="B"><block type="math_number"><field name="NUM">15</field></block></value></block></value>
      </block>
    </value>
    <statement name="DO0">
      <block type="purchase"><field name="PURCHASE_LIST">DIGITEVEN</field></block>
    </statement>
  </block>
</xml>`,
    ts: `if (aiConfidence >= (filter - 15)) {
  return lastDigit % 2 === 0 ? 'DIGITEVEN' : 'DIGITODD';
}`,
    py: `# Python Implementation
def get_signal(ai_confidence, last_digit, filter):
    if ai_confidence >= (filter - 15):
        return 'DIGITEVEN' if last_digit % 2 == 0 else 'DIGITODD'
    return None`
  },
  'Python Safe E/O': {
    description: 'Conservative entry waiting for 3 consecutive parity matches.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="variables_set">
    <field name="VAR">history_streak</field>
    <value name="VALUE"><block type="lists_create_with"><mutation items="3"></mutation></value>
  </block>
  <block type="controls_if">
    <value name="IF0"><block type="logic_operation"><field name="OP">AND</field></block></value>
    <statement name="DO0"><block type="purchase"><field name="PURCHASE_LIST">DIGITEVEN</field></block></statement>
  </block>
</xml>`,
    ts: `const r3 = history.slice(-3).map(t => t.lastDigit % 2 === 0);
if (r3.every(v => v === true)) return 'DIGITEVEN';
if (r3.every(v => v === false)) return 'DIGITODD';`,
    py: `# Python Implementation
def get_signal(history):
    r3 = [t['last_digit'] % 2 == 0 for t in history[-3:]]
    if all(r3): return 'DIGITEVEN'
    if all(not v for v in r3): return 'DIGITODD'
    return None`
  },
  'Python Logic': {
    description: 'Barrier-based digit over/under with parity filter.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="controls_if">
    <value name="IF0">
      <block type="logic_operation">
        <field name="OP">OR</field>
        <value name="A"><block type="logic_compare"><field name="OP">GTE</field><value name="A"><block type="variables_get"><field name="VAR">ai_confidence</field></block></value><value name="B"><block type="variables_get"><field name="VAR">filter</field></block></value></block></value>
        <value name="B"><block type="logic_operation"><field name="OP">AND</field></value>
      </block>
    </value>
  </block>
</xml>`,
    ts: `const isTargetDigitEven = lastDigit % 2 === 0;
if (aiConfidence >= filter || (isTargetDigitEven && trend > 55)) {
    return tradeType; // Over/Under
}`,
    py: `# Python Implementation
def get_signal(last_digit, ai_confidence, filter, trend):
    is_even = last_digit % 2 == 0
    if ai_confidence >= filter or (is_even and trend > 55):
        return "DIGITOVER" # or DIGITUNDER
    return None`
  },
  'Python Bias O/U': {
    description: 'Statistical mean-based digit over/under.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="procedures_defreturn">
    <field name="NAME">analyze_bias</field>
    <value name="RETURN">
      <block type="logic_compare">
        <field name="OP">GT</field>
        <value name="A"><block type="math_on_list"><field name="OP">AVERAGE</field></block></value>
        <value name="B"><block type="math_number"><field name="NUM">5.5</field></block></value>
      </block>
    </value>
  </block>
</xml>`,
    ts: `const recent10 = history.slice(-10).map(t => t.lastDigit);
const avgDigit = recent10.reduce((a, b) => a + b, 0) / 10;
if (avgDigit > 5.5) return 'DIGITOVER';
else if (avgDigit < 3.5) return 'DIGITUNDER';`,
    py: `# Python Implementation
def get_signal(history):
    recent_10 = [t['last_digit'] for t in history[-10:]]
    avg_digit = sum(recent_10) / 10
    if avg_digit > 5.5: return 'DIGITOVER'
    elif avg_digit < 3.5: return 'DIGITUNDER'
    return None`
  },
  'Even': {
    description: 'Strict parity dominance targeting even digits.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="controls_if">
    <value name="IF0"><block type="logic_operation"><field name="OP">OR</field><value name="A"><block type="logic_compare"><field name="OP">GTE</field><value name="A"><block type="variables_get"><field name="VAR">ai_confidence</field></block></value><value name="B"><block type="variables_get"><field name="VAR">filter</field></block></value></block></value><value name="B"><block type="logic_compare"><field name="OP">GT</field><value name="A"><block type="variables_get"><field name="VAR">parity_score</field></block></value><value name="B"><block type="math_number"><field name="NUM">55</field></block></value></block></value></block></value>
    <statement name="DO0"><block type="purchase"><field name="PURCHASE_LIST">DIGITEVEN</field></block></statement>
  </block>
</xml>`,
    ts: `const evenBias = parityScore > 55;
if (aiConfidence >= filter || evenBias) return 'DIGITEVEN';`,
    py: `# Python Implementation
def get_signal(parity_score, ai_confidence, filter):
    if ai_confidence >= filter or parity_score > 55:
        return 'DIGITEVEN'
    return None`
  },
  'Odd': {
    description: 'Strict parity dominance targeting odd digits.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="controls_if">
    <value name="IF0"><block type="logic_operation"><field name="OP">OR</field><value name="A"><block type="logic_compare"><field name="OP">GTE</field><value name="A"><block type="variables_get"><field name="VAR">ai_confidence</field></block></value><value name="B"><block type="variables_get"><field name="VAR">filter</field></block></value></block></value><value name="B"><block type="logic_compare"><field name="OP">LT</field><value name="A"><block type="variables_get"><field name="VAR">parity_score</field></block></value><value name="B"><block type="math_number"><field name="NUM">45</field></block></value></block></value></block></value>
    <statement name="DO0"><block type="purchase"><field name="PURCHASE_LIST">DIGITODD</field></block></statement>
  </block>
</xml>`,
    ts: `const oddBias = parityScore < 45;
if (aiConfidence >= filter || oddBias) return 'DIGITODD';`,
    py: `# Python Implementation
def get_signal(parity_score, ai_confidence, filter):
    if ai_confidence >= filter or parity_score < 45:
        return 'DIGITODD'
    return None`
  },
  'Even/Odd': {
    description: 'Predictive parity based on micro-trend velocity.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="variables_set">
    <field name="VAR">predicted_digit</field>
    <value name="VALUE">
      <block type="logic_ternary">
        <value name="IF"><block type="logic_compare"><field name="OP">EQ</field><value name="A"><block type="variables_get"><field name="VAR">trend</field></block></value><value name="B"><block type="text"><field name="TEXT">UP</field></block></value></block></value>
        <value name="THEN"><block type="math_arithmetic"><field name="OP">ADD</field><value name="A"><block type="variables_get"><field name="VAR">last_digit</field></block></value><value name="B"><block type="math_number"><field name="NUM">1</field></block></value></block></value>
        <value name="ELSE"><block type="variables_get"><field name="VAR">last_digit</field></block></value>
      </block>
    </value>
  </block>
</xml>`,
    ts: `const predictedDigit = trend === 'UP' ? lastDigit + 1 : 
                       trend === 'DOWN' ? lastDigit - 1 : lastDigit;
return (predictedDigit % 2 === 0) ? 'DIGITEVEN' : 'DIGITODD';`,
    py: `# Python Implementation
def get_signal(trend, last_digit):
    pred = last_digit + 1 if trend == 'UP' else (last_digit - 1 if trend == 'DOWN' else last_digit)
    return 'DIGITEVEN' if pred % 2 == 0 else 'DIGITODD'`
  },
  'Alternate': {
    description: 'Counter-entropy strategy for explosive markets.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="controls_if">
    <value name="IF0"><block type="logic_compare"><field name="OP">GT</field><value name="A"><block type="variables_get"><field name="VAR">volatility</field></block></value><value name="B"><block type="math_number"><field name="NUM">55</field></block></value></block></value>
    <statement name="DO0">
      <block type="purchase"><field name="PURCHASE_LIST">SWITCHED_PARITY</field></block>
    </statement>
  </block>
</xml>`,
    ts: `if (volatility > 55) return lastDigit % 2 === 0 ? 'DIGITODD' : 'DIGITEVEN';`,
    py: `# Python Implementation
def get_signal(volatility, last_digit):
    if volatility > 55:
        return 'DIGITODD' if last_digit % 2 == 0 else 'DIGITEVEN'`
  },
  'Flow Market': {
    description: 'Clustering strategy for low-volatility trending markets.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="controls_if">
    <value name="IF0"><block type="logic_compare"><field name="OP">LT</field><value name="A"><block type="variables_get"><field name="VAR">volatility</field></block></value><value name="B"><block type="math_number"><field name="NUM">45</field></block></value></block></value>
    <statement name="DO0">
      <block type="purchase"><field name="PURCHASE_LIST">TREND_PARITY</field></block>
    </statement>
  </block>
</xml>`,
    ts: `if (volatility < 45) return lastDigit % 2 === 0 ? 'DIGITEVEN' : 'DIGITODD';`,
    py: `# Python Implementation
def get_signal(volatility, last_digit):
    if volatility < 45:
        return 'DIGITEVEN' if last_digit % 2 == 0 else 'DIGITODD'`
  },
  'Smart O/U': {
    description: 'RSI and Stochastic mean reversion Over/Under.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="controls_if">
    <value name="IF0"><block type="logic_operation"><field name="OP">OR</field><value name="A"><block type="logic_compare"><field name="OP">GT</field><value name="A"><block type="variables_get"><field name="VAR">rsi</field></block></value><value name="B"><block type="math_number"><field name="NUM">65</field></block></value></block></value><value name="B"><block type="logic_compare"><field name="OP">GT</field><value name="A"><block type="variables_get"><field name="VAR">stoch_k</field></block></value><value name="B"><block type="math_number"><field name="NUM">80</field></block></value></block></value></block></value>
    <statement name="DO0"><block type="purchase"><field name="PURCHASE_LIST">DIGITUNDER</field></block></statement>
  </block>
</xml>`,
    ts: `if (rsi > 65 || stochK > 80) return 'DIGITUNDER';
else if (rsi < 35 || stochK < 20) return 'DIGITOVER';`,
    py: `# Python Implementation
def get_signal(rsi, stoch_k):
    if rsi > 65 or stoch_k > 80: return 'DIGITUNDER'
    if rsi < 35 or stoch_k < 20: return 'DIGITOVER'`
  },
  'Sniper Switch': {
    description: 'Precision reversal tracking on broken streaks.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="procedures_defreturn">
    <field name="NAME">is_streak_broken</field>
    <value name="RETURN"><block type="logic_operation"><field name="OP">AND</field></block></value>
  </block>
</xml>`,
    ts: `const r4 = history.slice(-4).map(t => t.lastDigit % 2 === 0);
if (r4[0] === r4[1] && r4[1] === r4[2] && r4[3] !== r4[2]) {
    return r4[3] ? 'DIGITEVEN' : 'DIGITODD';
}`,
    py: `# Python Implementation
def get_signal(history):
    r4 = [t['last_digit'] % 2 == 0 for t in history[-4:]]
    if r4[0] == r4[1] == r4[2] and r4[3] != r4[2]:
        return 'DIGITEVEN' if r4[3] else 'DIGITODD'`
  },
  'Momentum Rise/Fall': {
    description: 'Technical trend surfing for Rise/Fall contracts.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="controls_if">
    <value name="IF0"><block type="logic_operation"><field name="OP">AND</field><value name="A"><block type="logic_compare"><field name="OP">GT</field><value name="A"><block type="variables_get"><field name="VAR">momentum</field></block></value><value name="B"><block type="math_number"><field name="NUM">70</field></block></value></block></value><value name="B"><block type="logic_compare"><field name="OP">NEQ</field><value name="A"><block type="variables_get"><field name="VAR">trend</field></block></value><value name="B"><block type="text"><field name="TEXT">NEUTRAL</field></block></value></block></value></block></value>
    <statement name="DO0"><block type="purchase"><field name="PURCHASE_LIST">TREND_DIRECTION</field></block></statement>
  </block>
</xml>`,
    ts: `if (momentum > 70 && trend !== 'NEUTRAL') return trend === 'UP' ? 'CALL' : 'PUT';`,
    py: `# Python Implementation
def get_signal(momentum, trend):
    if momentum > 70 and trend != 'NEUTRAL':
        return 'CALL' if trend == 'UP' else 'PUT'`
  },
  'Reversal Rise/Fall': {
    description: 'Mean reversion targeting contrarian trend breaks.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="controls_if">
    <value name="IF0"><block type="logic_compare"><field name="OP">GT</field><value name="A"><block type="variables_get"><field name="VAR">mean_reversion</field></block></value><value name="B"><block type="math_number"><field name="NUM">75</field></block></value></block></value>
    <statement name="DO0"><block type="purchase"><field name="PURCHASE_LIST">REVERSE_TREND</field></block></statement>
  </block>
</xml>`,
    ts: `if (meanReversion > 75) return trend === 'UP' ? 'PUT' : 'CALL';`,
    py: `# Python Implementation
def get_signal(mean_reversion, trend):
    if mean_reversion > 75:
        return 'PUT' if trend == 'UP' else 'CALL'`
  },
  'Forex Scalper Pro': {
    description: 'Multi-indicator forex scalping for rapid entries.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="controls_if">
    <value name="IF0"><block type="logic_operation"><field name="OP">AND</field><value name="A"><block type="logic_compare"><field name="OP">LT</field><value name="A"><block type="variables_get"><field name="VAR">rsi</field></block></value><value name="B"><block type="math_number"><field name="NUM">35</field></block></value></block></value><value name="B"><block type="logic_compare"><field name="OP">GT</field><value name="A"><block type="variables_get"><field name="VAR">macd</field></block></value><value name="B"><block type="math_number"><field name="NUM">0</field></block></value></block></value></block></value>
    <statement name="DO0"><block type="purchase"><field name="PURCHASE_LIST">CALL</field></block></statement>
  </block>
</xml>`,
    ts: `const oversoldRecov = rsi < 35 && macd > 0;
const overboughtRecov = rsi > 65 && macd < 0;
if (oversoldRecov) return 'CALL';
else if (overboughtRecov) return 'PUT';`,
    py: `# Python Implementation
def get_signal(rsi, macd):
    if rsi < 35 and macd > 0: return 'CALL'
    if rsi > 65 and macd < 0: return 'PUT'`
  },
  'Digit Diff': {
    description: 'Probability-weighted digit avoidance.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="controls_if">
    <value name="IF0"><block type="logic_compare"><field name="OP">GTE</field><value name="A"><block type="variables_get"><field name="VAR">ai_confidence</field></block></value><value name="B"><block type="math_arithmetic"><field name="OP">MINUS</field><value name="A"><block type="variables_get"><field name="VAR">filter</field></block></value><value name="B"><block type="math_number"><field name="NUM">10</field></block></value></block></value></block></value>
    <statement name="DO0"><block type="purchase"><field name="PURCHASE_LIST">DIGITDIFF</field></block></statement>
  </block>
</xml>`,
    ts: `if (aiConfidence >= (filter - 10)) return 'DIGITDIFF';`,
    py: `# Python Implementation
def get_signal(ai_confidence, filter):
    if ai_confidence >= filter - 10: return 'DIGITDIFF'`
  },
  'Digit Match': {
    description: 'High-risk high-reward digit matching.',
    xml: `<xml xmlns="http://www.w3.org/1999/xhtml">
  <block type="controls_if">
    <value name="IF0"><block type="logic_compare"><field name="OP">GTE</field><value name="A"><block type="variables_get"><field name="VAR">ai_confidence</field></block></value><value name="B"><block type="math_arithmetic"><field name="OP">ADD</field><value name="A"><block type="variables_get"><field name="VAR">filter</field></block></value><value name="B"><block type="math_number"><field name="NUM">10</field></block></value></block></value></block></value>
    <statement name="DO0"><block type="purchase"><field name="PURCHASE_LIST">DIGITMATCH</field></block></statement>
  </block>
</xml>`,
    ts: `if (aiConfidence >= (filter + 10)) return 'DIGITMATCH';`,
    py: `# Python Implementation
def get_signal(ai_confidence, filter):
    if ai_confidence >= filter + 10: return 'DIGITMATCH'`
  }
};

export function BotCodeModal({ isOpen, onClose, strategy }: BotCodeModalProps) {
  const [activeTab, setActiveTab] = React.useState<'ts' | 'py' | 'xml'>('py');
  const [copied, setCopied] = React.useState(false);

  const codeData = STRATEGY_CODES[strategy];

  const handleCopy = () => {
    const code = activeTab === 'ts' ? codeData.ts : activeTab === 'xml' ? codeData.xml : codeData.py;
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="bg-[#0D0D10] border border-white/10 w-full max-w-2xl rounded-[12px] overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
          >
            {/* Header */}
            <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/[0.02]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-[8px] bg-accent/10 border border-accent/20 flex items-center justify-center">
                  <Terminal className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg leading-tight">{strategy}</h3>
                  <p className="text-text-dim text-xs mt-1 uppercase tracking-widest font-medium">Core Strategy Engine</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 hover:bg-white/5 rounded-full text-text-dim hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 overflow-y-auto">
              <div className="mb-6 bg-accent/5 border border-accent/10 p-4 rounded-[8px]">
                <p className="text-accent text-[13px] leading-relaxed italic">
                  "{codeData.description}"
                </p>
              </div>

              {/* Tabs */}
              <div className="flex items-center gap-2 mb-4">
                <button
                  onClick={() => setActiveTab('py')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-[6px] text-xs font-bold uppercase tracking-widest transition-all ${
                    activeTab === 'py' ? 'bg-accent text-bg shadow-[0_0_15px_rgba(0,255,65,0.3)]' : 'bg-white/5 text-text-dim hover:bg-white/10'
                  }`}
                >
                  Python
                </button>
                <button
                  onClick={() => setActiveTab('ts')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-[6px] text-xs font-bold uppercase tracking-widest transition-all ${
                    activeTab === 'ts' ? 'bg-accent text-bg shadow-[0_0_15px_rgba(0,255,65,0.3)]' : 'bg-white/5 text-text-dim hover:bg-white/10'
                  }`}
                >
                  TypeScript
                </button>
                <button
                  onClick={() => setActiveTab('xml')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-[6px] text-xs font-bold uppercase tracking-widest transition-all ${
                    activeTab === 'xml' ? 'bg-accent text-bg shadow-[0_0_15px_rgba(0,255,65,0.3)]' : 'bg-white/5 text-text-dim hover:bg-white/10'
                  }`}
                >
                  Binary Bot XML
                </button>
              </div>

              {/* Code Area */}
              <div className="relative group">
                <div className="absolute top-4 right-4 z-10 flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="p-2 bg-[#1A1A1D] border border-white/10 rounded-[6px] text-text-dim hover:text-white hover:border-white/20 transition-all active:scale-95 flex items-center gap-2"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-accent" /> : <Copy className="w-3.5 h-3.5" />}
                    <span className="text-[10px] font-bold uppercase">{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                
                <pre className="bg-[#050505] border border-white/5 p-6 rounded-[8px] overflow-x-auto text-xs font-mono leading-relaxed text-text-main custom-scrollbar">
                  <code>{activeTab === 'ts' ? codeData.ts : activeTab === 'xml' ? codeData.xml : codeData.py}</code>
                </pre>
              </div>

              <div className="mt-6 flex items-start gap-3 p-4 bg-white/[0.02] border border-white/5 rounded-[8px]">
                <div className="mt-0.5">
                  <Code2 className="w-4 h-4 text-text-dim" />
                </div>
                <p className="text-[11px] text-text-dim leading-relaxed">
                  Notice: The {activeTab === 'xml' ? 'XML' : 'Python'} code provided is a conceptual implementation of the internal logic used by the bot. {activeTab === 'xml' ? 'While structured according to Binary Bot XML patterns, these snippets require additional block IDs for direct importing.' : 'It is designed for analysis and porting to external environments.'} Reference the TypeScript logic for the exact real-time execution parameters used in Jimna.Hub.
                </p>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-white/[0.01] border-t border-white/5 flex justify-end">
              <button
                onClick={onClose}
                className="px-6 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-[6px] text-[11px] font-bold uppercase tracking-widest transition-all"
              >
                Close Engine
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
