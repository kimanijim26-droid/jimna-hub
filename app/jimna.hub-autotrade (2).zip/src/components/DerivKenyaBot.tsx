import React, { useState, useEffect, useRef } from 'react';
import { KENYA_CONFIG } from '../config';
import { GoogleSignIn } from './GoogleSignIn';
import { auth } from '../firebase';

const DerivKenyaBot = () => {
    const [connectionStatus, setConnectionStatus] = useState('INITIALIZING');
    const [latency, setLatency] = useState<number | null>(null);
    const [connectionQuality, setConnectionQuality] = useState('CHECKING');
    const [activeEndpoint, setActiveEndpoint] = useState<string | null>(null);
    const [logs, setLogs] = useState<{ time: string, message: string, type: string }[]>([]);
    const [user, setUser] = useState(auth.currentUser);

    const wsRef = useRef<WebSocket | null>(null);

    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged((u) => {
            setUser(u);
        });
        return () => unsubscribe();
    }, []);
    const pingIntervalRef = useRef<NodeJS.Timeout | null>(null);
    const lastPingTimeRef = useRef<number | null>(null);

    const addLog = (message: string, type: 'info' | 'success' | 'warning' | 'error' | 'debug' = 'info') => {
        const timestamp = new Date().toLocaleTimeString();
        setLogs(prev => [{ time: timestamp, message, type }, ...prev].slice(0, 100));
        console.log(`[${timestamp}] ${message}`);
    };

    const measureLatency = async () => {
        const start = performance.now();
        try {
            const testWs = new WebSocket('wss://frontend.binaryws.com/websockets/v3?app_id=' + KENYA_CONFIG.appId);

            await new Promise<void>((resolve, reject) => {
                const timeout = setTimeout(() => reject(new Error('Timeout')), 5000);
                testWs.onopen = () => {
                    clearTimeout(timeout);
                    const end = performance.now();
                    const measuredLatency = end - start;
                    setLatency(measuredLatency);

                    if (measuredLatency < 300) {
                        setConnectionQuality('EXCELLENT');
                        addLog(`📡 Kenya connection: ${measuredLatency.toFixed(0)}ms - EXCELLENT`, 'success');
                    } else if (measuredLatency < 500) {
                        setConnectionQuality('GOOD');
                        addLog(`📡 Kenya connection: ${measuredLatency.toFixed(0)}ms - GOOD`, 'success');
                    } else if (measuredLatency < 800) {
                        setConnectionQuality('FAIR');
                        addLog(`📡 Kenya connection: ${measuredLatency.toFixed(0)}ms - FAIR`, 'warning');
                    } else {
                        setConnectionQuality('POOR');
                        addLog(`📡 Kenya connection: ${measuredLatency.toFixed(0)}ms - POOR (consider alternative network)`, 'warning');
                    }

                    testWs.close();
                    resolve();
                };
                testWs.onerror = () => {
                    clearTimeout(timeout);
                    reject(new Error('Connection failed'));
                };
            });
        } catch (error: any) {
            addLog(`📡 Latency test failed: ${error.message}`, 'error');
            setConnectionQuality('OFFLINE');
        }
    };

    const connectWithOTP = async () => {
        addLog('🔐 Using OTP authentication flow for Kenya connection...', 'info');

        try {
            const otpResponse = await fetch(
                `https://api.derivws.com/trading/v1/options/accounts/${KENYA_CONFIG.accountId}/otp`,
                {
                    method: 'POST',
                    headers: {
                        'Deriv-App-ID': KENYA_CONFIG.appId,
                        'Authorization': `Bearer ${KENYA_CONFIG.apiToken}`,
                        'Content-Type': 'application/json',
                    },
                }
            );

            const otpData = await otpResponse.json();

            if (otpData.errors) {
                throw new Error(otpData.errors[0].message);
            }

            const wsUrl = otpData.data.url;
            addLog(`✅ OTP obtained, connecting to ${wsUrl.substring(0, 50)}...`, 'success');

            wsRef.current = new WebSocket(wsUrl);
            setupWebSocketHandlers();

        } catch (error: any) {
            addLog(`❌ OTP connection failed: ${error.message}`, 'error');
            connectDirect();
        }
    };

    const connectDirect = () => {
        addLog('🔌 Connecting via server proxy to Deriv Kenya-optimized endpoint...', 'info');

        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        // Extract host from the config endpoint and pass to proxy
        const host = KENYA_CONFIG.endpoint.replace('wss://', '').split('/')[0];
        const wsUrl = `${protocol}//${window.location.host}/api/deriv-ws-proxy?app_id=${KENYA_CONFIG.appId}&host=${host}`;
        
        wsRef.current = new WebSocket(wsUrl);
        setupWebSocketHandlers();
    };

    const setupWebSocketHandlers = () => {
        if (!wsRef.current) return;
        
        wsRef.current.onopen = () => {
            addLog('✅ WebSocket connected via Kenya-optimized route!', 'success');
            setConnectionStatus('CONNECTED');
            setActiveEndpoint(KENYA_CONFIG.endpoint);

            measureLatency();

            if (!KENYA_CONFIG.useOTPConnection) {
                wsRef.current!.send(JSON.stringify({
                    authorize: KENYA_CONFIG.apiToken
                }));
            }

            setupKeepAlive();
            subscribeToTicks();
        };

        wsRef.current.onmessage = (event) => {
            handleDerivMessage(JSON.parse(event.data));
        };

        wsRef.current.onerror = (error: any) => {
            addLog(`❌ WebSocket error: ${error.message}`, 'error');
            setConnectionStatus('ERROR');
            attemptReconnection();
        };

        wsRef.current.onclose = () => {
            addLog('🔌 Connection closed', 'warning');
            setConnectionStatus('DISCONNECTED');
            attemptReconnection();
        };
    };

    const setupKeepAlive = () => {
        if (pingIntervalRef.current) clearInterval(pingIntervalRef.current);

        pingIntervalRef.current = setInterval(() => {
            if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
                lastPingTimeRef.current = Date.now();
                wsRef.current.send(JSON.stringify({ ping: 1 }));
                addLog('💓 Keep-alive ping sent', 'debug');
            }
        }, 30000);
    };

    let retryCount = 0;
    const attemptReconnection = () => {
        if (retryCount >= KENYA_CONFIG.maxRetries) {
            addLog('❌ Max reconnection attempts reached. Please check your internet.', 'error');
            setConnectionStatus('FAILED');
            return;
        }

        retryCount++;
        const delay = KENYA_CONFIG.retryDelay * Math.pow(1.5, retryCount - 1);

        addLog(`🔄 Reconnection attempt ${retryCount}/${KENYA_CONFIG.maxRetries} in ${delay / 1000}s...`, 'warning');

        setTimeout(() => {
            if (KENYA_CONFIG.useOTPConnection) {
                connectWithOTP();
            } else {
                connectDirect();
            }
        }, delay);
    };

    const subscribeToTicks = () => {
        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
            wsRef.current.send(JSON.stringify({
                ticks: "R_100",
                subscribe: 1
            }));
            addLog('📡 Subscribed to Volatility 100 Index', 'success');
        }
    };

    const handleDerivMessage = (response: any) => {
        if (response.msg_type === 'pong' && lastPingTimeRef.current) {
            const currentLatency = Date.now() - lastPingTimeRef.current;
            setLatency(currentLatency);

            if (currentLatency < 300) setConnectionQuality('EXCELLENT');
            else if (currentLatency < 500) setConnectionQuality('GOOD');
            else if (currentLatency < 800) setConnectionQuality('FAIR');
            else setConnectionQuality('POOR');
        }

        if (response.msg_type === 'authorize' && response.authorize) {
            addLog(`✅ Authorized as: ${response.authorize.loginid}`, 'success');
            setConnectionStatus('TRADING READY');
        }

        if (response.error) {
            addLog(`⚠️ API Error: ${response.error.message}`, 'error');
        }
    };

    useEffect(() => {
        measureLatency();

        if (KENYA_CONFIG.useOTPConnection) {
            connectWithOTP();
        } else {
            connectDirect();
        }

        return () => {
            if (pingIntervalRef.current) clearInterval(pingIntervalRef.current);
            if (wsRef.current) wsRef.current.close();
        };
    }, []);

    return (
        <div className="bg-[#0a0a1a] text-white min-h-screen p-5 font-mono">
            <div className="border-b-2 border-[#00ff88] mb-5 pb-2.5 flex justify-between items-center flex-wrap">
                <h1 className="text-[#00ff88] m-0 text-2xl">🤖 Jimna.Hub AutoTrade</h1>
                <div className="flex items-center gap-4">
                  <GoogleSignIn />
                  <div className="bg-[#00ff8820] border border-[#00ff88] px-3.5 py-1.5 rounded-full text-xs text-[#00ff88]">
                      🇰🇪 Kenya-Optimized Connection
                  </div>
                </div>
            </div>

            <div className="grid grid-cols-[repeat(auto-fit,minmax(180px,1fr))] gap-4 mb-5">
                {user && (
                    <div className="bg-[#1a1a2e] p-4 rounded-lg border border-[#00ff8840] flex items-center gap-3">
                        <img 
                            src={user.photoURL || `https://ui-avatars.com/api/?name=${user.email}&background=00ff88&color=0a0a1a`} 
                            className="w-10 h-10 rounded-full border border-[#00ff88]" 
                            alt="Profile"
                        />
                        <div className="overflow-hidden">
                            <div className="text-[10px] text-[#888] uppercase mb-1">Authenticated Account</div>
                            <div className="text-xs font-bold text-[#00ff88] truncate">{user.email}</div>
                        </div>
                    </div>
                )}
                
                <div className="bg-[#1a1a2e] p-4 rounded-lg text-center">
                    <div className="text-[11px] text-[#888] mb-2 uppercase">CONNECTION STATUS</div>
                    <div className="text-lg font-bold" style={{ color: connectionStatus === 'TRADING READY' ? '#00ff88' : '#ffaa00' }}>
                        {connectionStatus}
                    </div>
                </div>

                <div className="bg-[#1a1a2e] p-4 rounded-lg text-center">
                    <div className="text-[11px] text-[#888] mb-2 uppercase">LATENCY</div>
                    <div className="text-lg font-bold" style={{ color: (latency || 0) < 500 ? '#00ff88' : '#ffaa00' }}>
                        {latency ? `${latency.toFixed(0)}ms` : '---'}
                    </div>
                </div>

                <div className="bg-[#1a1a2e] p-4 rounded-lg text-center">
                    <div className="text-[11px] text-[#888] mb-2 uppercase">CONNECTION QUALITY</div>
                    <div className="text-lg font-bold" style={{
                        color:
                            connectionQuality === 'EXCELLENT' ? '#00ff88' :
                                connectionQuality === 'GOOD' ? '#88ff00' :
                                    connectionQuality === 'FAIR' ? '#ffaa00' : '#ff4444'
                    }}>
                        {connectionQuality}
                    </div>
                </div>

                <div className="bg-[#1a1a2e] p-4 rounded-lg text-center">
                    <div className="text-[11px] text-[#888] mb-2 uppercase">ACTIVE ENDPOINT</div>
                    <div className="text-lg font-bold">
                        {activeEndpoint ? activeEndpoint.split('/')[2] : '---'}
                    </div>
                </div>
            </div>

            <div className="bg-[#1a1a2e] p-4 rounded-lg mb-5 border-l-4 border-[#00ff88]">
                <div className="text-sm font-bold mb-2 text-[#00ff88]">📡 Kenya Network Optimization</div>
                <div className="text-xs text-[#aaa] leading-relaxed">
                    Deriv uses AWS Global Accelerator to provide <strong>15-50% lower latency</strong> for Kenyan traders.
                    Average execution speed is under <strong>50 milliseconds</strong> with 99.97% uptime.
                </div>
            </div>

            <div className="flex gap-2.5 mb-5">
                <button onClick={measureLatency} className="bg-[#00ff8820] border border-[#00ff88] text-[#00ff88] px-5 py-2.5 rounded-lg cursor-pointer font-mono hover:bg-[#00ff8840]">
                    📊 Test Connection Speed
                </button>
                <button onClick={() => KENYA_CONFIG.useOTPConnection ? connectWithOTP() : connectDirect()} className="bg-[#ffaa0020] border border-[#ffaa00] text-[#ffaa00] px-5 py-2.5 rounded-lg cursor-pointer font-mono hover:bg-[#ffaa0040]">
                    🔄 Reconnect
                </button>
            </div>

            <div className="bg-[#0a0a1a] border border-[#333] rounded-lg overflow-hidden">
                <div className="bg-[#1a1a2e] p-2.5 border-b border-[#333] font-bold text-xs">📋 Connection Logs</div>
                <div className="p-2.5 max-h-[250px] overflow-y-auto text-[11px]">
                    {logs.map((log, i) => (
                        <div key={i} className="mb-1 font-mono" style={{
                            color: log.type === 'success' ? '#00ff88' : log.type === 'error' ? '#ff4444' : '#aaa'
                        }}>
                            [{log.time}] {log.message}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default DerivKenyaBot;
