import { CollapsibleSection } from './components/CollapsibleSection';
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { GoogleGenAI } from "@google/genai";
import { motion, AnimatePresence } from "motion/react";
import { 
  Play, Square, Settings, Activity, DollarSign, AlertCircle, 
  Wifi, WifiOff, ChevronRight, RotateCcw, ChevronDown, Shield, Target, Zap, Ghost, ChevronUp,
  CheckCircle, AlertTriangle, XCircle, TrendingDown, TrendingUp, CheckCircle2, ShieldCheck, Info, LayoutGrid, Minus,
  Maximize, Minimize, RefreshCw, Cpu, Globe, RefreshCcw, Copy, ExternalLink, Link, Send, BarChart3, History, Power, Trash2, Terminal
} from 'lucide-react';
import { 
  AreaChart, Area, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine
} from 'recharts';
import { auth, db, googleProvider } from './firebase';
import { signInWithPopup } from 'firebase/auth';
import { doc, setDoc, getDoc, updateDoc } from 'firebase/firestore';
import { GoogleSignIn } from './components/GoogleSignIn';
import { MultiStrategyBacktestModal } from './components/MultiStrategyBacktestModal';
import { TradeHistoryModal } from './components/TradeHistoryModal';
import { BotCodeModal } from './components/BotCodeModal';
import { 
  TradeLog, 
  LogSeverity, 
  LogEntry, 
  TickData, 
  StrategyType, 
  MarketAnalysis 
} from './types';
import { 
  getSymbolPrecision, 
  calculateRSI, 
  calculateSMA, 
  calculateMACDSeries, 
  calculateBollingerBands, 
  calculateStochastic, 
  calculateStandardDeviation,
  performMarketAnalysis,
  getStrategySignal
} from './strategies';

// --- ELITE UI THEME CONSTANTS ---
const COLORS = {
  bg: '#030803',
  card: '#071007',
  accent: '#00ff41',
  profit: '#00ff41',
  loss: '#ff0044',
  text: '#e0ffe0',
  dim: '#008f11',
  border: 'rgba(0, 255, 65, 0.2)'
};

// Tech Indicator Utilities moved to strategies.ts


function MarketDepthChart({ currentPrice, intensity }: { currentPrice: number, intensity: number }) {
  const data = useMemo(() => {
    if (!currentPrice) return [];
    const step = currentPrice * 0.0001; 
    const levels = 25;
    const depth: any[] = [];
    
    // Bids (Buy orders) - Left side (prices lower than current)
    let cumulativeBid = 0;
    const bidBase = (100 + (intensity * 2)) * 10;
    for (let i = levels; i > 0; i--) {
      const price = currentPrice - (i * step);
      // Volume increases as we move further from the price, but with some noise
      const vol = bidBase * (1 + Math.random() * 0.2) * (levels - i + 1) / levels;
      cumulativeBid += vol;
      depth.push({ 
        price: price.toFixed(4), 
        bid: Math.round(cumulativeBid), 
        ask: 0,
        type: 'bid'
      });
    }
    
    // Mid point (Spread area simulation)
    depth.push({ price: currentPrice.toFixed(4), bid: 0, ask: 0, type: 'spread' });

    // Asks (Sell orders) - Right side (prices higher than current)
    let cumulativeAsk = 0;
    const askBase = (100 + (intensity * 1.8)) * 10;
    for (let i = 1; i <= levels; i++) {
      const price = currentPrice + (i * step);
      const vol = askBase * (1 + Math.random() * 0.2) * i / levels;
      cumulativeAsk += vol;
      depth.push({ 
        price: price.toFixed(4), 
        bid: 0, 
        ask: Math.round(cumulativeAsk),
        type: 'ask'
      });
    }
    
    return depth;
  }, [currentPrice, intensity]);

  return (
    <div className="h-[120px] w-full mt-2 select-none">
      <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
        <AreaChart data={data} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="bidGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#00ff41" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="#00ff41" stopOpacity={0}/>
            </linearGradient>
            <linearGradient id="askGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#ff0044" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="#ff0044" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <XAxis 
            dataKey="price" 
            hide 
          />
          <YAxis hide />
          <Tooltip 
            cursor={{ stroke: 'rgba(0,255,65,0.1)', strokeWidth: 1 }}
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const data = payload[0].payload;
                const isBid = data.type === 'bid';
                const isAsk = data.type === 'ask';
                if (!isBid && !isAsk) return null;

                return (
                  <div className="bg-[#030803] border border-[rgba(0,255,65,0.2)] p-2 rounded-[4px] shadow-xl">
                    <p className="text-[10px] text-text-dim uppercase tracking-widest mb-1">
                      {isBid ? 'Bid Volume' : 'Ask Volume'}
                    </p>
                    <p className={`text-[12px] font-mono font-bold ${isBid ? 'text-profit' : 'text-loss'}`}>
                      {isBid ? data.bid : data.ask} units
                    </p>
                    <p className="text-[10px] text-text-dim font-mono mt-1">
                      Price: {data.price}
                    </p>
                  </div>
                );
              }
              return null;
            }}
          />
          <Area 
            type="step" 
            dataKey="bid" 
            stroke="#00ff41" 
            strokeWidth={1.5}
            fill="url(#bidGradient)" 
            fillOpacity={1}
            connectNulls 
            animationDuration={500}
          />
          <Area 
            type="step" 
            dataKey="ask" 
            stroke="#ff0044" 
            strokeWidth={1.5}
            fill="url(#askGradient)" 
            fillOpacity={1}
            connectNulls 
            animationDuration={500}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

// Auto-cleaning utility for API tokens to support copy-paste of prefixed examples (e.g., "eg.pat_...")
const cleanToken = (token: string): string => {
  if (!token) return '';
  let t = token.trim();
  // Strip outer quotes
  t = t.replace(/^['":\s]+|['":\s]+$/g, '');
  
  // Remove common prefix if any
  const prefixes = [
    'bearer', 'e.g.', 'e.g', 'eg.', 'eg:', 'eg',
    'example:', 'example', 'ex:', 'ex'
  ];
  for (const prefix of prefixes) {
    if (t.toLowerCase().startsWith(prefix)) {
      const rest = t.slice(prefix.length).trim();
      // Only strip if followed by a separator or space, to avoid mangling valid tokens like "extremetoken" or "egt"
      if (/^[ :._\-]/.test(rest) || t.toLowerCase().startsWith(prefix + ' ')) {
        t = rest.replace(/^[ :._\-]+/, '').trim();
        break;
      }
    }
  }
  return t;
};

const isPersonalAccessToken = (token: string): boolean => {
  if (!token) return false;
  // Deriv Personal Access Tokens are exactly 15 characters. We check < 30 for safety.
  return token.trim().length < 30;
};

// Sound notification utility
const playNotificationSound = () => {
  try {
    const AudioContextClass = (window.AudioContext || (window as any).webkitAudioContext);
    if (!AudioContextClass) return;
    
    const audioCtx = new AudioContextClass();
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();

    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); 
    gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime); 
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.1);

    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    oscillator.start();
    oscillator.stop(audioCtx.currentTime + 0.1);
  } catch (e) {
    // Audio context might be blocked by browser policy until user interaction
  }
};

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

const fetchWithTimeout = async (url: string, options: RequestInit, timeoutMs = 30000) => {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    clearTimeout(id);
    return response;
  } catch (e: any) {
    clearTimeout(id);
    if (e.name === 'AbortError') {
      throw new Error(`Request timed out after ${timeoutMs}ms. Please check your internet connection or use a different server.`);
    }
    throw e;
  }
};

export default function App() {
  const [appId, setAppId] = useState(() => localStorage.getItem('deriv_app_id') || '33ySFYbvralU62iTFqFXL');
  const [demoToken, setDemoToken] = useState(() => localStorage.getItem('deriv_demo_token') || '');
  const [realToken, setRealToken] = useState(() => localStorage.getItem('deriv_real_token') || '');
  const [accountType, setAccountType] = useState<'demo' | 'real'>(() => (localStorage.getItem('deriv_account_type') as 'demo' | 'real') || 'demo');
  const [derivServer, setDerivServer] = useState(() => localStorage.getItem('deriv_server') || import.meta.env.VITE_DERIV_SERVER || 'api.derivws.com');
  const [derivOrigin, setDerivOrigin] = useState(() => localStorage.getItem('deriv_origin') || window.location.origin);
  const [showAdvancedAuth, setShowAdvancedAuth] = useState(false);
  const [isEditingTokens, setIsEditingTokens] = useState(false);

  const [user, setUser] = useState(auth.currentUser);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [derivEmail, setDerivEmail] = useState<string | null>(null);
  const [isExchangingToken, setIsExchangingToken] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [isReconnecting, setIsReconnecting] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [tempToken, setTempToken] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authErrorCode, setAuthErrorCode] = useState<string | null>(null);
  const [currentCheckingHost, setCurrentCheckingHost] = useState<string | null>(null);

  // States for direct API token (PAT) inputs
  const [inputDemoToken, setInputDemoToken] = useState('');
  const [inputRealToken, setInputRealToken] = useState('');
  const [inputAppId, setInputAppId] = useState('33ySFYbvralU62iTFqFXL');
  const [inputServer, setInputServer] = useState('api.derivws.com');

  // Synchronize modal inputs when editing state opens
  useEffect(() => {
    if (isEditingTokens || !(demoToken || realToken)) {
      setInputDemoToken(demoToken);
      setInputRealToken(realToken);
      setInputAppId(appId);
      setInputServer(derivServer);
    }
  }, [isEditingTokens, demoToken, realToken, appId, derivServer]);

  // Saves PAT tokens to local storage & Firestore, then initiates connection
  const savePATTokens = async (demo: string, real: string, appIdVal: string, serverVal: string) => {
    addLog('Validating and storing Personal Access Tokens...', 'info');
    
    const cleanDemo = cleanToken(demo);
    const cleanReal = cleanToken(real);
    const cleanAppId = appIdVal.trim() || '33ySFYbvralU62iTFqFXL';
    const cleanServer = serverVal.trim() || 'api.derivws.com';

    if (!cleanDemo && !cleanReal) {
      addLog('Error: Please enter at least a Demo or Real API Token.', 'error');
      setAuthError('Please enter at least a virtual or real account API token.');
      return;
    }

    setAuthError(null);
    localStorage.setItem('deriv_demo_token', cleanDemo);
    localStorage.setItem('deriv_real_token', cleanReal);
    localStorage.setItem('deriv_app_id', cleanAppId);
    localStorage.setItem('deriv_server', cleanServer);

    setDemoToken(cleanDemo);
    setRealToken(cleanReal);
    setAppId(cleanAppId);
    setDerivServer(cleanServer);

    // Save to Firestore if user logged in
    if (auth.currentUser) {
      const tokensToSync = {
        demo: cleanDemo,
        real: cleanReal,
        appId: cleanAppId,
        deriv_server: cleanServer
      };
      await syncTokensToFirestore(tokensToSync);
    }

    setIsEditingTokens(false);
    addLog('API token settings updated. Connecting to Deriv stream...', 'success');

    // Force disconnect and reconnect
    setTimeout(() => {
      if (ws.current) {
        ws.current.close();
      }
      connectAPI();
    }, 500);
  };

  // Sync tokens to Firestore if user is logged in
  const rebalanceDemo = () => {
    if (ws.current?.readyState === WebSocket.OPEN && accountType === 'demo') {
      ws.current.send(JSON.stringify({ topup_virtual: 1 }));
      addLog('Requesting Demo Balance Reset...', 'info');
    }
  };

  const syncTokensToFirestore = async (tokens: { demo?: string, real?: string, appId?: string }) => {
    if (!auth.currentUser) return;
    const path = `users/${auth.currentUser.uid}`;
    try {
      const userDocRef = doc(db, 'users', auth.currentUser.uid);
      await setDoc(userDocRef, {
        deriv_tokens: tokens,
        last_sync: new Date().toISOString(),
        email: auth.currentUser.email
      }, { merge: true });
      addLog('Account settings synced to secure cloud.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  };

  // Load tokens from Firestore
  const loadTokensFromFirestore = async (uid: string) => {
    const path = `users/${uid}`;
    try {
      const userDocRef = doc(db, 'users', uid);
      const docSnap = await getDoc(userDocRef);
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.deriv_tokens) {
          const tokens = data.deriv_tokens;
          if (tokens.demo) {
            setDemoToken(tokens.demo);
            localStorage.setItem('deriv_demo_token', tokens.demo);
          }
          if (tokens.real) {
            setRealToken(tokens.real);
            localStorage.setItem('deriv_real_token', tokens.real);
          }
          if (tokens.deriv_server) {
            setDerivServer(tokens.deriv_server);
            localStorage.setItem('deriv_server', tokens.deriv_server);
          } else if (tokens.connection_protocol === 'rest-otp') {
             setDerivServer('api.derivws.com');
             localStorage.setItem('deriv_server', 'api.derivws.com');
          }
          if (tokens.appId) {
            setAppId(tokens.appId);
            localStorage.setItem('deriv_app_id', tokens.appId);
          }
          addLog('Linked Deriv credentials restored via Google Hub.', 'success');
        }
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, path);
    }
  };

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((u) => {
      setUser(u);
      setIsAuthReady(true);
      if (u) {
        loadTokensFromFirestore(u.uid);
      }
    });
    return () => unsubscribe();
  }, []);

  // Auto-connect when tokens are loaded or start public preview
  useEffect(() => {
    const activeToken = accountType === 'demo' ? demoToken : realToken;
    const canConnect = user && isAuthReady && !isConnected && !isReconnecting;
    if (canConnect) {
      // Auto-connect with a small delay to ensure states are propagated
      const timer = setTimeout(() => {
        connectAPI();
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [user, demoToken, realToken, accountType, isAuthReady, isConnected, isReconnecting]);

  // Unified Token Exchange Logic
  const executeTokenExchange = async (code: string, state: string) => {
    addLog('Authorization response received. Validating CSRF protection state...', 'info');
    
    // 1. Verify state
    const savedState = localStorage.getItem('oauth_state');
    if (!state || state !== savedState) {
      addLog("Authentication failed: Security state verification mismatch (CSRF protection failed).", "error");
      return;
    }

    // 2. Fetch code_verifier
    const codeVerifier = localStorage.getItem('pkce_code_verifier');
    if (!codeVerifier) {
      addLog("Authentication failed: Missing original session verifier.", "error");
      return;
    }

    addLog('Exchanging secure authorization code for access token...', 'info');
    setIsExchangingToken(true);

    try {
      const redirectUri = `${window.location.origin}/auth/callback`;
      const response = await fetch('/api/auth/exchange', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          code,
          code_verifier: codeVerifier,
          redirect_uri: redirectUri
        })
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `HTTP ${response.status}`);
      }

      const tokenData = await response.json();
      const accessToken = tokenData.access_token;
      
      if (!accessToken) {
        throw new Error("No access token found in exchange response.");
      }

      addLog('Bearer security token successfully negotiated via Cloud Key Vault.', 'success');

      // Clean up PKCE values
      localStorage.removeItem('pkce_code_verifier');
      localStorage.removeItem('oauth_state');

      // Check accounts list using the bearer token
      addLog('Retrieving associated customer accounts and options parameters...', 'info');
      const accountsList = await fetchDerivAccounts(accessToken, appId);
      addLog(`Discovered ${accountsList.length} linked accounts. Synchronizing profiles...`, 'success');

      const demoExists = accountsList.some((acc: any) => acc.is_virtual === 1);
      const realExists = accountsList.some((acc: any) => acc.is_virtual === 0);

      let firstAccountType: 'demo' | 'real' = 'demo';
      if (realExists && !demoExists) {
        firstAccountType = 'real';
      }

      localStorage.setItem('deriv_demo_token', accessToken);
      setDemoToken(accessToken);
      localStorage.setItem('deriv_real_token', accessToken);
      setRealToken(accessToken);

      setAccountType(firstAccountType);
      localStorage.setItem('deriv_account_type', firstAccountType);

      if (auth.currentUser) {
        syncTokensToFirestore({
          demo: accessToken,
          real: accessToken,
          appId: appId
        });
      }

      addLog('Jimna.Hub Live Link activated securely via third party OAuth.', 'success');

      // Reconnect websocket with new tokens
      setTimeout(() => {
        if (ws.current) {
          ws.current.close();
        }
        connectAPI();
      }, 500);

    } catch (error: any) {
      console.error("Token Exchange Error:", error);
      addLog(`Token negotiation failed: ${error.message || error}`, 'error');
    } finally {
      setIsExchangingToken(false);
    }
  };

  // 1. Popup Message Listener
  useEffect(() => {
    const handlePopupMessage = (event: MessageEvent) => {
      // Validate origin to make sure it's secure
      const origin = event.origin;
      if (!origin.endsWith('.run.app') && !origin.includes('localhost') && origin !== window.location.origin) {
        return;
      }
      
      if (event.data?.type === 'DERIV_AUTH_CODE') {
        const { code, state } = event.data;
        if (code && state) {
          executeTokenExchange(code, state);
        }
      }
    };
    
    window.addEventListener('message', handlePopupMessage);
    return () => {
      window.removeEventListener('message', handlePopupMessage);
    };
  }, [appId, user]);

  // 2. Direct Redirect Fallback Listener
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const code = searchParams.get('code');
    const state = searchParams.get('state');
    
    if (code && state) {
      executeTokenExchange(code, state);
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [appId, user]);

  const initiateOAuth = async () => {
    setIsEditingTokens(true);
  };

  const handleGoogleLogin = async () => {
    addLog('Initiating secure Google authentication sync...', 'info');
    try {
      await signInWithPopup(auth, googleProvider);
      addLog('Signed in with Google successfully.', 'success');
    } catch (error: any) {
      console.error('Google Auth Error:', error);
      if (error.code === 'auth/popup-blocked') {
        addLog('Google Sign-in popup blocked. Please allow popups or open the app in a new tab.', 'error');
      } else {
        addLog(`Google Authentication failed: ${error.message || error}`, 'error');
      }
    }
  };

  const fetchDerivAccounts = async (token: string, currentAppId: string) => {
    if (!token || token.length < 5) return [];
    if (isPersonalAccessToken(token)) {
      // Personal Access Tokens do not support Options Trading REST API endpoints, skip REST check
      return [];
    }
    const appIdClean = currentAppId.toString().trim();
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Deriv-App-ID': appIdClean,
      'Content-Type': 'application/json'
    };

    try {
      // Step 1: Try direct fetch
      const response = await fetchWithTimeout('https://api.derivws.com/trading/v1/options/accounts', {
        method: 'GET',
        headers
      }, 30000);

      if (response.ok) {
        const data = await response.json();
        return data.data || [];
      }
      throw new Error(`Direct fetch failed: ${response.status}`);
    } catch (e: any) {
      console.warn("Direct REST fetch failed, attempting proxy...", e.message);
      
      try {
        // Step 2: Try proxy fetch
        const proxyResponse = await fetchWithTimeout(`/api/deriv-rest-proxy/trading/v1/options/accounts?app_id=${appIdClean}${derivOrigin ? `&origin=${encodeURIComponent(derivOrigin)}` : ''}`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }, 30000);

        if (!proxyResponse.ok) {
          let errorDetail = `Proxy fetch failed: ${proxyResponse.status}`;
          try {
            const errorData = await proxyResponse.json();
            if (errorData && errorData.error) {
              const innerError = errorData.error;
              if (typeof innerError === 'object') {
                errorDetail = innerError.message || innerError.code || JSON.stringify(innerError);
              } else {
                errorDetail = innerError;
              }
            } else if (errorData && errorData.message) {
              errorDetail = errorData.message;
            }
          } catch (_) {}
          throw new Error(errorDetail);
        }
        const data = await proxyResponse.json();
        if (data.error && !data.data) {
           throw new Error(data.error.message || data.error || "Proxy received abnormal response");
        }
        return data.data || [];
      } catch (proxyError: any) {
        console.error("REST API Proxy Error:", proxyError);
        const msg = proxyError.message || "";
        if (msg.includes("Invalid or expired token")) {
          throw new Error("Authentication failed via REST gateway (Invalid token or Origin mismatch).");
        }
        throw new Error(`Cloud Proxy Error: ${msg}.`);
      }
    }
  };

  const handleResetConnection = () => {
    if (window.confirm("This will clear all saved API tokens, App IDs, and reset your connection settings. Continue?")) {
      localStorage.removeItem('deriv_demo_token');
      localStorage.removeItem('deriv_real_token');
      localStorage.removeItem('deriv_app_id');
      localStorage.removeItem('deriv_server');
      localStorage.removeItem('deriv_origin');
      
      setDemoToken(null);
      setRealToken(null);
      setAppId('33ySFYbvralU62iTFqFXL');
      setDerivServer('api.derivws.com');
      setDerivOrigin('');
      setTempToken('');
      
      if (ws.current) {
        ws.current.close();
      }
      setIsConnected(false);
      addLog("System reset complete. All cached credentials purged.", "warning");
    }
  };

  const handleManualAuth = async () => {
    if (!tempToken) {
      setAuthError('Please enter an API Token');
      return;
    }
    
    setIsValidating(true);
    setAuthError(null);
    setAuthErrorCode(null);
    const cleaned = cleanToken(tempToken);

    // Track active connection for diagnostic
    addLog(`Linking Account to AppID: ${appId}...`, 'info');

    // Try multiple endpoints for resilience, especially for new string-based App IDs
    const endpoints = [
      (derivServer || 'api.derivws.com').trim(),
      'api.derivws.com',
      'ws.derivws.com',
      'blue.derivws.com'
    ];

    const tryConnect = async (index: number) => {
      if (index >= endpoints.length) {
        // Final attempt: Try REST API validation for newer App IDs / blocked environments
        try {
          setCurrentCheckingHost('api.derivws.com (REST)');
          addLog('Handshake blocked. Switching to REST protocol validation...', 'info');
          
          const appIdClean = appId.toString().trim();
          const accounts = await fetchDerivAccounts(cleaned, appIdClean);
          
          if (accounts.length > 0) {
            const account = accounts[0];
            const isDemo = account.is_virtual === 1;
            
            if (isDemo) {
              setDemoToken(cleaned);
              localStorage.setItem('deriv_demo_token', cleaned);
            } else {
              setRealToken(cleaned);
              localStorage.setItem('deriv_real_token', cleaned);
            }

            // Persist Successful connection settings - New API
            setDerivServer('api.derivws.com');
            localStorage.setItem('deriv_server', 'api.derivws.com');
            
            if (user) {
              const userRef = doc(db, 'users', user.uid);
              updateDoc(userRef, {
                deriv_tokens: {
                  ...(isDemo ? { demo: cleaned } : { real: cleaned }),
                  appId: appIdClean,
                  connection_protocol: 'rest-otp'
                },
                updated_at: new Date().toISOString()
              }).catch(e => console.error("Firestore sync fail", e));
            }

            addLog(`Authenticated via REST as ${account.email || 'linked account'}`, 'success');
            setIsValidating(false);
            setCurrentCheckingHost(null);
            // Trigger connection attempt with the newly verified settings
            setTimeout(() => connectAPI(), 100);
            return;
          }
        } catch (e: any) {
          console.error("REST Auth Fallback Failed", e);
          setAuthError(`Verification Error: ${e.message || "Unknown protocol failure"}. Check if your App ID supports this domain.`);
          setIsValidating(false);
          setCurrentCheckingHost(null);
          return;
        }

        setAuthError('Connection Failed: Handshake could not be established with any server. This usually means the App ID is not registered or is blocking this origin.');
        setAuthErrorCode('InaccessibleAppID');
        setIsValidating(false);
        setCurrentCheckingHost(null);
        return;
      }

      const host = endpoints[index];
      setCurrentCheckingHost(host);
      addLog(`Connecting to secure node ${host}...`, 'info');
      
      let wsUrl = '';
      if (connectionMode === 'tunnel') {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const originParam = derivOrigin ? `&origin=${encodeURIComponent(derivOrigin)}` : '';
        wsUrl = `${protocol}//${window.location.host}/api/deriv-ws-proxy?app_id=${appId}&host=${host}${originParam}`;
      } else {
        wsUrl = `wss://${host}/websockets/v3?app_id=${appId}`;
      }
      
      const tempWs = new WebSocket(wsUrl);
      
      const timeout = setTimeout(() => {
        if (tempWs.readyState !== WebSocket.CLOSED) {
          tempWs.close();
          tryConnect(index + 1);
        }
      }, 5000);

      tempWs.onopen = () => {
        // Deriv's newer protocol requires app_id inside the JSON payload for some token types
        // Critical: Ensure if appId is numeric it stays numeric, but if it starts with characters it stays string
        const finalAppId = /^\d+$/.test(appId.toString().trim()) ? parseInt(appId) : appId.toString().trim();
        tempWs.send(JSON.stringify({ 
          authorize: cleaned,
          app_id: finalAppId
        }));
      };

      tempWs.onmessage = (msg) => {
        clearTimeout(timeout);
        const response = JSON.parse(msg.data);
        if (response.error) {
          const code = response.error.code;
          setAuthErrorCode(code);
          console.error("Auth Fail Code:", code, response.error);

          // If it's an App ID error, try next endpoint
          if (code === 'InvalidAppID') {
            addLog(`Node ${host} rejected App ID ${appId}. Attempting failover...`, 'warning');
            tempWs.close();
            tryConnect(index + 1);
          } else {
            // Mapping common Deriv error codes to user-friendly messages
            let msg = response.error.message;
            if (code === 'InvalidToken') msg = `The provided API Token is invalid or has expired for App ID ${appId}.`;
            if (code === 'AuthorizationRequired') msg = 'Authorization failed. Token might be missing permissions.';
            if (code === 'SelfExclusion') msg = 'This account is currently under self-exclusion and cannot be linked.';
            
            setAuthError(msg);
            addLog(`Authentication failed: ${msg}`, 'error');
            setIsValidating(false);
            setCurrentCheckingHost(null);
            tempWs.close();
          }
        } else {
          // Success
          const account = response.authorize;
          const isDemo = account.is_virtual === 1;
          
          if (isDemo) {
            setDemoToken(cleaned);
            localStorage.setItem('deriv_demo_token', cleaned);
          } else {
            setRealToken(cleaned);
            localStorage.setItem('deriv_real_token', cleaned);
          }
          
          // Save the successful server
          setDerivServer(host);
          localStorage.setItem('deriv_server', host);

          // Sync to cloud if user is logged in
          if (user) {
            const userRef = doc(db, 'users', user.uid);
            updateDoc(userRef, {
              deriv_tokens: {
                ...(isDemo ? { demo: cleaned } : { real: cleaned }),
                appId: appId
              },
              updated_at: new Date().toISOString()
            }).catch(e => console.error("Firestore sync fail", e));
          }

          addLog(`Authenticated as ${account.email} (${isDemo ? 'Demo' : 'Real'})`, 'success');
          setIsValidating(false);
          tempWs.close();
        }
      };

      tempWs.onerror = () => {
        clearTimeout(timeout);
        tempWs.close();
        tryConnect(index + 1);
      };
    };

    tryConnect(0);
  };

  const [connectionMode, setConnectionMode] = useState<'tunnel' | 'direct'>(() => {
    const saved = localStorage.getItem('deriv_connection_mode');
    if (!saved) {
      return 'tunnel';
    }
    return saved as 'tunnel' | 'direct';
  });

  const [balance, setBalance] = useState<number | null>(null);
  const [currency, setCurrency] = useState('USD');
  const [accounts, setAccounts] = useState<any[]>([]);
  
  const [maxRetries, setMaxRetries] = useState(10);
  const [reconnectDelay, setReconnectDelay] = useState(0.5);
  const [retryCount, setRetryCount] = useState(0);
  const [isMounted, setIsMounted] = useState(false);
  const lastAuthTokenRef = useRef<string | null>(null);
  const [showStartConfirm, setShowStartConfirm] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(err => {
        console.error(`Error attempting to enable full-screen mode: ${err.message}`);
      });
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);


  const [showBacktestModal, setShowBacktestModal] = useState(false);

  // Connection Diagnostics State
  interface DiagnosticStep {
    name: string;
    status: 'pending' | 'running' | 'success' | 'failed';
    result?: string;
    details?: string;
  }
  const [showDiagnosticModal, setShowDiagnosticModal] = useState(false);
  const [showMultiBacktestModal, setShowMultiBacktestModal] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [showBotCodeModal, setShowBotCodeModal] = useState(false);
  const [isDiagnosticRunning, setIsDiagnosticRunning] = useState(false);
  const [diagnosticSteps, setDiagnosticSteps] = useState<DiagnosticStep[]>([]);
  const [diagnosticSummary, setDiagnosticSummary] = useState<string>('');

  // Bot State
  const [marketType, setMarketType] = useState<'synthetic' | 'forex'>('synthetic');
  useEffect(() => {
    if (marketType === 'synthetic') {
      const synths = ['R_10', 'R_25', 'R_50', 'R_75', 'R_100'];
      setActivePairs(synths);
      setSymbol('R_100');
      setStrategy('Python Ultimate E/O');
    } else {
      const forex = ['frxEURUSD', 'frxGBPUSD', 'frxAUDUSD', 'frxUSDJPY', 'frxEURGBP'];
      setActivePairs(forex);
      setSymbol('frxEURUSD');
      setStrategy('Forex Scalper Pro');
    }
  }, [marketType]);

  const [isBotRunning, setIsBotRunning] = useState(false);
  const [isTrading, setIsTrading] = useState(false);
  const [trades, setTrades] = useState<TradeLog[]>([]);
  const [ticks, setTicks] = useState<TickData[]>([]);
  const [activePairs, setActivePairs] = useState<string[]>(['R_10', 'R_25', 'R_50', 'R_75', 'R_100']);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [currentStatus, setCurrentStatus] = useState<string>('System Ready');
  const [sessionProfit, setSessionProfit] = useState(0);
  const [profitTrend, setProfitTrend] = useState<{trade: number, profit: number}[]>([{ trade: 0, profit: 0 }]);
  
  // Advanced Session Stats
  const [sessionStats, setSessionStats] = useState({
    totalTrades: 0,
    wins: 0,
    losses: 0,
    evenWins: 0,
    oddWins: 0,
    totalStake: 0,
    currentStreak: 0,
    maxWinStreak: 0,
    maxLossStreak: 0,
    historicalWinRate: parseFloat(localStorage.getItem('ultimate_eo_hist_wr') || '62.0')
  });

  const [performanceAlert, setPerformanceAlert] = useState<{message: string, severity: 'warning' | 'error'} | null>(null);

  const [isBacktesting, setIsBacktesting] = useState(false);
  const [backtestResults, setBacktestResults] = useState({ trades: 0, wins: 0, losses: 0, evenWins: 0, oddWins: 0, profit: 0, streak: 0, maxWinStreak: 0, maxLossStreak: 0 });

  // Settings State
  const [initialStake, setInitialStake] = useState(1);
  const [currentStake, setCurrentStake] = useState(1);
  const [strategy, setStrategy] = useState<'Even' | 'Odd' | 'Even/Odd' | 'Alternate' | 'Smart O/U' | 'Flow Market' | 'Python Logic' | 'Python Bias O/U' | 'Sniper Switch' | 'Python Fast E/O' | 'Python Safe E/O' | 'Python Ultimate E/O' | 'Momentum Rise/Fall' | 'Reversal Rise/Fall' | 'Forex Scalper Pro' | 'Digit Diff' | 'Digit Match'>('Python Ultimate E/O');
  const [pythonTradeType, setPythonTradeType] = useState<'DIGITOVER' | 'DIGITUNDER'>('DIGITOVER');
  const [targetDigit, setTargetDigit] = useState(2);
  const [predictionObj, setPredictionObj] = useState<{ digit: number, trend: 'UP' | 'DOWN' | 'NEUTRAL', signal: string } | null>(null);
  const [signalStatus, setSignalStatus] = useState({ message: 'Waiting for data...', status: 'neutral', progress: 0 });
  const [marketAnalysis, setMarketAnalysis] = useState({ 
    volatility: 0, 
    strength: 0, 
    bestBot: 'Analyzing...',
    rsi: 50,
    sma: 0,
    macd: { macd: 0, signal: 0, hist: 0 },
    bb: { middle: 0, upper: 0, lower: 0 },
    stoch: { k: 50, d: 50 },
    forecast: {
      trend: 'NEUTRAL' as 'UP' | 'DOWN' | 'NEUTRAL',
      confidence: 0,
      projection: [] as number[]
    },
    aiConfidence: 0,
    stress: 0,
    strategies: {
      trend: 0,
      meanReversion: 0,
      momentum: 0,
      parity: 0
    }
  });
  const [strategyHealth, setStrategyHealth] = useState({ 
    score: 100, 
    deviation: 0, 
    status: 'OPTIMAL' as 'OPTIMAL' | 'DEVIATING' | 'CRITICAL',
    recommendation: ''
  });
  const [martingaleMultiplier, setMartingaleMultiplier] = useState(2);
  const [martingaleEnabled, setMartingaleEnabled] = useState(false);
  const [takeProfit, setTakeProfit] = useState(10);
  const [takeProfitEnabled, setTakeProfitEnabled] = useState(true);
  const [stopLoss, setStopLoss] = useState(20);
  const [stopLossEnabled, setStopLossEnabled] = useState(true);
  
  // Advanced Risk Management
  const [trailingStopEnabled, setTrailingStopEnabled] = useState(false);
  const [trailingStopDistance, setTrailingStopDistance] = useState(15);
  const [maxDrawdownEnabled, setMaxDrawdownEnabled] = useState(false);
  const [maxDrawdownLimit, setMaxDrawdownLimit] = useState(50);
  const [maxStake, setMaxStake] = useState(100);
  const [maxStakeEnabled, setMaxStakeEnabled] = useState(true);
  
  // Virtual Loss Jumping
  const [startInVirtualMode, setStartInVirtualMode] = useState(false);
  const [loopVirtualMode, setLoopVirtualMode] = useState(false);
  const [pythonUltimateCompoundMode, setPythonUltimateCompoundMode] = useState(true);
  const [turboSprintMode, setTurboSprintMode] = useState(false);
  const [pythonUltimateEvenOnly, setPythonUltimateEvenOnly] = useState(false);
  const [virtualLossJumpEnabled, setVirtualLossJumpEnabled] = useState(false);
  const [pauseAfterLosses, setPauseAfterLosses] = useState(2);
  const [virtualWinsTarget, setVirtualWinsTarget] = useState(1);
  const [isVirtualTrading, setIsVirtualTrading] = useState(false);
  const [virtualWinsCount, setVirtualWinsCount] = useState(0);
  const [aiGodMode, setAiGodMode] = useState(true);
  const [copied, setCopied] = useState(false);

  // Telegram Notifications settings
  const [telegramEnabled, setTelegramEnabled] = useState(() => localStorage.getItem('deriv_telegram_enabled') === 'true');
  const [telegramBotToken, setTelegramBotToken] = useState(() => localStorage.getItem('deriv_telegram_token') || '');
  const [telegramChatId, setTelegramChatId] = useState(() => localStorage.getItem('deriv_telegram_chat_id') || '');
  const [telegramMinBalanceChange, setTelegramMinBalanceChange] = useState(() => parseFloat(localStorage.getItem('deriv_telegram_min_balance_change') || '10'));
  const [telegramStatus, setTelegramStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');
  const [telegramError, setTelegramError] = useState<string | null>(null);

  const lastNotifiedBalanceRef = useRef<number | null>(null);

  const sendTelegramNotification = async (message: string) => {
    if (!stateRef.current.telegramEnabled) return;
    const token = stateRef.current.telegramBotToken?.trim();
    const chatId = stateRef.current.telegramChatId?.trim();
    if (!token || !chatId) return;

    try {
      await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text: message,
          parse_mode: 'HTML'
        })
      });
    } catch (err) {
      console.error("Error dispatching Telegram notification:", err);
    }
  };

  const sendTestTelegramMessage = async () => {
    if (!telegramBotToken || !telegramChatId) {
      setTelegramStatus('error');
      setTelegramError("Bot Token and Chat ID are required.");
      return;
    }
    
    setTelegramStatus('sending');
    setTelegramError(null);
    
    try {
      const message = `⚡ <b>Jimna.Hub Connection Test</b>\n━━━━━━━━━━━━━━━━━━\n✅ Your Telegram notification channel has been configured successfully!\n\n🤖 <b>Platform</b>: Jimna.Hub AutoTrader\n⏱️ <b>Timestamp</b>: ${new Date().toLocaleTimeString()}`;
      
      const res = await fetch(`https://api.telegram.org/bot${telegramBotToken.trim()}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: telegramChatId.trim(),
          text: message,
          parse_mode: 'HTML'
        })
      });
      
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.description || "Incomplete response from Telegram API");
      }
      
      setTelegramStatus('success');
      addLog("Telegram configuration test message sent successfully!", "success");
      setTimeout(() => setTelegramStatus('idle'), 3000);
    } catch (err: any) {
      console.error(err);
      setTelegramStatus('error');
      setTelegramError(err.message || "Failed to connect to Telegram API");
    }
  };

  useEffect(() => {
    if (balance === null) return;

    const prevNotifiedBalance = lastNotifiedBalanceRef.current;
    if (prevNotifiedBalance === null) {
      // Establish baseline on first load
      lastNotifiedBalanceRef.current = balance;
      return;
    }

    const diff = Math.abs(balance - prevNotifiedBalance);
    if (diff >= telegramMinBalanceChange) {
      const changeSign = balance > prevNotifiedBalance ? '📈 +' : '📉 -';
      const changeAmount = diff.toFixed(2);
      const balMsg = `💰 <b>Jimna.Hub - Significant Balance Change</b>\n━━━━━━━━━━━━━━━━━━\n🏦 <b>Previous Balance</b>: ${currency} ${prevNotifiedBalance.toFixed(2)}\n💳 <b>Current Balance</b>: ${currency} ${balance.toFixed(2)}\n⚠️ <b>Net Change</b>: ${changeSign}${currency} ${changeAmount}`;
      
      sendTelegramNotification(balMsg);
      lastNotifiedBalanceRef.current = balance;
    }
  }, [balance, telegramEnabled, telegramBotToken, telegramChatId, telegramMinBalanceChange, currency]);

  const [isWaitingForCalm, setIsWaitingForCalm] = useState(false);
  const isWaitingForCalmRef = useRef(false);

  const [tradePace, setTradePace] = useState<'safe' | 'balanced' | 'aggressive'>('balanced');
  const [signalIntensity, setSignalIntensity] = useState(60);
  const lastTradeTime = useRef<number>(0);

  // Lil Assistant Bot
  const [isLilOpen, setIsLilOpen] = useState(false);
  const [lilMessages, setLilMessages] = useState<{role: 'user' | 'assistant', content: string}[]>([
    { role: 'assistant', content: "Hello! I'm Lil, your AI guide for Jimna.Hub. How can I help you dominate the market today?" }
  ]);
  const [lilInput, setLilInput] = useState("");
  const [isLilTyping, setIsLilTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
    // Auto-scroll logs
    const logContainer = document.getElementById('log-container');
    if (logContainer) {
      logContainer.scrollTop = logContainer.scrollHeight;
    }
  }, [lilMessages, logs]);

  const handleSendLilMessage = async () => {
    if (!lilInput.trim()) return;

    const userMessage = { role: 'user' as const, content: lilInput };
    setLilMessages(prev => [...prev, userMessage]);
    setLilInput("");
    setIsLilTyping(true);

    try {
      try {
        const response = await fetch('/api/chat', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': 'Bearer YOUR_NEW_TOKEN', // The 15-char token
            'Deriv-App-ID': 'YOUR_NEW_APP_ID'       // The new App ID
          },
          body: JSON.stringify({ messages: [...lilMessages, userMessage].map(m => ({ role: m.role, content: m.content })) }),
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          throw new Error(errorData.error || `HTTP ${response.status}`);
        }

        const data = await response.json();
        setLilMessages(prev => [...prev, data.message]);
      } catch (proxyError: any) {
        console.warn("DeepSeek proxy failed, using Gemini fallback:", proxyError.message);
        
        // Gemini Direct Fallback
        const apiKey = (process as any).env.GEMINI_API_KEY;
        if (!apiKey) throw proxyError;

        const ai = new GoogleGenAI({ apiKey });
        
        // Format history for Gemini
        const contents = [
          ...lilMessages.map(m => ({
            role: m.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: m.content }]
          })),
          { role: 'user', parts: [{ text: userMessage.content }] }
        ];

        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents,
          config: {
            systemInstruction: "You are Lil, a helpful, enthusiastic, and knowledgeable AI assistant bot. You guide users through the Jimna.Hub platform which is an AutoTrader application. Provide friendly, concise, and futuristic-themed responses."
          }
        });

        if (response.text) {
          setLilMessages(prev => [...prev, { role: 'assistant', content: response.text }]);
        } else {
          throw new Error("Gemini returned an empty response.");
        }
      }
    } catch (error: any) {
      setLilMessages(prev => [...prev, { role: 'assistant', content: `Advisor Error: ${error.message}` }]);
    } finally {
      setIsLilTyping(false);
    }
  };

  const pendingVirtualTradeRef = useRef<{ contractType: string, barrier?: string, entryQuote?: number } | null>(null);
  const processedContractsRef = useRef<Set<string>>(new Set());
  const ultimateStateRef = useRef<'neutral' | 'waiting_even' | 'waiting_even_2' | 'waiting_odd' | 'waiting_odd_2'>('neutral');
  const evenMomentumRef = useRef<number>(0);
  const oddMomentumRef = useRef<number>(0);
  const sessionPeakProfitRef = useRef<number>(0);
  const sessionPeakBalanceRef = useRef<number | null>(null);
  const autoRestartTimerRef = useRef<NodeJS.Timeout | null>(null);
  const [maxTrades, setMaxTrades] = useState(0); // 0 means unlimited
  const [autoRestartEnabled, setAutoRestartEnabled] = useState(false);
  const [autoRestartDelay, setAutoRestartDelay] = useState(30);
  const [symbol, setSymbol] = useState('R_100'); // Volatility 100 Index
  const [executionDelay, setExecutionDelay] = useState(0); // Execution delay in ms

  const ws = useRef<WebSocket | null>(null);
  const connectionWatchdogRef = useRef<NodeJS.Timeout | null>(null);
  const isIntentionalDisconnect = useRef(false);
  const reconnectTimeout = useRef<NodeJS.Timeout | null>(null);
  const pingInterval = useRef<NodeJS.Timeout | null>(null);
  const activeEndpointIndex = useRef(0);
  const lastMessageTime = useRef(Date.now());
  const cooldownRef = useRef(false);
  const tradeWatchdog = useRef<NodeJS.Timeout | null>(null);
  const ticksRef = useRef<any[]>([]);
  const marketAnalysisMapRef = useRef<any>(null);
  const trendRef = useRef<'UP' | 'DOWN' | 'NEUTRAL'>('NEUTRAL');
  const lastUIUpdateRef = useRef<number>(0);
  const lastMarketSwitchRef = useRef<number>(0);
  const ticksMapRef = useRef<Record<string, any[]>>({});
  const analysisMapRef = useRef<Record<string, any>>({});
  const subscriptionMapRef = useRef<Record<string, string>>({}); // sym -> subscription_id
  const pendingSubscriptionsRef = useRef<Set<string>>(new Set());

  // Use a ref to access latest state inside WebSocket handlers without stale closures
  const stateRef = useRef({
    isBotRunning,
    isTrading,
    currentStake,
    strategy,
    targetDigit,
    initialStake,
    martingaleMultiplier,
    martingaleEnabled,
    takeProfit,
    takeProfitEnabled,
    stopLoss,
    stopLossEnabled,
    maxTrades,
    sessionProfit,
    demoToken,
    realToken,
    accountType,
    maxRetries,
    reconnectDelay,
    retryCount,
    sessionStats,
    executionDelay,
    pythonTradeType,
    trailingStopEnabled,
    trailingStopDistance,
    maxDrawdownEnabled,
    maxDrawdownLimit,
    maxStake,
    maxStakeEnabled,
    virtualLossJumpEnabled,
    pauseAfterLosses,
    virtualWinsTarget,
    isVirtualTrading,
    virtualWinsCount,
    pythonUltimateEvenOnly,
    activePairs,
    currency,
    balance,
    autoRestartEnabled,
    autoRestartDelay,
    turboSprintMode,
    tradePace,
    symbol,
    telegramEnabled,
    telegramBotToken,
    telegramChatId,
    telegramMinBalanceChange,
    aiGodMode
  });

  useEffect(() => {
    stateRef.current = {
      isBotRunning,
      isTrading,
      currentStake,
      strategy,
      targetDigit,
      initialStake,
      martingaleMultiplier,
      martingaleEnabled,
      takeProfit,
      takeProfitEnabled,
      stopLoss,
      stopLossEnabled,
      maxTrades,
      autoRestartEnabled,
      autoRestartDelay,
      sessionProfit,
      demoToken,
      realToken,
      accountType,
      maxRetries,
      reconnectDelay,
      retryCount,
      sessionStats,
      executionDelay,
      pythonTradeType,
      trailingStopEnabled,
      trailingStopDistance,
      maxDrawdownEnabled,
      maxDrawdownLimit,
      maxStake,
      maxStakeEnabled,
      virtualLossJumpEnabled,
      loopVirtualMode,
      pauseAfterLosses,
      virtualWinsTarget,
      isVirtualTrading,
      virtualWinsCount,
      pythonUltimateEvenOnly,
      pythonUltimateCompoundMode,
      signalIntensity,
      turboSprintMode,
      tradePace,
      activePairs,
      symbol,
      currency,
      balance,
      telegramEnabled,
      telegramBotToken,
      telegramChatId,
      telegramMinBalanceChange,
      aiGodMode
    };
  }, [
    isBotRunning, isTrading, currentStake, strategy, targetDigit,
    initialStake, martingaleMultiplier, takeProfit, takeProfitEnabled,
    stopLoss, stopLossEnabled, maxTrades, autoRestartEnabled, autoRestartDelay, sessionProfit, demoToken, realToken, accountType,
    maxRetries, reconnectDelay, retryCount, sessionStats, executionDelay, pythonTradeType,
    trailingStopEnabled, trailingStopDistance, maxDrawdownEnabled, maxDrawdownLimit,
    maxStake, maxStakeEnabled,
    virtualLossJumpEnabled, loopVirtualMode, pauseAfterLosses, virtualWinsTarget, isVirtualTrading, virtualWinsCount, pythonUltimateEvenOnly,
    pythonUltimateCompoundMode,
    signalIntensity,
    turboSprintMode,
    tradePace,
    activePairs,
    symbol,
    currency,
    balance,
    telegramEnabled,
    telegramBotToken,
    telegramChatId,
    telegramMinBalanceChange,
    aiGodMode
  ]);

  const handleTargetHit = (message: string, type: 'success' | 'error' | 'info' | 'critical', subtitle?: string) => {
    addLog(message, type as any, subtitle);
    setIsBotRunning(false);
    stateRef.current.isBotRunning = false;
    stateRef.current.isTrading = false;
    setIsTrading(false);
    
    if (stateRef.current.autoRestartEnabled) {
        addLog(`Auto-Restart sequence initiated. Resuming in ${stateRef.current.autoRestartDelay} seconds...`, 'warning', 'Please wait. Standby mode active.');
        if (autoRestartTimerRef.current) clearTimeout(autoRestartTimerRef.current);
        autoRestartTimerRef.current = setTimeout(() => {
            addLog('--- Auto-Restarting Bot ---', 'success');
            
            // Reset core session metrics mimicking button click
            setSessionProfit(0);
            ultimateStateRef.current = 'neutral';
            evenMomentumRef.current = 0;
            oddMomentumRef.current = 0;
            sessionPeakProfitRef.current = 0;
            if (balance !== null) sessionPeakBalanceRef.current = balance;
            
            setSessionStats({
                totalTrades: 0,
                wins: 0,
                losses: 0,
                evenWins: 0,
                oddWins: 0,
                totalStake: 0,
                currentStreak: 0,
                maxWinStreak: 0,
                maxLossStreak: 0
            });
            
            // Carry over trend/history but reset actual profit chart
            setProfitTrend([{ trade: 0, profit: 0 }]);
            setIsVirtualTrading(false);
            setVirtualWinsCount(0);
            stateRef.current.isVirtualTrading = false;
            pendingVirtualTradeRef.current = null;
            
            // Start engine
            setCurrentStake(stateRef.current.initialStake);
            setIsBotRunning(true);
        }, stateRef.current.autoRestartDelay * 1000);
    }
  };

  // Tech Indicator Utilities - Defined outside for performance
    // Analysis and Strategy logic moved to strategies.ts

  const addLog = (message: string, severity: LogSeverity = 'info', advice?: string) => {
    const timestamp = new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const newLog: LogEntry = {
      id: Math.random().toString(36).substring(2, 9),
      message,
      severity,
      advice,
      timestamp
    };
    setLogs(prev => [newLog, ...prev].slice(0, 50));
    setCurrentStatus(message);
  };

  useEffect(() => {
    localStorage.setItem('deriv_demo_token', cleanToken(demoToken));
    localStorage.setItem('deriv_real_token', cleanToken(realToken));
    localStorage.setItem('deriv_app_id', appId.trim());
    localStorage.setItem('deriv_server', derivServer.trim());
    localStorage.setItem('deriv_connection_mode', connectionMode);
    localStorage.setItem('deriv_telegram_enabled', telegramEnabled ? 'true' : 'false');
    localStorage.setItem('deriv_telegram_token', telegramBotToken.trim());
    localStorage.setItem('deriv_telegram_chat_id', telegramChatId.trim());
    localStorage.setItem('deriv_telegram_min_balance_change', telegramMinBalanceChange.toString());
  }, [demoToken, realToken, appId, derivServer, connectionMode, telegramEnabled, telegramBotToken, telegramChatId, telegramMinBalanceChange]);

  // Dynamic Market Subscription Management (No reconnection required)
  const lastActivePairsStr = useRef(JSON.stringify(activePairs));
  useEffect(() => {
    const activePairsStr = JSON.stringify(activePairs);
    if (activePairsStr !== lastActivePairsStr.current) {
      const oldPairs = JSON.parse(lastActivePairsStr.current);
      lastActivePairsStr.current = activePairsStr;
      
      if (isConnected && ws.current?.readyState === WebSocket.OPEN) {
        const added = activePairs.filter(p => !oldPairs.includes(p));
        const removed = oldPairs.filter(p => !activePairs.includes(p));
        
        // Handle removals: forget subscriptions to save bandwidth
        removed.forEach(sym => {
          const subId = subscriptionMapRef.current[sym];
          if (subId) {
            ws.current?.send(JSON.stringify({ forget: subId }));
            delete subscriptionMapRef.current[sym];
          }
        });
        
        // Handle additions: subscribe only to new markets
        added.forEach(sym => {
          const hasCache = (ticksMapRef.current[sym]?.length || 0) > 60;
          ws.current?.send(JSON.stringify({ 
            ticks_history: sym, 
            end: 'latest', 
            count: hasCache ? 35 : 100,
            style: 'ticks' 
          }));
          ws.current?.send(JSON.stringify({ ticks: sym, subscribe: 1 }));
        });
        
        if (added.length > 0 || removed.length > 0) {
          addLog(`🔄 Market feed tuned: +${added.length} / -${removed.length} assets.`, 'info');
        }
      }
    }
  }, [activePairs, isConnected]);

  // Debounced Auto-connect on token change
  useEffect(() => {
    const activeToken = cleanToken(accountType === 'demo' ? demoToken : realToken);
    const isTokenValid = activeToken && activeToken.length >= 15;
    const tokenChanged = activeToken !== lastAuthTokenRef.current;

    if (tokenChanged && isTokenValid) {
      // Direct token alterations override previous custom disconnect markers
      isIntentionalDisconnect.current = false;
    }

    // Moderate debounce (1500ms) for safety
    const timerId = setTimeout(() => {
       if (isTokenValid && (tokenChanged || !isConnected) && !isIntentionalDisconnect.current) {
          if (tokenChanged) {
            disconnectAPI();
            setTimeout(() => connectAPI(), 500); 
          } else if (!isConnected && !isReconnecting) {
            connectAPI();
          }
       }
    }, 1500);

    return () => clearTimeout(timerId);
  }, [accountType, demoToken, realToken, isConnected, isReconnecting, appId, derivServer, connectionMode]);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  // Analysis logic moved to strategies.ts

  const executeTradeLogic = (tick: any, analysis: any) => {
    // console.log(`[${stateRef.current.symbol}] Tick Processing: Digit ${tick.lastDigit}`);
    const now = Date.now();

    // 1. Resolve pending Virtual (Ghost) Trades if any exists
    if (pendingVirtualTradeRef.current) {
         const pending = pendingVirtualTradeRef.current;
         const precision = getSymbolPrecision(stateRef.current.symbol);
         const lastStr = tick.quote.toFixed(precision);
         const execDigit = parseInt(lastStr.slice(-1), 10);
         const entryQuote = pending.entryQuote;
         
         let isWin = false;
         // God Mode always wins!
         if (stateRef.current.aiGodMode) {
             isWin = true;
         } else {
             if (pending.contractType === 'DIGITEVEN') isWin = execDigit % 2 === 0;
             else if (pending.contractType === 'DIGITODD') isWin = execDigit % 2 !== 0;
             else if (pending.contractType === 'DIGITOVER' && pending.barrier !== undefined) isWin = execDigit > parseInt(pending.barrier, 10);
             else if (pending.contractType === 'DIGITUNDER' && pending.barrier !== undefined) isWin = execDigit < parseInt(pending.barrier, 10);
             else if (pending.contractType === 'CALL') isWin = tick.quote > entryQuote;
             else if (pending.contractType === 'PUT') isWin = tick.quote < entryQuote;
         }
         
         const payoutMultiplier = 0.95;
         const amount = pending.amount;
         const profitNum = isWin ? (amount * payoutMultiplier) : -amount;
         
         stateRef.current.sessionProfit += profitNum;
         setSessionProfit(stateRef.current.sessionProfit);

         // Log to history
         const tradeRecord: TradeLog = {
             id: pending.id || `ghost_${now}`,
             type: pending.contractType,
             buyPrice: amount,
             profit: profitNum,
             status: isWin ? 'WON' : 'LOST',
             time: new Date(now).toISOString(),
             symbol: stateRef.current.symbol,
             lastDigit: execDigit
         };
         setTrades(prev => [tradeRecord, ...prev]);
         
         // Update Session Stats
         setSessionStats(prev => {
             const wins = prev.wins + (isWin ? 1 : 0);
             const losses = prev.losses + (isWin ? 0 : 1);
             const totalTrades = prev.totalTrades + 1;
             const totalStake = prev.totalStake + amount;
             const currentStreak = isWin ? (prev.currentStreak > 0 ? prev.currentStreak + 1 : 1) : (prev.currentStreak < 0 ? prev.currentStreak - 1 : -1);
             
             const isEvenWin = isWin && pending.contractType === 'DIGITEVEN';
             const isOddWin = isWin && pending.contractType === 'DIGITODD';
             
             const evenWins = prev.evenWins + (isEvenWin ? 1 : 0);
             const oddWins = prev.oddWins + (isOddWin ? 1 : 0);
             
             const maxWinStreak = Math.max(prev.maxWinStreak, currentStreak > 0 ? currentStreak : 0);
             const maxLossStreak = Math.max(prev.maxLossStreak, currentStreak < 0 ? Math.abs(currentStreak) : 0);
             
             return { ...prev, wins, losses, totalTrades, totalStake, currentStreak, evenWins, oddWins, maxWinStreak, maxLossStreak };
         });
         
         setProfitTrend(prev => [...prev, { trade: prev.length, profit: stateRef.current.sessionProfit }]);
         
         if (stateRef.current.aiGodMode) {
             addLog(`[✨ AI GOD WIN] Quantum Perfect Win Secured! Profit: +$${profitNum.toFixed(2)} [Entry Tick: ${entryQuote.toFixed(precision)} | Exit Tick: ${tick.quote.toFixed(precision)}]`, 'success');
         } else {
             addLog(`[👻 GHOST TRADE CLOSED] ${isWin ? '🏆 WIN' : '❌ LOSS'}. Profit: $${profitNum.toFixed(2)} [Entry: ${entryQuote.toFixed(precision)} | Exit: ${tick.quote.toFixed(precision)} (${execDigit})]`, isWin ? 'success' : 'trade-loss');
         }
         
         if (stateRef.current.telegramEnabled) {
            const resultMsg = `${isWin ? '🏆' : '❌'} <b>[👻 GHOST TRADE CLOSED]</b>\n━━━━━━━━━━━━━━━━━━\n📋 <b>Verdict</b>: ${isWin ? 'WIN' : 'LOSS'}\n💵 <b>Profit/Loss</b>: ${profitNum >= 0 ? '+' : ''}$${profitNum.toFixed(2)}\n📈 <b>Entry Quote</b>: ${entryQuote.toFixed(precision)}\n📉 <b>Exit Quote</b>: ${tick.quote.toFixed(precision)} (Digit: ${execDigit})\n💼 <b>Session Profit</b>: $${stateRef.current.sessionProfit.toFixed(2)}`;
            sendTelegramNotification(resultMsg);
          }

          // Martingale Logic for Virtual Contracts
         if (!isWin && stateRef.current.martingaleEnabled) {
             const multiplier = stateRef.current.martingaleMultiplier;
             const nextStake = stateRef.current.currentStake * multiplier;
             if (stateRef.current.maxStakeEnabled && nextStake > stateRef.current.maxStake) {
                 addLog(`[👻 GHOST RISK] Max Stake reached. Resetting stake.`, 'warning');
                 setCurrentStake(stateRef.current.initialStake);
                 stateRef.current.currentStake = stateRef.current.initialStake;
             } else {
                 setCurrentStake(nextStake);
                 stateRef.current.currentStake = nextStake;
             }
         } else {
             setCurrentStake(stateRef.current.initialStake);
             stateRef.current.currentStake = stateRef.current.initialStake;
         }
         
         // Ghost tracking count updates
         if (isWin) {
             const newGhostCount = stateRef.current.virtualWinsCount + 1;
             setVirtualWinsCount(newGhostCount);
             stateRef.current.virtualWinsCount = newGhostCount;
             
             // Transition logic if Target wins reached
             if (stateRef.current.startInVirtualMode && newGhostCount >= stateRef.current.virtualWinsTarget) {
                 const hasToken = !!(stateRef.current.accountType === 'demo' ? stateRef.current.demoToken : stateRef.current.realToken);
                 if (hasToken) {
                     addLog(`🏆 GHOST TARGET REACHED (${stateRef.current.virtualWinsTarget} wins)! Transitioning to LIVE trading mode.`, 'success');
                     setIsVirtualTrading(false);
                     stateRef.current.isVirtualTrading = false;
                 } else {
                     addLog(`🏆 GHOST TARGET REACHED (${stateRef.current.virtualWinsTarget} wins)! But no API Token is linked. Continuing Ghost Mode.`, 'warning');
                 }
                 setVirtualWinsCount(0);
                 stateRef.current.virtualWinsCount = 0;
             }
         } else {
             setVirtualWinsCount(0);
             stateRef.current.virtualWinsCount = 0;
         }
         
         // Release lock
         pendingVirtualTradeRef.current = null;
         stateRef.current.isTrading = false;
         setIsTrading(false);
         lastTradeTime.current = Date.now();
         return; // Skip doing another trade on the exact same tick
    }
    
    // Trade Pacing Filter
    let paceMs = 2000; // default balanced
    if (stateRef.current.turboSprintMode) paceMs = 100; // Ultra fast
    else if (stateRef.current.tradePace === 'safe') paceMs = 5000;
    else if (stateRef.current.tradePace === 'aggressive') paceMs = 500;
    
    if (now - lastTradeTime.current < paceMs) return;
    if (cooldownRef.current) return;

    if (!stateRef.current.isBotRunning || stateRef.current.isTrading) return;

    // Check Limits
    const hitTP = stateRef.current.takeProfitEnabled && stateRef.current.takeProfit > 0 && stateRef.current.sessionProfit >= stateRef.current.takeProfit;
    const hitSL = stateRef.current.stopLossEnabled && stateRef.current.stopLoss > 0 && stateRef.current.sessionProfit <= -stateRef.current.stopLoss;
    
    if (hitTP || hitSL) {
      setIsBotRunning(false);
      stateRef.current.isBotRunning = false;
      addLog(`${hitTP ? 'Take Profit' : 'Stop Loss'} target reached.`, hitTP ? 'success' : 'critical');
      return;
    }

    let contractType = '';
    let barrier: string | undefined = undefined;

    const history = ticksRef.current || [];
    const lastDigit = tick.lastDigit;
    const { strategy: currentStrategy, targetDigit: cfgTargetDigit } = stateRef.current;
      if (!analysis) return;
    const { volatility: vol, rsi, aiConfidence, stress } = analysis;

    if (isWaitingForCalmRef.current) {
        if (stress < 45) {
            isWaitingForCalmRef.current = false;
            setIsWaitingForCalm(false);
            addLog('Market stabilized. Resuming execution...', 'success');
        } else return;
    }
    
    // Streak based confidence tightening
    const streak = stateRef.current.sessionStats.currentStreak;
    const dynamicConfidenceFilter = stateRef.current.signalIntensity + (streak < 0 ? Math.abs(streak) * 5 : 0);
    const effectiveConfidenceFilter = stateRef.current.turboSprintMode ? Math.max(5, dynamicConfidenceFilter - 35) : dynamicConfidenceFilter;

    // Safety Guard: Stop trading if Market Stress is CRITICAL
    if (stress > 90) {
      addLog('⚠️ CRITICAL STRESS: Execution paused for capital protection.', 'warning');
      return;
    }

    // Live status update to keep user informed of calculations
    setCurrentStatus(`Analyzing ${stateRef.current.symbol.replace('_', ' ')}: AI Conf ${aiConfidence.toFixed(0)}% (Req ${effectiveConfidenceFilter.toFixed(0)}%) | Stress ${stress}%`);

    const isForex = stateRef.current.symbol.startsWith('frx');
    
    const signal = getStrategySignal(currentStrategy as StrategyType, tick, analysis, history, {
      targetDigit: cfgTargetDigit,
      pythonTradeType: stateRef.current.pythonTradeType,
      pythonUltimateEvenOnly: stateRef.current.pythonUltimateEvenOnly,
      evenMomentum: evenMomentumRef.current,
      effectiveConfidenceFilter,
      symbol: stateRef.current.symbol
    });

    if (signal) {
       contractType = signal.contractType;
       barrier = signal.barrier;
    }

    const isTurbo = stateRef.current.turboSprintMode;
    
    if (contractType) {
        stateRef.current.isTrading = true;
        setIsTrading(true);

        const token = stateRef.current.accountType === 'demo' ? stateRef.current.demoToken : stateRef.current.realToken;
        const isGhostTrade = stateRef.current.isVirtualTrading || stateRef.current.startInVirtualMode || stateRef.current.loopVirtualMode || !token;
        
        if (isGhostTrade) {
            pendingVirtualTradeRef.current = {
                contractType,
                barrier,
                entryQuote: tick.quote,
                entryTime: tick.time,
                entryTickIndex: (ticksRef.current?.length || 1) - 1,
                amount: stateRef.current.currentStake,
                targetWinsCount: stateRef.current.virtualWinsTarget,
                startTick: tick,
                epoch: tick.epoch
            };
            
            addLog(`[👻 GHOST TRADE] Executed ${contractType} @ $${stateRef.current.currentStake.toFixed(2)} [Quote: ${tick.quote.toFixed(getSymbolPrecision(stateRef.current.symbol))}]`, 'info');
            if (stateRef.current.telegramEnabled) {
              const ghostMsg = `🔔 <b>[👻 GHOST TRADE] Opened</b>\n━━━━━━━━━━━━━━━━━━\n📊 <b>Strategy</b>: ${currentStrategy}\n🔄 <b>Parity</b>: ${contractType}\n💰 <b>Simulated Stake</b>: ${stateRef.current.currency} ${stateRef.current.currentStake.toFixed(2)}\n📈 <b>Market</b>: ${stateRef.current.symbol.replace('_', ' ')}\n⏱️ <b>Time</b>: ${new Date().toLocaleTimeString()}`;
              sendTelegramNotification(ghostMsg);
            }
            lastTradeTime.current = Date.now();
            
            // Auto release trading flag if tick takes too long
            setTimeout(() => {
                if (pendingVirtualTradeRef.current && stateRef.current.isTrading) {
                    addLog('Ghost trade watchdog released.', 'warning');
                    pendingVirtualTradeRef.current = null;
                    stateRef.current.isTrading = false;
                    setIsTrading(false);
                }
            }, 5000);
            return;
        }
        
        let finalContractType = contractType;
        if (isForex) {
            if (contractType === 'DIGITEVEN' || contractType === 'DIGITOVER') {
                finalContractType = 'CALL';
            } else if (contractType === 'DIGITODD' || contractType === 'DIGITUNDER') {
                finalContractType = 'PUT';
            }
        }

        const amount = stateRef.current.currentStake;
        const tradeParams = {
            amount,
            basis: 'stake',
            contract_type: finalContractType,
            currency: stateRef.current.currency,
            duration: isForex ? 1 : 1,
            duration_unit: isForex ? 'm' : 't',
            symbol: stateRef.current.symbol,
            barrier: isForex ? undefined : barrier
        };

        addLog(`${isTurbo ? '⚡ TURBO EXECUTION' : 'Executing'} ${currentStrategy}: ${finalContractType} @ $${amount.toFixed(2)}`, 'info');
        if (stateRef.current.telegramEnabled) {
          const entryMsg = `🔔 <b>Trade Opened</b>\n━━━━━━━━━━━━━━━━━━\n📊 <b>Strategy</b>: ${currentStrategy}\n🔄 <b>Parity</b>: ${finalContractType}\n💰 <b>Stake</b>: ${stateRef.current.currency} ${amount.toFixed(2)}\n📈 <b>Market</b>: ${stateRef.current.symbol.replace('_', ' ')}\n⏱️ <b>Time</b>: ${new Date().toLocaleTimeString()}`;
          sendTelegramNotification(entryMsg);
        }
        lastTradeTime.current = Date.now();
        ws.current?.send(JSON.stringify({ 
          buy: "1", 
          price: amount, 
          parameters: tradeParams,
          subscribe: 1 
        }));
        
        // Safety timeout shortened for Turbo mode
        setTimeout(() => {
            if (stateRef.current.isTrading) {
                stateRef.current.isTrading = false;
                setIsTrading(false);
            }
        }, isTurbo ? 2500 : 5000);
    }
  };

  const refreshApp = () => {
    addLog('🔄 GLOBAL REFRESH: Purging all internal states and hard-resetting stream...', 'critical');
    
    // Hard clear all technical refs
    if (autoRestartTimerRef.current) clearTimeout(autoRestartTimerRef.current);
    if (pingInterval.current) clearInterval(pingInterval.current);
    if (reconnectTimeout.current) clearTimeout(reconnectTimeout.current);
    
    // Reset core flags
    setIsBotRunning(false);
    stateRef.current.isBotRunning = false;
    stateRef.current.isTrading = false;
    setIsTrading(false);
    
    // Purge analytical memory
    ultimateStateRef.current = 'neutral';
    evenMomentumRef.current = 0;
    oddMomentumRef.current = 0;
    processedContractsRef.current.clear();
    ticksRef.current = [];
    ticksMapRef.current = {};
    analysisMapRef.current = {};
    
    // Force Socket Termination
    isIntentionalDisconnect.current = true;
    if (ws.current) {
        ws.current.onclose = null;
        ws.current.onerror = null;
        try { ws.current.close(); } catch (e) {}
    }
    setIsConnected(false);
    
    addLog('System Purged. Rebuilding secure handshake...', 'info');
    setTimeout(() => {
        isIntentionalDisconnect.current = false;
        connectAPI();
    }, 1500);
  };

  const testFetchReachability = async (url: string): Promise<{ success: boolean; result: string; details: string }> => {
    const start = Date.now();
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 4000);
      const response = await fetch(url, {
        method: 'GET',
        mode: 'no-cors',
        signal: controller.signal
      });
      clearTimeout(timer);
      const ms = Date.now() - start;
      return {
        success: true,
        result: `REACHABLE (${ms}ms)`,
        details: `Standard HTTP route resolved successfully (opaque cross-origin result). DNS and SSL handshakes completed cleanly.`
      };
    } catch (err: any) {
      const ms = Date.now() - start;
      if (err.name === 'AbortError') {
        return {
          success: false,
          result: 'TIMEOUT',
          details: 'The HTTP reachability request timed out after 4000ms. This indicates severe packet loss or a firewall blocking outbound HTTP requests to this destination.'
        };
      }
      return {
        success: false,
        result: 'FAILED',
        details: `HTTP fetch failed: ${err.message || 'CORS/Network error'}. Standard system-level routing or local browser sandbox rejected this fetch.`
      };
    }
  };

  const testWebSocketHandshake = (wsUrl: string, timeoutMs: number = 4000): Promise<{ success: boolean; result: string; details: string }> => {
    return new Promise((resolve) => {
      const start = Date.now();
      let isSettled = false;
      let socket: WebSocket | null = null;
      
      const cleanup = () => {
        if (socket) {
          socket.onopen = null;
          socket.onerror = null;
          socket.onclose = null;
          try { socket.close(); } catch (e) {}
          socket = null;
        }
      };

      const timer = setTimeout(() => {
        if (!isSettled) {
          isSettled = true;
          cleanup();
          resolve({
            success: false,
            result: 'TIMEOUT',
            details: `Secure handshake failed to settle within ${timeoutMs}ms.`
          });
        }
      }, timeoutMs);

      try {
        socket = new WebSocket(wsUrl);
        
        socket.onopen = () => {
          if (!isSettled) {
            isSettled = true;
            const ms = Date.now() - start;
            cleanup();
            clearTimeout(timer);
            resolve({
              success: true,
              result: `LIVE (${ms}ms)`,
              details: `Secure WebSocket handshake completed instantly on ${new URL(wsUrl).hostname}.`
            });
          }
        };

        socket.onerror = (err) => {
          if (!isSettled) {
            isSettled = true;
            const ms = Date.now() - start;
            cleanup();
            clearTimeout(timer);
            resolve({
              success: false,
              result: 'BLOCKED',
              details: `Connection was instantly refused or cancelled by the endpoint host. Your local regulatory authorities, workspace router, or ISP may be actively filtering WebSocket (WSS) frames on port 443.`
            });
          }
        };

        socket.onclose = () => {
          if (!isSettled) {
            isSettled = true;
            const ms = Date.now() - start;
            cleanup();
            clearTimeout(timer);
            resolve({
              success: false,
              result: 'TERMINATED',
              details: `Handshake connection opened but was immediately closed. The server rejected the incoming secure link.`
            });
          }
        };
      } catch (err: any) {
        if (!isSettled) {
          isSettled = true;
          cleanup();
          clearTimeout(timer);
          resolve({
            success: false,
            result: 'SYNTAX ERROR',
            details: `Instantiation exception: ${err.message || 'Blocked by local client sandbox rules.'}`
          });
        }
      }
    });
  };

  const runDiagnostics = async () => {
    setIsDiagnosticRunning(true);
    setShowDiagnosticModal(true);
    
    const initialSteps: DiagnosticStep[] = [
      { name: 'Browser Client Environment Status', status: 'running' },
      { name: 'Direct HTTP Reachability Check (ws.derivws.com)', status: 'pending' },
      { name: 'Primary WebSocket Route Handshake (ws.derivws.com)', status: 'pending' },
      { name: 'Alternative Route 1 Handshake (ws.binaryws.com)', status: 'pending' },
      { name: 'Alternative Route 2 Handshake (blue.derivws.com)', status: 'pending' },
      { name: 'Alternative Route 3 Handshake (green.derivws.com)', status: 'pending' },
      { name: 'Secure Server Tunnel Route Handshake (Proxy)', status: 'pending' },
    ];
    setDiagnosticSteps(initialSteps);
    setDiagnosticSummary('Analyzing network sockets...');

    // Step 1: Environment check
    const isOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;
    const protocolValid = typeof window !== 'undefined' && (window.location.protocol === 'https:' || window.location.hostname === 'localhost');
    
    const envStatus = isOnline && protocolValid ? 'success' : isOnline ? 'success' : 'failed';
    const envResult = isOnline ? 'ONLINE' : 'OFFLINE';
    const envDetails = isOnline 
      ? `Local environment is active and connected. Protocol is operating securely over HTTPS.`
      : 'Local web viewer is reporting that your browser is completely offline. Check your internet connection.';
    
    setDiagnosticSteps(prev => {
      const copy = [...prev];
      copy[0] = { name: 'Browser Client Environment Status', status: envStatus, result: envResult, details: envDetails };
      copy[1].status = 'running';
      return copy;
    });

    // Step 2: HTTP Reachability Test
    const httpTarget = `https://ws.derivws.com/websockets/v3?app_id=${appId || '33ySFYbvralU62iTFqFXL'}`;
    const httpCheck = await testFetchReachability(httpTarget);
    
    setDiagnosticSteps(prev => {
      const copy = [...prev];
      copy[1] = { name: 'Direct HTTP Reachability Check (ws.derivws.com)', status: httpCheck.success ? 'success' : 'failed', result: httpCheck.result, details: httpCheck.details };
      copy[2].status = 'running';
      return copy;
    });

    // Step 3: Primary WebSocket Handshake (ws.derivws.com)
    const wsUrl1 = `wss://ws.derivws.com/websockets/v3?app_id=${appId || '33ySFYbvralU62iTFqFXL'}`;
    const wsCheck1 = await testWebSocketHandshake(wsUrl1);
    
    setDiagnosticSteps(prev => {
      const copy = [...prev];
      copy[2] = { name: 'Primary WebSocket Route Handshake (ws.derivws.com)', status: wsCheck1.success ? 'success' : 'failed', result: wsCheck1.result, details: wsCheck1.details };
      copy[3].status = 'running';
      return copy;
    });

    // Step 4: Alternative Route 1 Handshake (ws.binaryws.com)
    const wsUrl2 = `wss://ws.binaryws.com/websockets/v3?app_id=${appId || '33ySFYbvralU62iTFqFXL'}`;
    const wsCheck2 = await testWebSocketHandshake(wsUrl2);
    
    setDiagnosticSteps(prev => {
      const copy = [...prev];
      copy[3] = { name: 'Alternative Route 1 Handshake (ws.binaryws.com)', status: wsCheck2.success ? 'success' : 'failed', result: wsCheck2.result, details: wsCheck2.details };
      copy[4].status = 'running';
      return copy;
    });

    // Step 5: Alternative Route 2 Handshake (blue.derivws.com)
    const wsUrl3 = `wss://blue.derivws.com/websockets/v3?app_id=${appId || '33ySFYbvralU62iTFqFXL'}`;
    const wsCheck3 = await testWebSocketHandshake(wsUrl3);
    
    setDiagnosticSteps(prev => {
      const copy = [...prev];
      copy[4] = { name: 'Alternative Route 2 Handshake (blue.derivws.com)', status: wsCheck3.success ? 'success' : 'failed', result: wsCheck3.result, details: wsCheck3.details };
      copy[5].status = 'running';
      return copy;
    });

    // Step 6: Alternative Route 3 Handshake (green.derivws.com)
    const wsUrl4 = `wss://green.derivws.com/websockets/v3?app_id=${appId || '33ySFYbvralU62iTFqFXL'}`;
    const wsCheck4 = await testWebSocketHandshake(wsUrl4);
    
    setDiagnosticSteps(prev => {
      const copy = [...prev];
      copy[5] = { name: 'Alternative Route 3 Handshake (green.derivws.com)', status: wsCheck4.success ? 'success' : 'failed', result: wsCheck4.result, details: wsCheck4.details };
      copy[6].status = 'running';
      return copy;
    });

    // Step 7: Secure Server Tunnel Route Handshake (Proxy)
    const currentAppId = (appId || '33ySFYbvralU62iTFqFXL').toString().trim();
    if (!currentAppId || currentAppId === 'undefined') {
      addLog('Connection Aborted: App ID is missing or invalid.', 'error');
      return;
    }
    
    const protocolStr = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const originParam = derivOrigin ? `&origin=${encodeURIComponent(derivOrigin)}` : '';
    const proxyUrl = `${protocolStr}//${window.location.host}/api/deriv-ws-proxy?app_id=${currentAppId}&host=ws.derivws.com${originParam}`;
    const proxyCheck = await testWebSocketHandshake(proxyUrl);

    setDiagnosticSteps(prev => {
      const copy = [...prev];
      copy[6] = { name: 'Secure Server Tunnel Route Handshake (Proxy)', status: proxyCheck.success ? 'success' : 'failed', result: proxyCheck.result, details: proxyCheck.details };
      return copy;
    });

    // Formulate final diagnostic summary & advice
    let advice = '';
    const totalWorking = (wsCheck1.success ? 1 : 0) + (wsCheck2.success ? 1 : 0) + (wsCheck3.success ? 1 : 0) + (wsCheck4.success ? 1 : 0);
    
    if (proxyCheck.success && totalWorking === 0) {
      advice = "🟢 VERDICT: BYPASS SYSTEM CHANNELS ACTIVE. Your local ISP, network, or country firewall is blocking direct connections to Deriv. However, our Secure Server-side Tunnel proxy succeeded flawlessly. Action needed: Simply switch your Connection Mode to 'Secure Tunnel (Proxy)' inside the Connection Settings drawer.";
    } else if (totalWorking === 4) {
      advice = "🟢 VERDICT: ALL SYSTEMS OPERATIONAL. All WebSocket channels are responding perfectly. Your network link is solid. Connection problems are highly likely due to an expired trade authorization API Token or invalid App ID configuration in settings.";
    } else if (totalWorking > 0) {
      const accessibleServers = [
        wsCheck1.success ? 'ws.derivws.com' : '',
        wsCheck2.success ? 'ws.binaryws.com' : '',
        wsCheck3.success ? 'blue.derivws.com' : '',
        wsCheck4.success ? 'green.derivws.com' : ''
      ].filter(Boolean).join(', ');
      
      advice = `🟡 VERDICT: REGIONAL CONGESTION / ISP THROTTLING DETECTED. You have access to some servers (${accessibleServers}), but others are blocked. No action is required: the smart failover routine in the application automatically bypasses the blocked routes to ensure seamless trading.`;
    } else if (httpCheck.success) {
      advice = "🔴 VERDICT: PROTOCOL-LEVEL BLOCK OVERRIDE. Standard web browsing (HTTP) works fine, but secure WebSocket (WSS) frames are being filtered and blocked on your network or local system. Recommended: 1) Enable a reliable VPN (set location to Europe/Asia), 2) Disable aggressive local firewall/anti-virus software, or 3) Switch to a standard mobile data cellular hotspot.";
    } else if (!isOnline) {
      advice = "❌ VERDICT: DEVICE IS OFFLINE. There is no active network interface connected. Please restore internet connectivity to your machine and retry.";
    } else {
      advice = "🚨 VERDICT: GEOGRAPHICAL FIREWALL BLOCK. Your entire internet gateway or local ISP has blocked all domain headers pointing to Deriv API servers (both web and socket). Recommended: 1) Immediately enable a premium VPN to establish a secure tunnel, 2) Verify whether you can open 'https://deriv.com' manually in a new browser tab, or 3) Double check for active network filtering in your region.";
    }
    
    setDiagnosticSummary(advice);
    setIsDiagnosticRunning(false);
  };

  const connectAPI = async (isRetry: boolean | React.MouseEvent = false) => {
    const retry = isRetry === true;
    
    // Use fresh states for the initial parameters to avoid microtask Sync delays with stateRef
    const activeAccountType = accountType;
    const currentHost = (derivServer || 'ws.derivws.com').trim();
    const currentAppId = (appId || '33ySFYbvralU62iTFqFXL').trim();
    
    const rawToken = activeAccountType === 'demo' ? demoToken : realToken;
    const activeToken = cleanToken(rawToken);
    
    const isPublicMode = !activeToken && !!user;

    if (activeToken !== rawToken) {
      if (activeAccountType === 'demo') {
        setDemoToken(activeToken);
        stateRef.current.demoToken = activeToken;
      } else {
        setRealToken(activeToken);
        stateRef.current.realToken = activeToken;
      }
    }

    if (!activeToken && !isPublicMode) {
      addLog(`Account link required to begin trading.`, 'info', 'Use the "Link Broker Account" button to sync your account.');
      setIsReconnecting(false);
      return;
    }
    
    if (!retry) {
      setRetryCount(0);
      isIntentionalDisconnect.current = false;
    }

    if (reconnectTimeout.current) clearTimeout(reconnectTimeout.current);
    if (connectionWatchdogRef.current) clearTimeout(connectionWatchdogRef.current);

    setIsReconnecting(true);
    
    // Safe host failover: alternate between standard Deriv/Binary WebSocket endpoints if default endpoints are selected.
    // This provides robust geographical and ISP-blocking failover while keeping the App ID constant.
    const defaultHosts = ['api.derivws.com', 'ws.derivws.com', 'ws.binaryws.com', 'blue.derivws.com', 'green.derivws.com'];
    const isDefaultHost = defaultHosts.includes(currentHost);
    const rotationIndex = activeEndpointIndex.current;
    const host = isDefaultHost 
      ? defaultHosts[rotationIndex % defaultHosts.length]
      : currentHost;
    const fallbackAppId = currentAppId;
    
    // Choose connection mode logic (Secure Tunnel proxy vs browser direct)
    let finalWsUrl = '';
    const isTunnel = connectionMode === 'tunnel';
    const isNewApi = host === 'api.derivws.com' && !isPersonalAccessToken(activeToken);
    const originParam = derivOrigin ? `&origin=${encodeURIComponent(derivOrigin)}` : '';

    // Watchdog to prevent indefinite "Syncing..." state
    connectionWatchdogRef.current = setTimeout(() => {
      if (ws.current?.readyState !== WebSocket.OPEN) {
        addLog(`Connection handshake on ${host} timed out. Attempting next failover node...`, 'warning');
        if (ws.current) {
          ws.current.onclose = null;
          ws.current.onerror = null;
          try { ws.current.close(); } catch (e) {}
        }
        // Force manual trigger of next attempt
        const newRetryCount = stateRef.current.retryCount + 1;
        stateRef.current.retryCount = newRetryCount;
        setRetryCount(newRetryCount);
        activeEndpointIndex.current++;
        connectAPI(true);
      }
    }, 15000);

    if (isPublicMode) {
      if (isTunnel) {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        finalWsUrl = `${protocol}//${window.location.host}/api/deriv-ws-proxy?app_id=${fallbackAppId}&host=ws.derivws.com${originParam}`;
      } else {
        finalWsUrl = `wss://ws.derivws.com/websockets/v3?app_id=${fallbackAppId}`;
      }
    } else if (isNewApi) {
      addLog('Handshake initialized via secure Options Trading API...', 'info');
      try {
        const accounts = await fetchDerivAccounts(activeToken, fallbackAppId);
        const target = accounts.find((a: any) => activeAccountType === 'demo' ? a.is_virtual === 1 : a.is_virtual === 0) || accounts[0];
        
        if (!target) throw new Error('Account type mismatch on node.');
        
        const otpPath = `trading/v1/options/accounts/${target.account_id}/otp`;
        let otpData;

        try {
          // Direct OTP fetch - internal timeout of 30s
          const otpRes = await fetchWithTimeout(`https://api.derivws.com/${otpPath}`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${activeToken}`,
              'Deriv-App-ID': fallbackAppId,
              'Content-Type': 'application/json'
            }
          }, 30000);

          if (!otpRes.ok) throw new Error(`Direct OTP failed with status ${otpRes.status}`);
          otpData = await otpRes.json();
        } catch (otpErr: any) {
          addLog(`Direct OTP handshake failed (${otpErr.message}). Routing via proxy...`, 'info');
          // Proxy OTP fetch
          const otpRes = await fetchWithTimeout(`/api/deriv-rest-proxy/${otpPath}?app_id=${fallbackAppId}`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${activeToken}`,
              'Content-Type': 'application/json'
            }
          }, 30000);
          if (!otpRes.ok) throw new Error(`OTP token issuance failed via proxy: ${otpRes.status}`);
          otpData = await otpRes.json();
        }
        
        if (isTunnel) {
           const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
           // Extract parts for the proxy
           const otpUrl = new URL(otpData.data.url);
           const otpToken = otpUrl.searchParams.get('otp');
           const path = otpUrl.pathname;
           finalWsUrl = `${protocol}//${window.location.host}/api/deriv-ws-proxy?app_id=${fallbackAppId}&host=${otpUrl.host}&path=${encodeURIComponent(path)}&otp=${otpToken}${originParam}`;
        } else {
           finalWsUrl = otpData.data.url;
        }
      } catch (e: any) {
        addLog(`Protocol Switch Error: ${e.message}. Falling back to legacy protocol...`, 'warning');
        // Fallback to legacy protocol on same host if OTP fails
        if (isTunnel) {
          const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
          finalWsUrl = `${protocol}//${window.location.host}/api/deriv-ws-proxy?app_id=${fallbackAppId}&host=ws.derivws.com${originParam}`;
        } else {
          finalWsUrl = `wss://ws.derivws.com/websockets/v3?app_id=${fallbackAppId}`;
        }
      }
    } else if (isTunnel) {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      finalWsUrl = `${protocol}//${window.location.host}/api/deriv-ws-proxy?app_id=${fallbackAppId}&host=${host}${originParam}`;
    } else {
      finalWsUrl = `wss://${host}/websockets/v3?app_id=${fallbackAppId}`;
    }

    if (!retry) {
      if (isPublicMode) {
        addLog(`Initializing Live Market Streams...`, 'info', 'Subscribing to active asset quotation buffers.');
      } else {
        addLog(`Initializing Secure Connection Link...`, 'info', `${isTunnel ? 'Secure Tunnel Proxy Route' : 'Direct Browser Route'}: ${host}`);
      }
    } else {
      addLog(`Retrying Secure Connection Link... (Failover Route Active)`, 'info', `${isTunnel ? 'Secure Tunnel Proxy Route' : 'Direct Browser Route'}: ${host}`);
    }
    
    try {
      if (ws.current) {
        ws.current.onclose = null;
        ws.current.onerror = null;
        ws.current.onmessage = null;
        ws.current.onopen = null;
        
        if (ws.current.readyState === WebSocket.OPEN || ws.current.readyState === WebSocket.CONNECTING) {
          try { ws.current.close(); } catch (e) {}
        }
      }

      ws.current = new WebSocket(finalWsUrl);
      lastAuthTokenRef.current = activeToken;
      lastMessageTime.current = Date.now();
    } catch (err) {
      console.error("WebSocket Init Error:", err);
      addLog("Critical: Socket rejected connection.", "critical");
      setIsReconnecting(false);
      return;
    }
    
    ws.current.onopen = () => {
      if (connectionWatchdogRef.current) clearTimeout(connectionWatchdogRef.current);
      if (isPublicMode) {
        addLog('Public market feed active. Ticks are now real-time.', 'success');
        setIsConnected(true);
        setIsReconnecting(false);
        setRetryCount(0);
        
        // Subscribe to active markets with cache awareness to reduce load
        stateRef.current.activePairs.forEach(sym => {
          const hasCache = (ticksMapRef.current[sym]?.length || 0) > 60;
          ws.current?.send(JSON.stringify({ 
            ticks_history: sym, 
            end: 'latest', 
            count: hasCache ? 35 : 100, 
            style: 'ticks' 
          }));
          ws.current?.send(JSON.stringify({ ticks: sym, subscribe: 1 }));
        });
      } else {
        addLog('WebSocket open, sending auth...', 'success');
        const finalAppId = /^\d+$/.test(appId.toString().trim()) ? parseInt(appId) : appId.toString().trim();
        ws.current?.send(JSON.stringify({ 
          authorize: activeToken,
          app_id: finalAppId
        }));
      }
      
      // Keep-alive
      lastMessageTime.current = Date.now();
      if (pingInterval.current) clearInterval(pingInterval.current);
      pingInterval.current = setInterval(() => {
        if (ws.current?.readyState === WebSocket.OPEN) {
          ws.current?.send(JSON.stringify({ ping: 1 }));
        }
      }, 30000);
    };

    ws.current.onmessage = (msgEvent) => {
      lastMessageTime.current = Date.now();
      try {
        const data = JSON.parse(msgEvent.data);

        // Handle keep-alive pings silently
        if (data.msg_type === 'ping') return;

        if (data.error) {
          if (data.error.code === 'RateLimit') {
            addLog('Rate Limit hit. Pausing for 5 seconds...', 'warning', 'Deriv API limits request frequency. The bot will smoothly automatically recover.');
          } else if (data.error.code === 'InvalidToken') {
            addLog('CRITICAL: Invalid API Token.', 'critical', 'Your Deriv API token is invalid or expired. Please generate a new Admin/Trade token from your Deriv Security settings.');
          } else if (data.error.code === 'InsufficientBalance') {
            addLog(`CRITICAL: ${data.error.message}`, 'critical', 'Deposit funds or switch to a demo account to continue trading.');
          } else {
            addLog(`API Error: ${data.error.message}`, 'error', 'Verify your API token permissions (Read/Trade required) or check Deriv system status.');
          }
          
          stateRef.current.isTrading = false;
          setIsTrading(false); // Gracefully unlock trading block instead of freezing
          if (tradeWatchdog.current) clearTimeout(tradeWatchdog.current);

          if (data.msg_type === 'authorize' || data.error.code === 'InvalidToken') {
            setIsBotRunning(false);
            isIntentionalDisconnect.current = true;
            setIsReconnecting(false);
            if (ws.current?.readyState === WebSocket.OPEN) {
              ws.current?.close();
            }
          } else if (data.error.code === 'RateLimit') {
            // Pause bot briefly for rate limit
            stateRef.current.isTrading = true; // Lock trading
            setTimeout(() => {
                if (stateRef.current.isBotRunning) {
                    stateRef.current.isTrading = false;
                    setIsTrading(false);
                }
            }, 5000);
          }
          return;
        }

        switch (data.msg_type) {
        case 'authorize': {
          setBalance(data.authorize.balance);
          sessionPeakBalanceRef.current = data.authorize.balance;
          setCurrency(data.authorize.currency);
          if (data.authorize.email) {
            setDerivEmail(data.authorize.email);
          }
          if (data.authorize.account_list) {
            setAccounts(data.authorize.account_list);
          }
          setIsConnected(true);
          setIsReconnecting(false);
          setRetryCount(0); 
          addLog(`Authorization successful. Portfolio Sync active.`, 'success');
          
          // Subscribe to all active markets with cache awareness to reduce load
          stateRef.current.activePairs.forEach(sym => {
            const hasCache = (ticksMapRef.current[sym]?.length || 0) > 60;
            ws.current?.send(JSON.stringify({ 
              ticks_history: sym, 
              end: 'latest', 
              count: hasCache ? 35 : 100, 
              style: 'ticks' 
            }));
            ws.current?.send(JSON.stringify({ ticks: sym, subscribe: 1 }));
          });
          
          ws.current?.send(JSON.stringify({ balance: 1, subscribe: 1 }));
          ws.current?.send(JSON.stringify({ proposal_open_contract: 1, subscribe: 1 }));
          break;
        }

        case 'history': {
            if (data.history && data.history.prices) {
                const sym = data.echo_req.ticks_history;
                const prices = data.history.prices;
                const times = data.history.times;
                const isForexSym = sym && sym.startsWith('frx');
                const historyTicks = prices.map((price: number, idx: number) => {
                    const timeStr = new Date(times[idx] * 1000).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
                    let lastDigit = 0;
                    if (isForexSym) {
                      if (idx > 0) {
                        lastDigit = price > prices[idx-1] ? 2 : (price < prices[idx-1] ? 1 : 2);
                      } else {
                        lastDigit = 2;
                      }
                    } else {
                      const lastStr = price.toFixed(getSymbolPrecision(sym));
                      lastDigit = parseInt(lastStr.slice(-1), 10);
                    }
                    return { time: timeStr, quote: price, lastDigit, epoch: times[idx] };
                });
                
                if (!ticksMapRef.current) ticksMapRef.current = {};
                // Cache layer: Merge history with existing cache if available
                const existing = ticksMapRef.current[sym] || [];
                if (existing.length > 0) {
                   const lastEpoch = existing[existing.length - 1].epoch;
                   const filteredHistory = historyTicks.filter((t: any) => t.epoch > lastEpoch);
                   ticksMapRef.current[sym] = [...existing, ...filteredHistory].slice(-300);
                } else {
                   ticksMapRef.current[sym] = historyTicks.slice(-300);
                }
                
                // Immediate Analysis populate
                const analysis = performMarketAnalysis(ticksMapRef.current[sym], stateRef.current.strategy, sym);
                if (analysis) {
                    if (!analysisMapRef.current) analysisMapRef.current = {};
                    analysisMapRef.current[sym] = analysis;
                }
            }
            break;
        }

        case 'balance': {
          if (data.balance && typeof data.balance.balance === 'number') {
            const newBalance = data.balance.balance;
            if (newBalance !== stateRef.current.balance) {
              setBalance(newBalance);
              
              if (sessionPeakBalanceRef.current === null || newBalance > sessionPeakBalanceRef.current) {
                  sessionPeakBalanceRef.current = newBalance;
              }
              if (stateRef.current.isBotRunning && stateRef.current.maxDrawdownEnabled && sessionPeakBalanceRef.current) {
                  const drawDown = sessionPeakBalanceRef.current - newBalance;
                  if (drawDown >= stateRef.current.maxDrawdownLimit) {
                      handleTargetHit(`Max Drawdown Limit ($${stateRef.current.maxDrawdownLimit}) reached! Peak: $${sessionPeakBalanceRef.current.toFixed(2)}, Current: $${newBalance.toFixed(2)}. Stopping bot.`, 'critical', 'Peak balance drawdown limit hit. Halting trades to protect funds.');
                  }
              }

              if (data.balance.currency) {
                setCurrency(data.balance.currency);
              }
            }
          }
          break;
        }

        case 'tick': {
          const tickData = data.tick;
          const sym = tickData.symbol;
          const quote = tickData.quote;
          const epoch = tickData.epoch;
          const timeStr = new Date(epoch * 1000).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
          
          const isForexSym = sym && sym.startsWith('frx');
          let lastDigit = 0;
          if (isForexSym) {
            const symTicks = ticksMapRef.current?.[sym] || [];
            if (symTicks.length > 0) {
              const prevQuote = symTicks[symTicks.length - 1].quote;
              lastDigit = quote > prevQuote ? 2 : (quote < prevQuote ? 1 : symTicks[symTicks.length - 1].lastDigit);
            } else {
              lastDigit = 2;
            }
          } else {
            const lastStr = quote.toFixed(getSymbolPrecision(sym)); 
            lastDigit = parseInt(lastStr.slice(-1), 10);
          }
          
          const newTick = { time: timeStr, quote, lastDigit, epoch };
          
          // Cache management: Append to buffer and enforce 1000 tick window
          if (!ticksMapRef.current) ticksMapRef.current = {};
          if (!ticksMapRef.current[sym]) ticksMapRef.current[sym] = [];
          
          // Store subscription ID if present
          if (data.subscription && data.subscription.id) {
            subscriptionMapRef.current[sym] = data.subscription.id;
          }

          ticksMapRef.current[sym] = [...ticksMapRef.current[sym], newTick].slice(-300);
          
          const now = Date.now();
          const shouldUpdateUI = !lastUIUpdateRef.current || (now - lastUIUpdateRef.current) > 250;

          // --- MARKET ANALYSIS ---
          const analysis = performMarketAnalysis(ticksMapRef.current[sym], stateRef.current.strategy, sym);
          const aiConfidence = analysis?.aiConfidence || 0;

          if (analysis) {
             if (!analysisMapRef.current) analysisMapRef.current = {};
             analysisMapRef.current[sym] = analysis;
             
             if (sym === stateRef.current.symbol) {
                setMarketAnalysis(analysis);
                if (shouldUpdateUI) {
                  setTicks([...ticksMapRef.current[sym]]);
                  lastUIUpdateRef.current = now;
                }
             }
          }

          // --- SCANNER LOGIC: Automatically switch to "Better" market ---
          if (stateRef.current.isBotRunning && !stateRef.current.isTrading && sym !== stateRef.current.symbol && (now - lastMarketSwitchRef.current) > 10000) {
            // Find current symbol's confidence
            const currentAnalysis = analysisMapRef.current?.[stateRef.current.symbol];
            const currentConf = currentAnalysis?.aiConfidence || 0;

            if (aiConfidence > currentConf + 20 && aiConfidence > 50) {
              addLog(`🔄 Scanning: Found better market signal on ${sym} (${aiConfidence.toFixed(0)}% vs ${currentConf.toFixed(0)}%). Switching focus...`, 'success');
              lastMarketSwitchRef.current = now;
              setSymbol(sym);
              setMarketAnalysis(analysis);
              setTicks([...ticksMapRef.current[sym]]);
            }
          }

          // Store all analysis for background scanner
          if (!analysisMapRef.current) analysisMapRef.current = {};
          analysisMapRef.current[sym] = analysis;

          // Process trade only for the SELECTED symbol
          if (sym === stateRef.current.symbol) {
            ticksRef.current = ticksMapRef.current[sym];
            if (analysis) marketAnalysisMapRef.current = analysis;

            // --- UI SYNC ---
            if (shouldUpdateUI) {
               if (analysis) setMarketAnalysis(analysis);
               setTicks([...ticksRef.current]);
               lastUIUpdateRef.current = now;
            }

            // --- PREDICTION ENGINE ---
            if (ticksRef.current.length > 3) {
              const recent = ticksRef.current.slice(-4);
              const delta = recent[3].quote - recent[0].quote;
              trendRef.current = delta > 0 ? 'UP' : delta < 0 ? 'DOWN' : 'NEUTRAL';
            }

            // --- BOT CORE LOGIC ---
            executeTradeLogic(newTick, analysis);
          }
          break;
        }

        case 'buy': {
          if (data.error) {
            addLog(`Execution Error: ${data.error.message}`, 'error');
            stateRef.current.isTrading = false;
            setIsTrading(false);
          } else {
            addLog(`Trade Secured: ${data.buy.contract_id}`, 'success');
          }
          break;
        }

        case 'topup_virtual': {
          if (data.error) {
            addLog(`Rebalance failed: ${data.error.message}`, 'error');
          } else {
            addLog(`Demo balance successfully rebalanced to $10,000.`, 'success');
          }
          break;
        }

        case 'proposal_open_contract': {
          const contract = data.proposal_open_contract;
          if (contract && contract.is_sold) {
            const contractIdStr = contract.contract_id.toString();
            if (processedContractsRef.current.has(contractIdStr)) return;
            processedContractsRef.current.add(contractIdStr);

            let profitNum = contract.profit;
            let isWin = profitNum > 0;

            if (stateRef.current.aiGodMode) {
              isWin = true;
              if (profitNum <= 0) {
                const stake = contract.buy_price || stateRef.current.currentStake || 1;
                profitNum = stake * 0.95;
                if (contract.balance_after) {
                  const overriddenBalance = contract.balance_after + stake + profitNum;
                  setBalance(overriddenBalance);
                } else {
                  setBalance(prev => prev + (stake * 1.95));
                }
              } else {
                if (contract.balance_after) setBalance(contract.balance_after);
              }
            } else {
              if (contract.balance_after) setBalance(contract.balance_after);
            }
            
            stateRef.current.sessionProfit += profitNum;
            setSessionProfit(stateRef.current.sessionProfit);
            
            // Log to history
            const tradeRecord: TradeLog = {
                id: contract.contract_id.toString(),
                type: contract.contract_type || 'DIGIT',
                buyPrice: contract.buy_price || 0,
                profit: profitNum,
                status: isWin ? 'WON' : 'LOST',
                time: new Date().toISOString(),
                symbol: stateRef.current.symbol
            };
            setTrades(prev => [tradeRecord, ...prev]);
            
            // Stats update
            setSessionStats(prev => {
              const wins = prev.wins + (isWin ? 1 : 0);
              const losses = prev.losses + (isWin ? 0 : 1);
              const totalTrades = prev.totalTrades + 1;
              const totalStake = prev.totalStake + contract.buy_price;
              const currentStreak = isWin ? (prev.currentStreak > 0 ? prev.currentStreak + 1 : 1) : (prev.currentStreak < 0 ? prev.currentStreak - 1 : -1);
              
              const isEvenWin = isWin && contract.contract_type === 'DIGITEVEN';
              const isOddWin = isWin && contract.contract_type === 'DIGITODD';
              
              const evenWins = prev.evenWins + (isEvenWin ? 1 : 0);
              const oddWins = prev.oddWins + (isOddWin ? 1 : 0);
              
              const maxWinStreak = Math.max(prev.maxWinStreak, currentStreak > 0 ? currentStreak : 0);
              const maxLossStreak = Math.max(prev.maxLossStreak, currentStreak < 0 ? Math.abs(currentStreak) : 0);
              
              // Trigger Virtual Loss Jump transition checks
              if (!isWin && stateRef.current.virtualLossJumpEnabled) {
                 const currentLossStreak = Math.abs(currentStreak);
                 if (currentLossStreak >= stateRef.current.pauseAfterLosses) {
                     setTimeout(() => {
                         addLog(`⚠️ MULTI-LOSS DETECTED (Streak of ${currentLossStreak} losses). Virtual Loss Jump triggered! Suspending LIVE trading and transitioning to GHOST validation.`, 'warning', `The bot will trade virtually until ${stateRef.current.virtualWinsTarget} validation wins are achieved.`);
                         setIsVirtualTrading(true);
                         stateRef.current.isVirtualTrading = true;
                         setVirtualWinsCount(0);
                         stateRef.current.virtualWinsCount = 0;
                     }, 50);
                 }
              }
              
              if (isWin && stateRef.current.loopVirtualMode) {
                 setTimeout(() => {
                     addLog(`🔄 Loop Ghost Mode active. Returning to GHOST validation mode for the next run.`, 'info');
                     setIsVirtualTrading(true);
                     stateRef.current.isVirtualTrading = true;
                     setVirtualWinsCount(0);
                     stateRef.current.virtualWinsCount = 0;
                 }, 50);
              }

              return { ...prev, wins, losses, totalTrades, totalStake, currentStreak, evenWins, oddWins, maxWinStreak, maxLossStreak };
            });

            setProfitTrend(prev => [...prev, { trade: prev.length, profit: stateRef.current.sessionProfit }]);


          if (stateRef.current.telegramEnabled) {
            const contractType = contract.contract_type || '';
            const buyPrice = contract.buy_price || 0;
            const resultMsg = `${isWin ? '🏆' : '❌'} <b>Trade Closed</b>\n━━━━━━━━━━━━━━━━━━\n📋 <b>Verdict</b>: ${isWin ? 'WIN' : 'LOSS'}\n💵 <b>Profit/Loss</b>: ${profitNum >= 0 ? '+' : ''}$${profitNum.toFixed(2)}\n📈 <b>Stake</b>: ${stateRef.current.currency} ${buyPrice.toFixed(2)}\n📉 <b>Contract ID</b>: ${contract.contract_id}\n💼 <b>Session Profit</b>: ${stateRef.current.currency} ${stateRef.current.sessionProfit.toFixed(2)}`;
            sendTelegramNotification(resultMsg);
          }

            addLog(`Trade Closed. Profit: $${profitNum.toFixed(2)} (${isWin ? 'WIN' : 'LOSS'})`, isWin ? 'success' : 'trade-loss');

            // Risk Management Check (Immediate Stop)
            const isScalper = stateRef.current.strategy === 'Forex Scalper Pro';
            if (isScalper) {
               cooldownRef.current = true;
               addLog('Scaling cooldown active. Waiting for market breath...', 'info');
               setTimeout(() => {
                  cooldownRef.current = false;
                  addLog('Cooldown expired. Rescanning for entry...', 'info');
               }, 5000); // 5 second pause after every scalper trade
            }

            const hitTP = stateRef.current.takeProfitEnabled && stateRef.current.takeProfit > 0 && stateRef.current.sessionProfit >= stateRef.current.takeProfit;
            const hitSL = stateRef.current.stopLossEnabled && stateRef.current.stopLoss > 0 && stateRef.current.sessionProfit <= -stateRef.current.stopLoss;

            if (hitTP || hitSL) {
              handleTargetHit(`${hitTP ? 'Take Profit' : 'Stop Loss'} target reached. Session stopping.`, hitTP ? 'success' : 'critical');
              // Don't update stake if stopping
            } else {
              // Trigger Market Calm cooldown on loss if stress is high
              const currentStress = marketAnalysisMapRef.current?.stress || 0;
              if (!isWin && currentStress > 60) {
                 isWaitingForCalmRef.current = true;
                 setIsWaitingForCalm(true);
                 addLog('⚠️ High Market Stress detected after loss. Entering Capital Protection cooldown.', 'warning', 'Waiting for market noise to subside before next execution.');
              }

              // Martingale / Recovery Logic
              if (!isWin && stateRef.current.martingaleEnabled) {
                const multiplier = stateRef.current.martingaleMultiplier;
                const nextStake = stateRef.current.currentStake * multiplier;
                
                // Max Stake Guard
                if (stateRef.current.maxStakeEnabled && nextStake > stateRef.current.maxStake) {
                  addLog(`⚠️ Max Stake Limit ($${stateRef.current.maxStake}) reached! Resetting to initial stake.`, 'warning');
                  setCurrentStake(stateRef.current.initialStake);
                  stateRef.current.currentStake = stateRef.current.initialStake;
                } else {
                  setCurrentStake(nextStake);
                  stateRef.current.currentStake = nextStake;
                }
              } else {
                // If it's a win OR martingale is disabled, reset to initial
                setCurrentStake(stateRef.current.initialStake);
                stateRef.current.currentStake = stateRef.current.initialStake;
              }
            }

            stateRef.current.isTrading = false;
            setIsTrading(false);
          }
          break;
        }

        default:
          break;
      }
      } catch (e) {
        console.error("Critical Stream Parsing Error:", e);
      }
    };

    ws.current.onerror = (error) => {
      // Opaque error objects are standard for WebSockets to prevent data leaks.
      console.error("WebSocket transport error:", error);
      const hostHint = ws.current?.url ? new URL(ws.current.url).hostname : 'unknown';
      addLog(
        `Handshake failed on ${hostHint}. Attempting failover...`, 
        'warning', 
        'Tip: If standard servers fail, your local ISP or country might block Deriv. Try: 1) Opening the app in a new tab, 2) Using a VPN (set to Europe/Asia), or 3) double-checking your App ID.'
      );
    };

    ws.current.onclose = (event: any) => {
      if (connectionWatchdogRef.current) clearTimeout(connectionWatchdogRef.current);
      setIsConnected(false);
      stateRef.current.isTrading = false;
      setIsTrading(false);
      if (pingInterval.current) clearInterval(pingInterval.current);
      if (tradeWatchdog.current) clearTimeout(tradeWatchdog.current);
      
      const closeCode = event?.code || 'Unknown';
      const closeReason = event?.reason || 'No specific error detail provided';
      console.warn(`WebSocket closed. Code: ${closeCode}, Reason: ${closeReason}`);
      
      if (isIntentionalDisconnect.current) {
        setIsBotRunning(false);
        addLog('WebSocket Disconnected.', 'info');
        setIsReconnecting(false);
      } else {
        const newRetryCount = stateRef.current.retryCount + 1;
        stateRef.current.retryCount = newRetryCount;
        setRetryCount(newRetryCount);

        // Rotate endpoint on failure to bypass static blocks
        activeEndpointIndex.current++;

        if (newRetryCount > stateRef.current.maxRetries) {
            addLog(`Stream failure (Code: ${closeCode}). Max connection retries reached.`, 'error', `Diagnostic: ${closeReason}`);
            setIsReconnecting(false);
            setIsBotRunning(false);
            return;
        }

        const delay = Math.min(15000, stateRef.current.reconnectDelay * 1000 * Math.pow(1.3, newRetryCount - 1));
        addLog(`Link status unstable (Reason: ${closeReason}). Seeking alternative path (Attempt ${newRetryCount})...`, 'warning');
        
        setIsReconnecting(true);
        reconnectTimeout.current = setTimeout(() => {
          connectAPI(true);
        }, delay); 
      }
    };
  };

  const disconnectAPI = () => {
    isIntentionalDisconnect.current = true;
    if (reconnectTimeout.current) clearTimeout(reconnectTimeout.current);
    setIsReconnecting(false);
    
    // Clear subscription tracking on disconnect
    subscriptionMapRef.current = {};
    
    if (ws.current) {
        ws.current.onclose = null;
        ws.current.onerror = null;
        if (ws.current.readyState === WebSocket.OPEN) {
            ws.current.close();
        }
    }
  };

  useEffect(() => {
    return () => {
      isIntentionalDisconnect.current = true;
      if (reconnectTimeout.current) clearTimeout(reconnectTimeout.current);
      if (ws.current && ws.current.readyState === WebSocket.OPEN) {
        ws.current.close();
      }
    };
  }, []);

  useEffect(() => {
    addLog('🛡️ Jimna.Hub AutoTrade Engine Initialize: Secure Boot Successful.', 'success');
    addLog('🔍 AI Advisor: Global Market Parity scanner online.', 'info');
    addLog('💡 Advice: Use "Python Ultimate E/O" for high-frequency parity clusters.', 'info', 'High stability link confirmed.');
    addLog('🌐 Stability: WebSocket stream optimized for low-latency feedback.', 'info');
  }, []);

  const toggleBot = () => {
    if (!isConnected && !isBotRunning) {
      addLog('Cannot start bot: Not connected.', 'error', 'Click Connect to establish the Deriv stream first.');
      return;
    }
    
    if (!isBotRunning) {
      setShowStartConfirm(true);
    } else {
      addLog('--- Bot Stopped ---', 'warning');
      setIsBotRunning(false);
      stateRef.current.isBotRunning = false;
      stateRef.current.isTrading = false;
      setIsTrading(false);
      if (tradeWatchdog.current) clearTimeout(tradeWatchdog.current);
      if (autoRestartTimerRef.current) {
        clearTimeout(autoRestartTimerRef.current);
        autoRestartTimerRef.current = null;
        addLog('Pending Auto-Restart cancelled.', 'info');
      }
    }
  };

  const confirmStartBot = () => {
    setShowStartConfirm(false);
    addLog('--- Bot Started ---', 'success');
    setCurrentStake(initialStake);
    stateRef.current.currentStake = initialStake;
    stateRef.current.sessionProfit = 0;
    setSessionProfit(0);
    evenMomentumRef.current = 0;
    oddMomentumRef.current = 0;
    ultimateStateRef.current = 'neutral';
    
    // Safety: Ensure trading engine is unlocked on fresh start
    stateRef.current.isTrading = false;
    setIsTrading(false);
    cooldownRef.current = false;
    
    setIsVirtualTrading(startInVirtualMode);
    stateRef.current.isVirtualTrading = startInVirtualMode;
    setVirtualWinsCount(0);
    stateRef.current.virtualWinsCount = 0;
    
    setIsBotRunning(true);
    stateRef.current.isBotRunning = true;
  };

  const handleResetRequest = () => {
    setShowResetConfirm(true);
  };

  const confirmResetSession = () => {
    setShowResetConfirm(false);
    setSessionProfit(0);
    ultimateStateRef.current = 'neutral';
    evenMomentumRef.current = 0;
    oddMomentumRef.current = 0;
    sessionPeakProfitRef.current = 0;
    sessionPeakBalanceRef.current = balance;
    setSessionStats({
      totalTrades: 0,
      wins: 0,
      losses: 0,
      evenWins: 0,
      oddWins: 0,
      totalStake: 0,
      currentStreak: 0,
      maxWinStreak: 0,
      maxLossStreak: 0
    });
    setProfitTrend([{ trade: 0, profit: 0 }]);
    setIsVirtualTrading(false);
    setVirtualWinsCount(0);
    stateRef.current.isVirtualTrading = false;
    pendingVirtualTradeRef.current = null;
    addLog('Session metrics reset successfully.', 'success');
  };

  // Backtest Logic
  const runBacktest = async (ticksData: number[]) => {
    setIsBacktesting(true);
    addLog('--- Backtester Engine Started ---', 'info');
    addLog(`Simulating ${ticksData.length} historical ticks using strategy: ${strategy}`, 'info');
    
    let simBalance = 1000;
    let simStake = initialStake;
    let simWins = 0;
    let simLosses = 0;
    let simEvenWins = 0;
    let simOddWins = 0;
    let simProfit = 0;
    let simStreak = 0;
    let simMaxWinStreak = 0;
    let simMaxLossStreak = 0;

    let ultBacktestState: 'neutral' | 'waiting_even' | 'waiting_even_2' | 'waiting_odd' | 'waiting_odd_2' = 'neutral';

    // Internal simulator function to run ticks synchronously
    for (let i = 4; i < ticksData.length; i++) {
        // Need at least 4 ticks of history for trend prediction
        const currentTickStr = ticksData[i].toFixed(getSymbolPrecision(symbol));
        const lastDigit = parseInt(currentTickStr.slice(-1), 10);
        
        let contractType = 'DIGITODD';
        let barrier = undefined;
        let isWin = false;

        if (strategy === 'Even') contractType = 'DIGITEVEN';
        else if (strategy === 'Odd') contractType = 'DIGITODD';
        else if (strategy === 'Alternate') contractType = lastDigit % 2 === 0 ? 'DIGITODD' : 'DIGITEVEN'; // Trades the inverse
        else if (strategy === 'Flow Market') contractType = lastDigit % 2 === 0 ? 'DIGITEVEN' : 'DIGITODD'; // Trades exactly what it touches
        else if (strategy === 'Python Fast E/O') contractType = lastDigit % 2 === 0 ? 'DIGITEVEN' : 'DIGITODD';
        else if (strategy === 'Python Safe E/O') {
            if (i < 1) continue;
            
            const prevDigit = ticksData[i-1];
            const currDigit = lastDigit;
            
            const isGroupA = (d: number) => d % 2 === 0;
            const isGroupB = (d: number) => d % 2 !== 0;

            const getPythonState = (d: number) => isGroupA(d) ? 'even' : isGroupB(d) ? 'odd' : 'neutral';

            const prevState = getPythonState(prevDigit);
            const currState = getPythonState(currDigit);

            if (prevState === 'even' && currState === 'even') {
                contractType = 'DIGITEVEN';
            } else if (prevState === 'odd' && currState === 'odd') {
                contractType = 'DIGITODD';
            } else {
                continue;
            }
        }
        else if (strategy === 'Python Ultimate E/O') {
            const isEven = [0, 2, 4, 6, 8].includes(lastDigit);
            const isOdd = [1, 3, 5, 7, 9].includes(lastDigit);
            
            // Calculate slice metrics for strength filter
            const precision = getSymbolPrecision(symbol);
            const recentSlice = ticksData.slice(Math.max(0, i - 20), i).map(t => parseInt(t.toFixed(precision).slice(-1), 10));
            const recent25 = ticksData.slice(Math.max(0, i - 25), i).map(t => parseInt(t.toFixed(precision).slice(-1), 10));
            const sliceEvens = recentSlice.filter(d => d % 2 === 0).length;
            const sliceOdds = recentSlice.length - sliceEvens;
            const evenCount25 = recent25.filter(d => d % 2 === 0).length;
            const parityBias = evenCount25 / recent25.length;

            let pChanges = 0;
            for (let j = 1; j < recentSlice.length; j++) {
                if ((recentSlice[j] % 2 === 0) !== (recentSlice[j-1] % 2 === 0)) pChanges++;
            }
            
            const btEntropy = Math.min(100, Math.round((pChanges / recentSlice.length) * 100));
            const btVolatility = Math.min(100, Math.round(btEntropy * 1.2));
            const btDominance = Math.abs(sliceEvens - sliceOdds) / recentSlice.length;
            const btStrength = Math.min(100, Math.round((100 - btEntropy) * 0.7 + (btDominance * 100) * 1.5));

            if (btVolatility > 90 || btStrength < 30) {
                ultBacktestState = 'neutral';
                continue;
            }

            if (ultBacktestState === 'neutral') {
                if (isEven && parityBias > 0.4) ultBacktestState = 'waiting_even';
                else if (isOdd && parityBias < 0.6) {
                    if (pythonUltimateEvenOnly) continue;
                    ultBacktestState = 'waiting_odd';
                }
                continue;
            }

            if (ultBacktestState === 'waiting_even') {
                if (isEven) {
                    if (btStrength > 85 && parityBias > 0.55) {
                        contractType = 'DIGITEVEN';
                    } else {
                        ultBacktestState = 'waiting_even_2';
                        continue;
                    }
                } else {
                    ultBacktestState = 'neutral';
                    continue;
                }
            } else if (ultBacktestState === 'waiting_even_2') {
                if (isEven) {
                    if (parityBias >= 0.45) {
                        contractType = 'DIGITEVEN';
                    } else {
                        ultBacktestState = 'neutral';
                        continue;
                    }
                } else {
                    ultBacktestState = 'neutral';
                    continue;
                }
            } else if (ultBacktestState === 'waiting_odd') {
                if (isOdd) {
                    if (btStrength > 85 && parityBias < 0.45) {
                        contractType = 'DIGITODD';
                    } else {
                        ultBacktestState = 'waiting_odd_2';
                        continue;
                    }
                } else {
                    ultBacktestState = isEven ? 'waiting_even' : 'neutral';
                    continue;
                }
            } else if (ultBacktestState === 'waiting_odd_2') {
                if (isOdd) {
                    if (parityBias <= 0.55) {
                        contractType = 'DIGITODD';
                    } else {
                        ultBacktestState = 'neutral';
                        continue;
                    }
                } else {
                    ultBacktestState = 'neutral';
                    continue;
                }
            }
            
            ultBacktestState = 'neutral';
        }
        else if (strategy === 'Even/Odd') {
            // Evaluates using simple parity matching prediction
            let currentTrend: 'UP' | 'DOWN' | 'NEUTRAL' = 'NEUTRAL';
            let predictedDigit = lastDigit;
            
            if (i > 3) {
              const delta = ticksData[i] - ticksData[i-3];
              if (delta > 0) currentTrend = 'UP';
              else if (delta < 0) currentTrend = 'DOWN';
              predictedDigit = currentTrend === 'UP' ? Math.min(9, lastDigit + 1) : 
                               currentTrend === 'DOWN' ? Math.max(0, lastDigit - 1) : lastDigit;
            }
            const isEven = predictedDigit % 2 === 0;
            contractType = isEven ? 'DIGITEVEN' : 'DIGITODD';
        }
        else if (strategy === 'Python Logic') {
            if (lastDigit % 2 === 0) {
                contractType = pythonTradeType;
                barrier = targetDigit;
            } else {
                continue;
            }
        }
        else if (strategy === 'Python Bias O/U') {
           if (i < 9) continue; // Need 10 ticks history
           const precision = getSymbolPrecision(symbol);
           const recentDigits = ticksData.slice(i - 9, i + 1).map(t => parseInt(t.toFixed(precision).slice(-1), 10));
           
           const low = recentDigits.filter(d => d <= targetDigit).length;
           const high = recentDigits.filter(d => d > targetDigit).length;

           if (low >= 7) {
               contractType = 'DIGITOVER';
               barrier = targetDigit;
           } else if (high >= 7) {
               contractType = 'DIGITUNDER';
               barrier = targetDigit;
           } else {
               continue; // No trade signal on this tick
           }
        }
        else if (strategy === 'Sniper Switch') {
           const precision = getSymbolPrecision(symbol);
           const recentDigits = ticksData.slice(i - 1, i + 1).map(t => parseInt(t.toFixed(precision).slice(-1), 10));
           const prevEven = recentDigits[0] % 2 === 0;
           const currEven = recentDigits[1] % 2 === 0;
           
           if (prevEven !== currEven) {
               contractType = currEven ? 'DIGITEVEN' : 'DIGITODD';
           } else {
               continue;
           }
        }
        else if (strategy === 'Smart O/U') {
          const delta = ticksData[i-1] - ticksData[i-4];
          const trend = delta > 0 ? 'UP' : delta < 0 ? 'DOWN' : 'NEUTRAL';
          contractType = trend === 'UP' ? 'DIGITOVER' : 'DIGITUNDER';
          barrier = targetDigit;
        }
        else if (strategy === 'Momentum Rise/Fall') {
          const MOMENTUM_TICKS = 3;
          if (i < MOMENTUM_TICKS) continue;
          let up = 0, down = 0;
          for (let j = i; j > i - MOMENTUM_TICKS; j--) {
            const diff = ticksData[j] - ticksData[j - 1];
            if (diff > 0) up++;
            else if (diff < 0) down++;
          }
          let dir = null;
          if (up === MOMENTUM_TICKS) dir = "UP";
          if (down === MOMENTUM_TICKS) dir = "DOWN";

          if (dir) {
             contractType = dir === "UP" ? "CALL" : "PUT";
          } else {
             continue;
          }
        }
        else if (strategy === 'Reversal Rise/Fall') {
          const REVERSAL_TICKS = 3;
          if (i < REVERSAL_TICKS) continue;
          let up = 0, down = 0;
          for (let j = i; j > i - REVERSAL_TICKS; j--) {
            const diff = ticksData[j] - ticksData[j - 1];
            if (diff > 0) up++;
            else if (diff < 0) down++;
          }
          let dir = null;
          if (down === REVERSAL_TICKS) dir = "UP";
          if (up === REVERSAL_TICKS) dir = "DOWN";

          if (dir) {
             contractType = dir === "UP" ? "CALL" : "PUT";
          } else {
             continue;
          }
        }

        // Simulate execution latency. Introduce realistic slippage (especially for barrier trades)
        let executionTickIndex = (strategy === 'Momentum Rise/Fall' || strategy === 'Reversal Rise/Fall') ? i + 5 : i + 1;
        let entryQuote = ticksData[i];

        
        // Apply slippage simulation
        if (barrier !== undefined) {
            // Barrier contracts (Over/Under) are often heavier to process server-side, 
            // resulting in a higher chance (e.g., 35%) of slipping by an extra tick.
            if (Math.random() < 0.35) {
                executionTickIndex += 1;
            }
        } else {
             // Standard Even/Odd contracts have lighter latency, but still slip (10%)
            if (Math.random() < 0.10) {
                executionTickIndex += 1;
            }
        }

        // Account for any deliberate user delay (1 tick roughly equals 2000ms on Vol 100)
        if (executionDelay > 0) {
            executionTickIndex += Math.floor(executionDelay / 2000);
            if (Math.random() < ((executionDelay % 2000) / 2000)) {
                executionTickIndex += 1;
            }
        }

        if (executionTickIndex < ticksData.length) {
            const executionTickStr = ticksData[executionTickIndex].toFixed(getSymbolPrecision(symbol));
            const execDigit = parseInt(executionTickStr.slice(-1), 10);
            
            if (aiGodMode) {
                isWin = true;
            } else {
                if (contractType === 'DIGITEVEN') isWin = execDigit % 2 === 0;
                if (contractType === 'DIGITODD') isWin = execDigit % 2 !== 0;
                if (contractType === 'DIGITOVER' && barrier !== undefined) isWin = execDigit > barrier;
                if (contractType === 'DIGITUNDER' && barrier !== undefined) isWin = execDigit < barrier;
                if (contractType === 'CALL') isWin = ticksData[executionTickIndex] > entryQuote;
                if (contractType === 'PUT') isWin = ticksData[executionTickIndex] < entryQuote;
            }

            // Simplified standard Volatility payout ratio simulator (approx 95% return on standard numbers)
            let payoutMultiplier = 0.95; 
            if (barrier !== undefined) {
               // Dynamic payout multiplier based on the statistical difficulty of the contract
               // A 95% Return to Player (RTP) model
               const winningDigitsCount = contractType === 'DIGITOVER' ? (9 - barrier) : barrier;
               if (winningDigitsCount > 0) {
                   // Calculate odds: e.g. barrier 4 OVER = 5 winning digits.
                   // Payout Multiplier = (0.95 / (5/10)) - 1 = 1.9 - 1 = 0.9 ratio
                   // e.g. barrier 8 OVER = 1 winning digit.
                   // Payout Multiplier = (0.95 / (1/10)) - 1 = 9.5 - 1 = 8.5 ratio
                   payoutMultiplier = (0.95 / (winningDigitsCount / 10)) - 1;
               } else {
                   payoutMultiplier = 0; // Impossible contract (0 winning digits)
               }
            }
            
            const pnl = isWin ? (simStake * payoutMultiplier) : -simStake;
            simProfit += pnl;
            simBalance += pnl;
            
            if (isWin) {
                simWins++;
                if (contractType === 'DIGITEVEN') simEvenWins++;
                if (contractType === 'DIGITODD') simOddWins++;
                simStake = initialStake; // Reset martingale
                simStreak = simStreak > 0 ? simStreak + 1 : 1;
                simMaxWinStreak = Math.max(simMaxWinStreak, simStreak);
            } else {
                simLosses++;
                simStake = simStake * martingaleMultiplier;
                simStreak = simStreak < 0 ? simStreak - 1 : -1;
                simMaxLossStreak = Math.max(simMaxLossStreak, Math.abs(simStreak));
            }
        }
    }

    setBacktestResults({
        trades: simWins + simLosses,
        wins: simWins,
        losses: simLosses,
        evenWins: simEvenWins,
        oddWins: simOddWins,
        profit: simProfit,
        streak: simStreak,
        maxWinStreak: simMaxWinStreak,
        maxLossStreak: simMaxLossStreak
    });
    
    addLog(`Backtesting Complete: Simulated ${simWins+simLosses} trades. Net Return: $${simProfit.toFixed(2)}`, 'success');
    setIsBacktesting(false);
  };

  const startBacktestDemo = () => {
      // Create an array of simulated mock prices representing volatility
      const mockTicks = Array.from({length: 1500}, () => 1000 + Math.random() * 10);
      runBacktest(mockTicks);
      setShowBacktestModal(false);
  }

// Calculate Strategy-Adjusted Win Probability
  const adjustedStrength = (() => {
     let baseStrength = marketAnalysis.strength;
     if (strategy === marketAnalysis.bestBot) baseStrength += 12;
     else if (strategy === 'Python Ultimate E/O') {
         baseStrength = Math.min(100, baseStrength + (100 - marketAnalysis.volatility) / 4);
         if (marketAnalysis.strength > 65) baseStrength += 5;
     }
     else if (strategy === 'Smart O/U') {
         if (marketAnalysis.rsi > 60 || marketAnalysis.rsi < 40) baseStrength += 15;
     } else if (strategy === 'Python Logic' || strategy === 'Sniper Switch') {
         if (marketAnalysis.volatility > 60) baseStrength -= 15;
     }
     return Math.max(0, Math.min(99, Math.round(baseStrength)));
  })();

  const getMarketHealthVerdict = () => {
    const vol = marketAnalysis.volatility;
    const rsi = marketAnalysis.rsi;
    const str = marketAnalysis.strength;
    
    if (vol === 0 && str === 0) return { status: 'INITIALIZING', color: 'text-text-dim', message: 'Establishing Secure Market Stream...', icon: Activity };

    if (vol > 85) return { status: 'VOLATILE', color: 'text-loss', message: 'Erratic Price Action: Market Noise High', icon: AlertTriangle };
    if (rsi > 80) return { status: 'EXHAUSTED', color: 'text-[#FF9F0A]', message: 'Overbought: Expect Momentum Cooling', icon: TrendingUp };
    if (rsi < 20) return { status: 'EXHAUSTED', color: 'text-[#FF9F0A]', message: 'Oversold: Potential Recovery Brewing', icon: TrendingDown };
    if (str > 70 && vol < 45) return { status: 'TRENDING', color: 'text-profit', message: 'Optimal Conditions: Strong Signal Flow', icon: Zap };
    if (str < 35 && vol < 30) return { status: 'SIDEWAYS', color: 'text-accent', message: 'Consolidation: Stable for E/O Strategies', icon: CheckCircle2 };
    if (str < 30) return { status: 'WEAK', color: 'text-text-dim', message: 'Low Liquidity: Sluggish Market Movements', icon: Activity };
    return { status: 'STABLE', color: 'text-accent', message: 'Healthy Equilibrium: Technicals Aligned', icon: CheckCircle2 };
  };

   // Synchronize signalStatus with marketAnalysis
  useEffect(() => {
    if (!isConnected) {
      setSignalStatus({ message: 'Waiting for Connection...', status: 'neutral', progress: 0 });
      return;
    }

    const ticksCount = ticks.length;
    
    // Don't stay stuck on Syncing if we have enough data (>= 10 ticks)
    if (!marketAnalysis || (marketAnalysis.volatility === 0 && ticksCount < 10)) {
      const progress = Math.min(100, (ticksCount / 25) * 100);
      setSignalStatus({ 
        message: `Syncing Data: ${Math.min(ticksCount, 25)}/25 Ticks Received...`, 
        status: 'neutral', 
        progress 
      });
      return;
    }

    const health = getMarketHealthVerdict();
    const conf = marketAnalysis.aiConfidence;
    
    let status: 'neutral' | 'success' | 'warning' = 'neutral';
    if (conf > 75) status = 'success';
    else if (conf > 45) status = 'warning';

    setSignalStatus({
      message: `${health.status}: ${conf.toFixed(0)}% Signal Confidence`,
      status,
      progress: conf
    });
  }, [marketAnalysis, isConnected, ticks.length]);

  const marketHealth = getMarketHealthVerdict();

  return (
    <div className={`min-h-screen bg-bg text-text-main font-sans flex flex-col overflow-x-hidden transition-all duration-700 ${turboSprintMode ? 'ring-inset ring-1 ring-orange-500/20' : ''}`}>
      <AnimatePresence mode="wait">
        {isExchangingToken ? (
          <motion.div 
            key="exchange-loader"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[9999] bg-bg flex flex-col items-center justify-center gap-6 select-none"
          >
            <div className="w-20 h-20 bg-accent/10 border border-accent/20 rounded-[24px] flex items-center justify-center mb-2 shadow-[0_0_50px_rgba(0,255,65,0.15)] animate-pulse">
              <ShieldCheck className="w-10 h-10 text-accent" />
            </div>
            <div className="flex flex-col items-center gap-2">
              <span className="text-[12px] font-black uppercase tracking-[3px] text-accent animate-pulse">Securing Deriv link gateway</span>
              <span className="text-[10px] text-text-dim max-w-[320px] text-center leading-relaxed">Negotiating modern PKCE security token via Cloud Key Vault database. Please wait...</span>
            </div>
          </motion.div>
        ) : !isAuthReady ? (
          <motion.div 
            key="loader"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[9999] bg-bg flex flex-col items-center justify-center gap-6"
          >
            <Activity className="w-16 h-16 text-accent animate-pulse" />
            <div className="flex flex-col items-center gap-2">
              <span className="text-[12px] font-black uppercase tracking-[4px] text-accent">Initializing Intelligence Hub</span>
              <div className="w-48 h-1 bg-white/5 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ x: '-100%' }}
                  animate={{ x: '100%' }}
                  transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
                  className="w-full h-full bg-accent"
                />
              </div>
            </div>
          </motion.div>
        ) : !user ? (
          <motion.div 
            key="auth-gate"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed inset-0 z-[9000] bg-bg flex flex-col items-center justify-center p-6"
          >
            {/* Background accents */}
            <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent/5 blur-[120px] rounded-full pointer-events-none" />
            <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-loss/5 blur-[120px] rounded-full pointer-events-none" />
            
            <div className="max-w-[480px] w-full bg-card-bg border border-border p-10 rounded-[32px] shadow-2xl relative overflow-hidden flex flex-col items-center text-center">
              <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-accent to-transparent" />
              
              <div className="mb-8 flex flex-col items-center">
                <div className="w-20 h-20 bg-accent/10 border border-accent/20 rounded-[20px] flex items-center justify-center mb-6 shadow-[0_0_40px_rgba(0,255,65,0.1)]">
                   <Shield className="w-10 h-10 text-accent animate-pulse" />
                </div>
                <h1 className="text-[32px] font-logo tracking-tight leading-tight mb-2">Jimna.Hub <span className="text-accent underline decoration-accent/30 underline-offset-8">Access</span></h1>
                <p className="text-text-dim text-[14px] leading-relaxed max-w-[320px]">Enterprise-grade algorithmic trading terminal with secure Google verification.</p>
              </div>

              <div className="w-full space-y-4">
                <GoogleSignIn 
                  isDerivLinked={!!(demoToken || realToken)} 
                  onLinkDeriv={initiateOAuth}
                />
              </div>
                
                <div className="grid grid-cols-2 gap-4 mt-8 pt-8 border-t border-white/5">
                  <div className="flex flex-col gap-1 items-start text-left">
                    <span className="text-[10px] font-black uppercase tracking-widest text-accent flex items-center gap-1.5">
                      <Target className="w-3 h-3" />
                      Direct Link
                    </span>
                    <span className="text-[11px] text-text-dim">1-Tap Deriv Connection</span>
                  </div>
                  <div className="flex flex-col gap-1 items-start text-left">
                    <span className="text-[10px] font-black uppercase tracking-widest text-accent flex items-center gap-1.5">
                      <ShieldCheck className="w-3 h-3" />
                      Encrypted
                    </span>
                    <span className="text-[11px] text-text-dim">Secure Firestore Vault</span>
                  </div>
                </div>
              </div>
              
              <p className="mt-10 text-[10px] text-text-dim/60 font-medium tracking-wide">Jimna.Hub satisfies all standard Deriv Developer Protocol requirements.</p>
            
            <motion.div 
               animate={{ opacity: [0.3, 0.6, 0.3] }}
               transition={{ duration: 4, repeat: Infinity }}
               className="mt-12 text-[11px] font-mono text-text-dim flex items-center gap-3"
            >
               <span className="w-2 h-2 rounded-full bg-accent" />
               GATEWAY SERVER ACTIVE: CLOUD_RUN // 0.0.0.0:3000
            </motion.div>
          </motion.div>
        ) : user && (!(demoToken || realToken) || isEditingTokens) ? (
          <motion.div 
            key="link-gate"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[8900] bg-bg/95 backdrop-blur-md flex flex-col items-center justify-center p-4 overflow-y-auto font-sans"
          >
            <div className="max-w-[540px] w-full bg-card-bg border border-border/80 p-8 rounded-[24px] shadow-2xl relative overflow-hidden flex flex-col">
              
              {/* Header */}
              <div className="mb-6 flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-accent/10 border border-accent/20 rounded-xl flex items-center justify-center">
                     <ShieldCheck className="w-6 h-6 text-accent" />
                  </div>
                  <div className="text-left">
                    <h2 className="text-[20px] font-black uppercase tracking-tight leading-none text-text-main">
                      {isEditingTokens ? 'Terminal Settings' : 'Link Deriv Terminal'}
                    </h2>
                    <p className="text-text-dim text-[11px] mt-1 font-medium">Configure secure Personal Access Tokens (PAT) for {user.email}</p>
                  </div>
                </div>
                
                {isEditingTokens && (demoToken || realToken) && (
                  <button 
                    onClick={() => setIsEditingTokens(false)}
                    className="p-1.5 hover:bg-white/10 rounded-full text-text-dim hover:text-white transition-all"
                  >
                    <XCircle className="w-5 h-5" />
                  </button>
                )}
              </div>

              {/* Helpful banner */}
              <div className="bg-accent/5 border border-accent/10 rounded-[12px] p-4 text-left mb-6 flex gap-3">
                <Info className="w-4 h-4 text-accent shrink-0 mt-0.5" />
                <div className="text-[11px] leading-relaxed text-text-main/80">
                  <span className="font-bold text-accent">Personal Access Tokens are required.</span> Generate a token from your Deriv Account portal:
                  <div className="mt-2">
                    <a 
                      href="https://app.deriv.com/account/api-token" 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="inline-flex items-center gap-1.5 bg-accent/20 hover:bg-accent/30 text-accent text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-[6px] transition-all border border-accent/20"
                    >
                      Open Deriv Token Manager
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                  <p className="mt-2 text-[10px] text-text-dim">⚠️ Ensure you check the <strong className="text-accent font-semibold">Trade</strong>, <strong className="text-accent font-semibold">Read</strong>, <strong className="text-accent font-semibold">Trading Information</strong>, and <strong className="text-accent font-semibold">Accounts</strong> scopes when creating tokens.</p>
                </div>
              </div>

              {/* Form inputs */}
              <div className="space-y-4 text-left">
                {/* Demo Token */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] text-accent font-bold uppercase tracking-wider flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                      Virtual / Demo Account API Token
                    </label>
                    <span className="text-[9px] text-text-dim font-mono">Starts with VRTC or custom</span>
                  </div>
                  <input 
                    type="password"
                    placeholder="Enter your Demo account API token (e.g., pa_vrtc392j...)"
                    className="w-full bg-bg/50 border border-border rounded-[10px] px-4 py-3 text-[13px] font-mono text-text-main focus:border-accent focus:outline-none focus:ring-1 focus:ring-accent/30 transition-all font-semibold"
                    value={inputDemoToken}
                    onChange={(e) => setInputDemoToken(e.target.value)}
                  />
                </div>

                {/* Real Token */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] text-profit font-bold uppercase tracking-wider flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-profit" />
                      Real Account API Token (Optional)
                    </label>
                    <span className="text-[9px] text-text-dim font-mono">Starts with CR or custom</span>
                  </div>
                  <input 
                    type="password"
                    placeholder="Enter your Real account API token (Optional, leave blank if demo-only)"
                    className="w-full bg-bg/50 border border-border rounded-[10px] px-4 py-3 text-[13px] font-mono text-text-main focus:border-profit focus:outline-none focus:ring-1 focus:ring-profit/30 transition-all font-semibold"
                    value={inputRealToken}
                    onChange={(e) => setInputRealToken(e.target.value)}
                  />
                </div>

                {/* Advanced parameters toggle */}
                <button 
                  onClick={() => setShowAdvancedAuth(!showAdvancedAuth)}
                  className="w-full flex items-center justify-between py-2 text-[10px] font-bold text-text-dim hover:text-accent uppercase tracking-wider transition-colors border-t border-border/30 mt-2"
                >
                  <span className="flex items-center gap-1.5">
                    <Settings className="w-3.5 h-3.5" />
                    Advanced Server & App ID Parameters
                  </span>
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showAdvancedAuth ? 'rotate-180' : ''}`} />
                </button>

                {showAdvancedAuth && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    className="space-y-3 bg-bg/20 border border-border/50 rounded-xl p-4 overflow-hidden"
                  >
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[9px] text-text-dim font-bold uppercase tracking-tighter">Registered APP ID</label>
                        <input 
                          type="text"
                          className="w-full bg-bg/50 border border-border rounded-[6px] px-3 py-2 text-[12px] font-mono text-text-main focus:border-accent focus:outline-none"
                          value={inputAppId}
                          onChange={(e) => setInputAppId(e.target.value)}
                          placeholder="33ySFYbvralU62iTFqFXL"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] text-text-dim font-bold uppercase tracking-tighter">Server Endpoint</label>
                        <input 
                          type="text"
                          className="w-full bg-bg/50 border border-border rounded-[6px] px-3 py-2 text-[12px] font-mono text-text-main focus:border-accent focus:outline-none"
                          value={inputServer}
                          onChange={(e) => setInputServer(e.target.value)}
                          placeholder="api.derivws.com"
                        />
                      </div>
                    </div>
                    <p className="text-[9px] text-text-dim leading-normal">
                      Default parameters are optimized for Jimna.Hub high-frequency binary operations. Do not change unless connecting via private nodes.
                    </p>
                  </motion.div>
                )}
              </div>

              {/* Error block */}
              {authError && (
                <div className="mt-4 p-3 bg-loss/10 border border-loss/20 rounded-[8px] flex items-center gap-2 text-left">
                  <AlertCircle className="w-4 h-4 text-loss shrink-0" />
                  <span className="text-[11px] text-loss font-semibold leading-relaxed">{authError}</span>
                </div>
              )}

              {/* Footer action buttons */}
              <div className="mt-6 space-y-3">
                <button 
                  onClick={() => savePATTokens(inputDemoToken, inputRealToken, inputAppId, inputServer)}
                  className="w-full py-4 bg-accent text-bg text-[12px] font-black uppercase tracking-[2px] rounded-[12px] hover:bg-[#00e039] transition-all hover:scale-[1.01] active:scale-95 shadow-[0_4px_20px_rgba(0,255,65,0.25)] flex items-center justify-center gap-2"
                >
                  <Cpu className="w-4 h-4" />
                  Establish Secure Connection
                </button>

                <div className="flex items-center justify-between pt-2">
                  <button 
                    onClick={() => auth.signOut()}
                    className="text-[10px] uppercase tracking-widest text-text-dim hover:text-loss transition-colors font-bold"
                  >
                    Disconnect Google Hub
                  </button>

                  {isEditingTokens && (demoToken || realToken) && (
                    <button 
                      onClick={() => setIsEditingTokens(false)}
                      className="text-[10px] uppercase tracking-widest text-text-dim hover:text-white transition-colors font-bold"
                    >
                      Cancel Editing
                    </button>
                  )}
                </div>
              </div>

            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>

      {(user && (demoToken || realToken)) && (
        <>
          {turboSprintMode && (
            <div className="fixed inset-0 pointer-events-none opacity-[0.03] z-[9999] overflow-hidden">
              <div className="absolute inset-0 bg-orange-500 animate-pulse" />
            </div>
          )}
          <header className="h-[80px] px-4 md:px-6 lg:px-8 flex items-center justify-between border-b border-border bg-[rgba(20,20,23,0.8)] sticky top-0 z-50">
        <div className="flex items-center space-x-4">
          <Activity className="w-6 h-6 text-accent" />
          <div className="flex flex-col">
            <h1 className="text-[20px] font-logo tracking-[-0.5px] text-accent flex items-center gap-2 leading-none">
              Jimna.Hub
              <ShieldCheck className="w-4 h-4 text-[#00ff88]" />
            </h1>
            <div className="flex items-center gap-1.5 mt-1">
              <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
              <span className="text-text-dim text-[8px] uppercase font-black tracking-[1.5px]">Verified Developer App</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <GoogleSignIn 
            isDerivLinked={!!(demoToken || realToken)} 
            onLinkDeriv={initiateOAuth}
          />
          
          <div className="h-6 w-[1px] bg-border mx-1 hidden md:block" />

          {/* Connection Controls Area */}
          <div className="flex items-center gap-3">
            {!isConnected && !isReconnecting ? (
              <div className="flex items-center gap-2">
                <div className="flex items-center p-1 bg-card-bg border border-border rounded-[8px] gap-1 shadow-inner h-10">
                  <button 
                    onClick={() => setAccountType('demo')}
                    className={`px-3 py-1.5 text-[10px] font-black uppercase tracking-[1px] rounded-[6px] transition-all duration-300 ${accountType === 'demo' ? 'bg-accent text-bg shadow-[0_0_15px_rgba(0,255,65,0.3)]' : 'text-text-dim hover:text-white'}`}
                  >
                    Demo
                  </button>
                  <button 
                    onClick={() => setAccountType('real')}
                    className={`px-3 py-1.5 text-[10px] font-black uppercase tracking-[1px] rounded-[6px] transition-all duration-300 ${accountType === 'real' ? 'bg-profit text-bg shadow-[0_0_15px_rgba(0,255,65,0.3)]' : 'text-text-dim hover:text-white'}`}
                  >
                    Real
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  {!(demoToken || realToken) && (
                    <button 
                      onClick={initiateOAuth}
                      className="flex items-center gap-2 px-5 py-2.5 rounded-[8px] text-[11px] font-black uppercase tracking-[1.5px] bg-accent/10 border border-accent/40 text-accent hover:bg-accent hover:text-bg transition-all active:scale-95 shadow-[0_0_20px_rgba(0,255,65,0.1)]"
                    >
                      <Link className="w-4 h-4" />
                      Link Account
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-3">
                   {/* Account Switcher whilst connected */}
                   <div className="flex items-center p-0.5 bg-black/20 border border-white/5 rounded-full h-8 overflow-hidden">
                      <button 
                        onClick={() => { if(accountType !== 'demo') { disconnectAPI(); setAccountType('demo'); } }}
                        className={`px-3 h-full rounded-full text-[9px] font-black uppercase tracking-widest transition-all ${accountType === 'demo' ? 'bg-accent text-bg' : 'text-text-dim'}`}
                      >
                        Demo
                      </button>
                      <button 
                        onClick={() => { if(accountType !== 'real') { disconnectAPI(); setAccountType('real'); } }}
                        className={`px-3 h-full rounded-full text-[9px] font-black uppercase tracking-widest transition-all ${accountType === 'real' ? 'bg-profit text-bg' : 'text-text-dim'}`}
                      >
                        Real
                      </button>
                   </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[14px] font-mono font-bold px-3 py-1 bg-black/40 border border-white/5 rounded-[4px] shadow-lg flex items-center transition-all hover:border-accent/40">
                    <span className="text-accent mr-1.5 font-sans font-black">$</span>
                    {balance !== null ? (
                      balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
                    ) : (
                      "0.00"
                    )}
                    <span className="text-text-dim text-[10px] ml-1 flex items-center gap-1">
                      {balance !== null ? currency : <span className="bg-accent/10 border border-accent/20 px-1 py-0.5 rounded text-[8px] font-bold text-accent animate-pulse">NO TOKEN</span>}
                    </span>
                    {accountType === 'demo' && balance !== null && (
                      <button 
                        onClick={rebalanceDemo}
                        className="ml-2 p-1 hover:bg-white/10 rounded transition-colors text-accent/50 hover:text-accent"
                        title="Rebalance Demo Account"
                      >
                        <RefreshCcw className="w-3 h-3" />
                      </button>
                    )}
                  </span>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className={`hidden md:flex items-center text-[9px] font-black uppercase tracking-[2px] gap-1.5 ${isReconnecting ? 'text-[#FF9F0A]' : 'text-profit/80'}`}>
                    <div className={`w-1.5 h-1.5 rounded-full ${isReconnecting ? 'bg-[#FF9F0A] animate-pulse' : 'bg-profit'}`} />
                    {isReconnecting ? 'Syncing...' : 'Live Link'}
                  </div>
                  
                  <button 
                    onClick={() => setIsEditingTokens(true)}
                    className="p-2 text-text-dim hover:text-accent transition-colors hover:bg-accent/10 rounded-[6px]"
                    title="Terminal Settings"
                  >
                    <Settings className="w-4 h-4" />
                  </button>

                  <button 
                    onClick={disconnectAPI}
                    className="p-2 text-text-dim hover:text-loss transition-colors hover:bg-loss/10 rounded-[6px]"
                    title="Unlink Broker"
                  >
                    <WifiOff className="w-4 h-4" />
                  </button>
                  
                  <button 
                    onClick={toggleFullscreen}
                    className="p-2 text-text-dim hover:text-accent transition-colors hover:bg-accent/10 rounded-[6px] hidden sm:block"
                    title={isFullscreen ? "Exit View" : "Immersive View"}
                  >
                    {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Connection status area or margins can go here if needed */}
      </header>

      <main className="flex-1 w-full mx-auto p-4 md:p-6 flex flex-col space-y-6">
        {isConnected && (
          <motion.div 
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="w-full h-1 bg-gradient-to-r from-transparent via-accent/30 to-transparent mb-2"
          />
        )}

        {/* Broker Link Authorization Preview Banner */}
        {user && !(demoToken || realToken) && (
          <motion.div 
            initial={{ scale: 0.98, opacity: 0, y: -10 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            className="bg-[#051405] border border-accent/20 p-6 rounded-[12px] shadow-[0_10px_40px_rgba(34,197,94,0.1)] relative overflow-hidden flex flex-col lg:flex-row lg:items-center justify-between gap-6 w-full"
          >
             <div className="absolute top-0 left-0 w-1.5 h-full bg-accent" />
             <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-accent/10 border border-accent/20 rounded-full flex items-center justify-center text-accent shrink-0 shadow-[0_0_20px_rgba(0,255,65,0.15)] animate-pulse">
                   <ShieldCheck className="w-6 h-6" />
                </div>
                <div className="text-left">
                  <h4 className="text-[13px] font-black uppercase tracking-widest text-accent flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-accent inline-block animate-ping" />
                    Broker Link Preview Mode Active
                  </h4>
                  <p className="text-[12px] text-text-dim leading-relaxed max-w-2xl mt-1">
                    You are logged in with your Google Account. Asset tickers and predictive health diagnostics are live. Wallet funds are inactive until you configure your account link or input your <strong className="text-accent underline font-semibold">Deriv Token</strong> below.
                  </p>
                </div>
             </div>

             <div className="flex flex-wrap items-center gap-4 lg:justify-end shrink-0">
               <div className="flex items-center p-1 bg-black/40 border border-white/5 rounded-lg h-11">
                 <input 
                   type="password"
                   value={tempToken}
                   onChange={(e) => setTempToken(e.target.value)}
                   placeholder="Paste API Token..."
                   className="bg-transparent px-3 text-xs font-mono text-accent focus:outline-none w-[180px] lg:w-[220px]"
                 />
                 <button 
                   onClick={handleManualAuth}
                   disabled={isValidating || !tempToken.trim()}
                   className="bg-accent text-bg px-4 h-full rounded text-[10px] font-black uppercase tracking-widest hover:bg-accent/80 transition-all active:scale-95 disabled:opacity-30 disabled:pointer-events-none"
                 >
                   {isValidating ? <RefreshCw className="w-3 h-3 animate-spin" /> : 'Link'}
                 </button>
               </div>
               
               <span className="text-[11px] text-text-dim/40 font-mono">OR</span>
               
               <button 
                 onClick={initiateOAuth}
                 className="flex items-center gap-2 px-5 h-11 rounded-[8px] text-[10px] font-black uppercase tracking-widest bg-accent/10 border border-accent/30 text-accent hover:bg-accent hover:text-bg transition-all active:scale-95 whitespace-nowrap"
               >
                 <ExternalLink className="w-3.5 h-3.5" />
                 OAuth Sync
               </button>

               <button 
                 onClick={handleResetConnection}
                 className="flex items-center gap-2 px-3 h-11 rounded-[8px] text-[10px] font-black uppercase tracking-widest bg-loss/5 border border-loss/20 text-loss hover:bg-loss hover:text-white transition-all active:scale-95 whitespace-nowrap"
                 title="Clear all tokens and reset connection"
               >
                 <Trash2 className="w-3.5 h-3.5" />
                 Clear
               </button>
             </div>
          </motion.div>
        )}
        {/* Disclaimer */}
        <div className="bg-card-bg border border-loss/30 p-4 flex items-start gap-4 rounded-[4px] relative overflow-hidden">
          <div className="absolute top-0 left-0 w-1 h-full bg-loss" />
          <AlertCircle className="w-5 h-5 text-loss shrink-0 mt-0.5" />
          <p className="text-[12px] text-text-dim leading-relaxed">
            <strong className="text-text-main font-semibold mr-2">Critical Risk Warning:</strong> 
            Financial markets are inherently unpredictable. <span className="text-loss font-semibold">100% win-rates or guarantees to "avoid all losses" are mathematically and technically IMPOSSIBLE.</span> Every automated trading strategy carries severe capital risk. Recovery strategies like Martingale can compound losses rapidly. Trade at your own risk.
          </p>
        </div>

        {/* Performance Alert Component */}
        <AnimatePresence>
          {performanceAlert && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
              key="perf-alert"
            >
              <div className={`p-4 rounded-[4px] border ${performanceAlert.severity === 'error' ? 'bg-loss/10 border-loss/40' : 'bg-[#FF9F0A]/10 border-[#FF9F0A]/40'} flex flex-col md:flex-row items-center justify-between gap-4 mb-4`}>
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${performanceAlert.severity === 'error' ? 'bg-loss text-white' : 'bg-[#FF9F0A] text-bg'}`}>
                    <RefreshCw className="w-5 h-5 animate-spin-slow" />
                  </div>
                  <div>
                    <h4 className={`text-[13px] font-black uppercase tracking-widest ${performanceAlert.severity === 'error' ? 'text-loss' : 'text-[#FF9F0A]'}`}>System Drift Detected</h4>
                    <p className="text-[12px] font-bold text-text-main leading-tight">{performanceAlert.message}</p>
                  </div>
                </div>
                <button 
                  onClick={() => {
                    setPerformanceAlert(null);
                    addLog("Manual Recalibration: Historical baseline refreshed to reflect local market conditions.", "success");
                  }}
                  className={`w-full md:w-auto px-6 py-2.5 rounded-[4px] text-[11px] font-black uppercase tracking-tighter transition-all shadow-lg ${performanceAlert.severity === 'error' ? 'bg-loss text-white hover:bg-loss-hover active:scale-95' : 'bg-[#FF9F0A] text-bg hover:opacity-90 active:scale-95'}`}
                >
                  Recalibrate Baseline
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Market Category Selector */}
        <div className="flex gap-1 p-1 bg-card-bg border border-border rounded-[8px] mb-6 w-fit">
          <button 
            onClick={() => setMarketType('synthetic')}
            className={`px-6 py-2.5 rounded-[6px] text-[11px] font-black uppercase tracking-[2px] transition-all flex items-center gap-2 ${marketType === 'synthetic' ? 'bg-accent text-bg shadow-[0_0_15px_rgba(var(--accent-rgb),0.3)]' : 'text-text-dim hover:text-text-main'}`}
          >
            <LayoutGrid className="w-4 h-4" />
            Synthetic Indices
          </button>
          <button 
            onClick={() => {
              setMarketType('forex');
              // Optional: auto-switch to a forex symbol if needed
            }}
            className={`px-6 py-2.5 rounded-[6px] text-[11px] font-black uppercase tracking-[2px] transition-all flex items-center gap-2 ${marketType === 'forex' ? 'bg-accent text-bg shadow-[0_0_15px_rgba(var(--accent-rgb),0.3)]' : 'text-text-dim hover:text-text-main'}`}
          >
            <Globe className="w-4 h-4" />
            Forex Markets
          </button>
        </div>

        {/* Market Entry Advisory */}
        <div className="bg-[#111114] border border-border/40 rounded-[4px] p-5 animate-in fade-in slide-in-from-top-4 duration-500 mb-6">
          <div className="flex flex-col xl:flex-row items-start justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className={`p-4 rounded-full bg-opacity-10 ${marketHealth.color.replace('text-', 'bg-')} border border-current flex items-center justify-center ${marketHealth.color}`}>
                <marketHealth.icon className="w-7 h-7" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-[14px] font-bold uppercase tracking-wider text-text-main">
                    Market Health: <span className="text-text-dim ml-1">({symbol.replace('R_', 'VOL ').replace('frx', '')})</span>
                  </h3>
                  <span className={`text-[12px] font-black italic uppercase tracking-tighter ${marketHealth.color}`}>
                    {marketHealth.status}
                  </span>
                </div>
                <p className={`text-[15px] font-semibold leading-tight ${marketHealth.color}`}>
                  {marketHealth.message}
                </p>
                <div className="flex items-center gap-3 mt-3">
                   <div className="flex items-center gap-1.5 px-2 py-1 bg-white/5 rounded-[4px] border border-white/10">
                      <Zap className="w-3.5 h-3.5 text-accent" />
                      <span className="text-[10px] text-text-dim font-bold uppercase">AI Intensity: {marketAnalysis.volatility.toFixed(1)}%</span>
                   </div>
                   <div className="flex items-center gap-1.5 px-2 py-1 bg-white/5 rounded-[4px] border border-white/10">
                      <Activity className="w-3.5 h-3.5 text-profit" />
                      <span className="text-[10px] text-text-dim font-bold uppercase">Trend: {marketAnalysis.forecast.confidence}% CONF</span>
                   </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full xl:w-auto flex-1">
              {[
                { label: 'Trend Follow', score: marketAnalysis.strategies.trend, icon: TrendingUp },
                { label: 'Mean Revert', score: marketAnalysis.strategies.meanReversion, icon: RefreshCcw },
                { label: 'Momentum', score: marketAnalysis.strategies.momentum, icon: Zap },
                { label: 'Parity Bias', score: marketAnalysis.strategies.parity, icon: Target }
              ].map((strat) => (
                <div key={strat.label} className="bg-white/5 p-3 rounded-[4px] border border-white/5 hover:border-white/10 transition-all group">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[9px] font-black uppercase tracking-[1px] text-text-dim group-hover:text-text-main transition-colors">{strat.label}</span>
                    <strat.icon className={`w-3.5 h-3.5 ${strat.score > 70 ? 'text-profit' : strat.score > 40 ? 'text-amber-500' : 'text-loss'}`} />
                  </div>
                  <div className="flex items-baseline justify-between gap-2">
                    <span className={`text-[16px] font-mono font-bold leading-none ${strat.score > 70 ? 'text-profit' : 'text-white'}`}>
                      {strat.score}%
                    </span>
                    <div className="h-1 w-12 bg-white/10 rounded-full overflow-hidden">
                       <div 
                         className={`h-full transition-all duration-1000 ${strat.score > 70 ? 'bg-profit' : strat.score > 40 ? 'bg-amber-500' : 'bg-loss'}`} 
                         style={{ width: `${strat.score}%` }} 
                       />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-4 pl-0 xl:pl-6 border-l-0 xl:border-l border-border/20">
               <div className="text-center">
                  <div className="text-[9px] font-black text-accent uppercase tracking-[2px] mb-1">Global Signal</div>
                  <div className={`text-[24px] font-mono font-black leading-none ${marketAnalysis.aiConfidence > 75 ? 'text-accent shadow-[0_0_15px_rgba(var(--accent-rgb),0.2)]' : 'text-white'}`}>
                    {marketAnalysis.aiConfidence.toFixed(0)}%
                  </div>
                  <div className="text-[10px] font-black text-text-dim uppercase mt-1 tracking-tighter">AI AGGREGATE</div>
               </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[350px_1fr_320px] 2xl:grid-cols-[400px_1fr_380px] gap-[1px] bg-border border border-border">
          
          {/* Panel 1: Config */}
          <div className="bg-[#0D0D0F] p-[30px] flex flex-col">
            <h2 className="text-[10px] uppercase tracking-[2px] text-text-dim font-bold mb-6">Market & Strategy</h2>

            <div className="bg-[#111114] border border-border rounded-[4px] overflow-hidden mb-4">
              <CollapsibleSection title="AI Market Scanner" icon={LayoutGrid} defaultOpen={true}>
                <div className="space-y-4">
                  <div className="bg-accent/5 p-3 rounded-[4px] border border-accent/20">
                    <p className="text-[10px] text-accent font-bold uppercase tracking-widest mb-2 flex items-center gap-2">
                       <Zap className="w-3 h-3" /> Auto-Switch Scanner
                    </p>
                    <p className="text-[10px] text-text-dim leading-relaxed">
                      The bot is monitoring <span className="text-white font-bold">{activePairs.length}</span> markets. It will automatically switch focus to the pair with the highest trade confidence when idle.
                    </p>
                  </div>
                  
                  <div>
                    <label className="block text-[10px] text-text-dim mb-2 uppercase font-bold tracking-widest">Active Scanner Pairs</label>
                    <div className="flex flex-wrap gap-2">
                      {activePairs.map(p => (
                        <div key={p} className={`flex items-center gap-2 pl-3 pr-2 py-1.5 rounded-[4px] border transition-all ${symbol === p ? 'bg-accent/10 border-accent shadow-[0_0_10px_rgba(var(--accent-rgb),0.2)]' : 'bg-transparent border-border hover:border-white/20'}`}>
                          <button 
                            onClick={() => setSymbol(p)}
                            className={`text-[11px] font-mono font-bold ${symbol === p ? 'text-accent' : 'text-text-dim'}`}
                          >
                            {p.replace('R_', 'VOL ').replace('frx', '')}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CollapsibleSection>
            </div>
            
            <div className="bg-[#111114] border border-border rounded-[4px] overflow-hidden">
              <CollapsibleSection title="Core Strategy" icon={Target} defaultOpen={true}>
                <div>
                  <label className="block text-[12px] text-text-dim mb-2 uppercase tracking-wide">Target Logic</label>
                  <div className="flex flex-wrap gap-2">
                    {[
                      'Even/Odd', 'Even', 'Odd', 'Alternate', 'Smart O/U', 'Flow Market', 'Python Logic', 'Python Bias O/U', 'Sniper Switch', 'Python Fast E/O', 'Python Safe E/O', 'Python Ultimate E/O', 'Momentum Rise/Fall', 'Reversal Rise/Fall', 'Forex Scalper Pro'
                    ].map(s => (
                      <button
                        key={s}
                        disabled={isBotRunning}
                        onClick={() => setStrategy(s as any)}
                        className={`py-2 px-3 flex-1 min-w-[30%] text-[11px] font-semibold uppercase rounded-[4px] border transition-colors ${
                          strategy === s 
                            ? 'bg-accent border-accent text-bg' 
                            : 'bg-transparent border-border text-text-dim hover:bg-card-bg'
                        } disabled:opacity-50`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="mt-6 bg-[#1A1A1D] p-3 rounded-[4px] border border-orange-500/20">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Zap className="w-3 h-3 text-orange-400" />
                      <span className="text-[11px] text-text-main font-bold uppercase tracking-tight">1-Min Turbo Sprint</span>
                    </div>
                    <button
                      onClick={() => {
                        setTurboSprintMode(!turboSprintMode);
                        stateRef.current.turboSprintMode = !turboSprintMode;
                      }}
                      disabled={isBotRunning}
                      className={`relative w-8 h-4 rounded-full transition-colors ${turboSprintMode ? 'bg-orange-500' : 'bg-border'}`}
                    >
                      <span className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white transition-transform ${turboSprintMode ? 'translate-x-4' : ''}`} />
                    </button>
                  </div>
                  <p className="text-[10px] text-text-dim mt-1.5 leading-relaxed">
                    <span className="text-orange-400 font-bold uppercase">Turbo Mode:</span> Minimal signal filtering + Maximum frequency. Targets profit reach in &lt; 60s windows.
                  </p>
                </div>

                {strategy === 'Python Ultimate E/O' && (
                  <div className="space-y-2">
                    <div className="bg-[#1A1A1D] p-3 rounded-[4px] border border-accent/20 animate-in zoom-in-95">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Zap className="w-3 h-3 text-accent" />
                          <span className="text-[11px] text-text-main font-bold uppercase tracking-tight">Even Precision Mode</span>
                        </div>
                        <button
                          onClick={() => setPythonUltimateEvenOnly(!pythonUltimateEvenOnly)}
                          disabled={isBotRunning}
                          className={`relative w-8 h-4 rounded-full transition-colors ${pythonUltimateEvenOnly ? 'bg-accent' : 'bg-border'}`}
                        >
                          <span className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white transition-transform ${pythonUltimateEvenOnly ? 'translate-x-4' : ''}`} />
                        </button>
                      </div>
                      <p className="text-[10px] text-text-dim mt-1.5 leading-relaxed">
                        Detects and executes ONLY on EVEN trends. Mid-air execution priority.
                      </p>
                    </div>

                    <div className="bg-[#1A1A1D] p-3 rounded-[4px] border border-purple-500/20 animate-in zoom-in-95">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Target className="w-3 h-3 text-purple-400" />
                          <span className="text-[11px] text-text-main font-bold uppercase tracking-tight">Compound Mode (Paroli)</span>
                        </div>
                        <button
                          onClick={() => {
                            setPythonUltimateCompoundMode(!pythonUltimateCompoundMode);
                            stateRef.current.pythonUltimateCompoundMode = !pythonUltimateCompoundMode;
                          }}
                          disabled={isBotRunning}
                          className={`relative w-8 h-4 rounded-full transition-colors ${pythonUltimateCompoundMode ? 'bg-purple-500' : 'bg-border'}`}
                        >
                          <span className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white transition-transform ${pythonUltimateCompoundMode ? 'translate-x-4' : ''}`} />
                        </button>
                      </div>
                      <p className="text-[10px] text-text-dim mt-1.5 leading-relaxed">
                        <span className="text-purple-400 font-bold uppercase">Paroli Strategy:</span> Double after WIN, reset after LOSS. Ideal for aggressive profit sprints with low exposure.
                      </p>
                    </div>
                  </div>
                )}

                {(strategy === 'Smart O/U' || strategy === 'Python Bias O/U' || strategy === 'Python Logic') && (
                  <div className="animate-in fade-in slide-in-from-top-2">
                    <label className="block text-[12px] text-text-dim mb-2 uppercase tracking-wide">Prediction Barrier (0-9)</label>
                    <input 
                      type="number" 
                      min="0" max="9" step="1"
                      value={targetDigit}
                      onChange={(e) => setTargetDigit(parseInt(e.target.value) || 0)}
                      disabled={isBotRunning}
                      className="w-full bg-card-bg border border-border rounded-[4px] px-3 py-2 font-mono text-[14px] text-accent focus:outline-none focus:border-accent disabled:opacity-50"
                    />
                  </div>
                )}

                {strategy === 'Python Logic' && (
                  <div className="animate-in fade-in slide-in-from-top-2">
                    <label className="block text-[12px] text-text-dim mb-2 uppercase tracking-wide">Target Type</label>
                    <div className="flex gap-2">
                      {['DIGITOVER', 'DIGITUNDER'].map(t => (
                        <button
                          key={t}
                          disabled={isBotRunning}
                          onClick={() => setPythonTradeType(t as any)}
                          className={`py-2 px-3 flex-1 text-[11px] font-semibold uppercase rounded-[4px] border transition-colors ${
                            pythonTradeType === t 
                              ? 'bg-accent border-accent text-bg' 
                              : 'bg-transparent border-border text-text-dim hover:bg-card-bg'
                          } disabled:opacity-50`}
                        >
                          {t.replace('DIGIT', '')}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-[12px] text-text-dim uppercase tracking-wide" title="Enables stake increases after losses">Martingale Recovery</label>
                      <button
                        onClick={() => setMartingaleEnabled(!martingaleEnabled)}
                        disabled={isBotRunning}
                        className={`relative w-8 h-4 rounded-full transition-colors ${martingaleEnabled ? 'bg-accent' : 'bg-border'}`}
                      >
                        <span className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white transition-transform ${martingaleEnabled ? 'translate-x-4' : ''}`} />
                      </button>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[12px] text-text-dim mb-2 uppercase tracking-wide">Initial Stake ($)</label>
                        <input 
                          type="number" 
                          min="0.35" step="0.5"
                          value={initialStake}
                          onChange={(e) => setInitialStake(parseFloat(e.target.value) || 1)}
                          disabled={isBotRunning}
                          className="w-full bg-card-bg border border-border rounded-[4px] px-3 py-2 font-mono text-[14px] text-accent focus:outline-none focus:border-accent disabled:opacity-50"
                        />
                      </div>
                      <div>
                        <label className={`block text-[12px] text-text-dim mb-2 uppercase tracking-wide ${!martingaleEnabled ? 'opacity-30' : ''}`} title="Doubles stake after a loss to recover">Multiplier x</label>
                        <input 
                          type="number" 
                          min="1" step="0.1"
                          value={martingaleMultiplier}
                          onChange={(e) => setMartingaleMultiplier(parseFloat(e.target.value) || 2)}
                          disabled={isBotRunning || !martingaleEnabled}
                          className="w-full bg-card-bg border border-border rounded-[4px] px-3 py-2 font-mono text-[14px] text-accent focus:outline-none focus:border-accent disabled:opacity-50"
                        />
                      </div>
                    </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                       <label className="text-[12px] text-text-dim uppercase tracking-wide">Signal Intensity</label>
                       <span className="text-[11px] font-mono font-bold text-accent">{signalIntensity}%</span>
                    </div>
                    <input 
                      type="range"
                      min="20"
                      max="95"
                      value={signalIntensity}
                      onChange={(e) => setSignalIntensity(parseInt(e.target.value))}
                      disabled={isBotRunning}
                      className="w-full accent-accent h-1 bg-border rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between mt-1">
                       <span className="text-[9px] text-text-dim uppercase">Fast Capture</span>
                       <span className="text-[9px] text-text-dim uppercase">High Precision</span>
                    </div>
                  </div>
                </div>
              </CollapsibleSection>

              <CollapsibleSection title="Risk Management" icon={Shield}>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-[12px] text-text-dim uppercase tracking-wide flex items-center gap-2">
                         Take Profit ($)
                      </label>
                      <div className="flex gap-1">
                        {[1, 5, 10, 25].map(v => (
                          <button
                            key={v}
                            disabled={isBotRunning}
                            onClick={() => setTakeProfit(v)}
                            className={`px-1.5 py-0.5 rounded text-[8px] font-bold border transition-all ${takeProfit === v ? 'bg-profit border-profit text-bg' : 'border-border text-text-dim hover:border-profit/50'} disabled:opacity-50`}
                          >
                            ${v}
                          </button>
                        ))}
                      </div>
                      <button
                        onClick={() => setTakeProfitEnabled(!takeProfitEnabled)}
                        disabled={isBotRunning}
                        className={`relative w-8 h-4 rounded-full transition-colors ${takeProfitEnabled ? 'bg-success' : 'bg-border'}`}
                      >
                        <span className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white transition-transform ${takeProfitEnabled ? 'translate-x-4' : ''}`} />
                      </button>
                    </div>
                    {takeProfitEnabled && (
                    <div className="space-y-2">
                      <input 
                        type="number" 
                        min="0" step="1"
                        value={takeProfit}
                        onChange={(e) => setTakeProfit(parseFloat(e.target.value) || 0)}
                        disabled={isBotRunning}
                        className="w-full bg-card-bg border border-border rounded-[4px] px-3 py-2 font-mono text-[14px] text-profit focus:outline-none focus:border-profit/50 disabled:opacity-50"
                      />
                    </div>
                    )}
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-[12px] text-text-dim uppercase tracking-wide">Stop Loss ($)</label>
                      <button
                        onClick={() => setStopLossEnabled(!stopLossEnabled)}
                        disabled={isBotRunning}
                        className={`relative w-8 h-4 rounded-full transition-colors ${stopLossEnabled ? 'bg-loss' : 'bg-border'}`}
                      >
                        <span className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white transition-transform ${stopLossEnabled ? 'translate-x-4' : ''}`} />
                      </button>
                    </div>
                    {stopLossEnabled && (
                      <input 
                        type="number" 
                        min="0" step="1"
                        value={stopLoss}
                        onChange={(e) => setStopLoss(parseFloat(e.target.value) || 0)}
                        disabled={isBotRunning}
                        className="w-full bg-card-bg border border-border rounded-[4px] px-3 py-2 font-mono text-[14px] text-loss focus:outline-none focus:border-loss/50 disabled:opacity-50"
                      />
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-[12px] text-text-dim uppercase tracking-wide">Trailing Stop</label>
                      <button onClick={() => setTrailingStopEnabled(!trailingStopEnabled)} disabled={isBotRunning} className={`relative w-8 h-4 rounded-full transition-colors ${trailingStopEnabled ? 'bg-loss' : 'bg-border'}`}><span className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white transition-transform ${trailingStopEnabled ? 'translate-x-4' : ''}`} /></button>
                    </div>
                    {trailingStopEnabled && (
                       <input type="number" min="0" step="1" value={trailingStopDistance} onChange={e => setTrailingStopDistance(parseFloat(e.target.value)||0)} disabled={isBotRunning} className="w-full bg-card-bg border border-border rounded-[4px] px-3 py-2 font-mono text-[14px] text-loss focus:outline-none focus:border-loss/50 disabled:opacity-50" placeholder="Distance ($)" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-[12px] text-text-dim uppercase tracking-wide">Max Drawdown</label>
                      <button onClick={() => setMaxDrawdownEnabled(!maxDrawdownEnabled)} disabled={isBotRunning} className={`relative w-8 h-4 rounded-full transition-colors ${maxDrawdownEnabled ? 'bg-loss' : 'bg-border'}`}><span className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white transition-transform ${maxDrawdownEnabled ? 'translate-x-4' : ''}`} /></button>
                    </div>
                    {maxDrawdownEnabled && (
                       <input type="number" min="0" step="1" value={maxDrawdownLimit} onChange={e => setMaxDrawdownLimit(parseFloat(e.target.value)||0)} disabled={isBotRunning} className="w-full bg-card-bg border border-border rounded-[4px] px-3 py-2 font-mono text-[14px] text-loss focus:outline-none focus:border-loss/50 disabled:opacity-50" placeholder="Peak Drop ($)" />
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-[12px] text-text-dim uppercase tracking-wide">Max Stake ($)</label>
                      <button onClick={() => setMaxStakeEnabled(!maxStakeEnabled)} disabled={isBotRunning} className={`relative w-8 h-4 rounded-full transition-colors ${maxStakeEnabled ? 'bg-loss' : 'bg-border'}`}><span className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white transition-transform ${maxStakeEnabled ? 'translate-x-4' : ''}`} /></button>
                    </div>
                    {maxStakeEnabled && (
                       <input type="number" min="0" step="1" value={maxStake} onChange={e => setMaxStake(parseFloat(e.target.value)||0)} disabled={isBotRunning} className="w-full bg-card-bg border border-border rounded-[4px] px-3 py-2 font-mono text-[14px] text-loss focus:outline-none focus:border-loss/50 disabled:opacity-50" placeholder="Max ($)" />
                    )}
                  </div>
                  <div>
                    <label className="block text-[12px] text-text-dim mb-2 uppercase tracking-wide">Max trades</label>
                    <input 
                      type="number" 
                      min="0" step="1"
                      value={maxTrades}
                      onChange={(e) => setMaxTrades(parseInt(e.target.value) || 0)}
                      disabled={isBotRunning}
                      className="w-full bg-card-bg border border-border rounded-[4px] px-3 py-2 font-mono text-[14px] text-[#FF9F0A] focus:outline-none focus:border-[#FF9F0A]/50 disabled:opacity-50"
                    />
                  </div>
                </div>

                <div className="mt-4">
                  <label className="block text-[12px] text-text-dim mb-2 uppercase tracking-wide">Trade Pace</label>
                  <div className="flex gap-1">
                    {(['safe', 'balanced', 'aggressive'] as const).map(p => (
                      <button
                        key={p}
                        onClick={() => setTradePace(p)}
                        disabled={isBotRunning}
                        className={`flex-1 py-1 text-[10px] uppercase font-bold rounded-[4px] border transition-colors ${
                          tradePace === p 
                            ? 'bg-accent border-accent text-bg' 
                            : 'bg-transparent border-border text-text-dim hover:bg-card-bg'
                        } disabled:opacity-50`}
                        title={p === 'safe' ? '5s delay' : p === 'balanced' ? '2s delay' : '0.5s delay'}
                      >
                        {p.slice(0, 4)}
                      </button>
                    ))}
                  </div>
                </div>
              </CollapsibleSection>

              <CollapsibleSection title="Auto-Restart Settings" icon={RotateCcw}>
                <div className="space-y-4">
                  <div className="bg-[#1A1A1D] p-3 rounded-[4px] border border-border/30">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <RotateCcw className={`w-4 h-4 ${autoRestartEnabled ? 'text-success animate-spin-slow' : 'text-text-dim'}`} />
                        <span className="text-[12px] text-text-main font-bold uppercase tracking-tight">Enable Auto-Restart</span>
                      </div>
                      <button
                        onClick={() => setAutoRestartEnabled(!autoRestartEnabled)}
                        disabled={isBotRunning}
                        className={`relative w-10 h-5 rounded-full transition-colors ${autoRestartEnabled ? 'bg-success' : 'bg-border'}`}
                        title="Toggle Auto-Restart"
                      >
                        <span className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white transition-transform ${autoRestartEnabled ? 'translate-x-5' : ''}`} />
                      </button>
                    </div>
                    
                    <p className="text-[11px] text-text-dim leading-relaxed mb-4">
                      This feature allows the bot to automatically resume trading after a stop condition (such as Take Profit, Stop Loss, or Max Trades) has been met.
                    </p>

                    <div className="space-y-1.5">
                      <label className="block text-[10px] text-text-dim uppercase tracking-widest font-semibold text-accent">Auto-Restart Delay (Seconds)</label>
                      <div className="flex items-center gap-3">
                        <input 
                          type="number"
                          min="1"
                          step="1"
                          max="3600"
                          value={autoRestartDelay}
                          onChange={(e) => setAutoRestartDelay(parseInt(e.target.value) || 1)}
                          disabled={isBotRunning}
                          className="flex-1 bg-card-bg border border-border rounded-[4px] px-3 py-2 font-mono text-[14px] text-success focus:outline-none focus:border-success/50 disabled:opacity-50"
                          placeholder="Delay in seconds"
                        />
                        <span className="text-[12px] text-text-dim font-mono">SEC</span>
                      </div>
                      <p className="text-[9px] text-text-dim/60 mt-1">
                        The bot will wait for this duration before starting a new session automatically.
                      </p>
                    </div>
                  </div>

                  <div className="px-1">
                    <div className="flex items-start gap-2">
                      <Info className="w-3.5 h-3.5 text-accent shrink-0 mt-0.5" />
                      <p className="text-[10px] text-text-dim italic leading-snug">
                        Note: Auto-restart will reset session statistics (profit, trades, streaks) to ensure a fresh cycle execution.
                      </p>
                    </div>
                  </div>
                </div>
              </CollapsibleSection>

              <CollapsibleSection title="Ghost Mode" icon={Ghost}>
                <div className="flex items-center justify-between mb-3 border-b border-white/[0.05] pb-3 bg-success/5 p-2 rounded-[4px] border border-success/20">
                  <div>
                      <label className="text-[12px] text-success uppercase tracking-wide font-bold block">✨ AI God Mode (Always Win)</label>
                      <span className="text-[10px] text-text-dim">Forces a 100% win-rate for simulated, virtual, and backtest trades.</span>
                  </div>
                  <button onClick={() => setAiGodMode(!aiGodMode)} disabled={isBotRunning} className={`relative w-8 h-4 rounded-full transition-colors ${aiGodMode ? 'bg-success' : 'bg-border'}`}><span className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white transition-transform ${aiGodMode ? 'translate-x-4' : ''}`} /></button>
                </div>

                <div className="flex items-center justify-between mb-3 border-b border-white/[0.05] pb-3">
                  <div>
                      <label className="text-[12px] text-[#FF9F0A] uppercase tracking-wide font-semibold block">Ghost Auto-Deploy</label>
                      <span className="text-[10px] text-text-dim">Simulate until target wins, then go real.</span>
                  </div>
                  <button onClick={() => setStartInVirtualMode(!startInVirtualMode)} disabled={isBotRunning} className={`relative w-8 h-4 rounded-full transition-colors ${startInVirtualMode ? 'bg-[#FF9F0A]' : 'bg-border'}`}><span className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white transition-transform ${startInVirtualMode ? 'translate-x-4' : ''}`} /></button>
                </div>

                <div className="flex items-center justify-between mb-3 border-b border-white/[0.05] pb-3">
                  <div>
                      <label className="text-[12px] text-[#FF9F0A] uppercase tracking-wide font-semibold block">Continuous Looper</label>
                      <span className="text-[10px] text-text-dim">Re-enter Ghost Mode after every real trade.</span>
                  </div>
                  <button onClick={() => setLoopVirtualMode(!loopVirtualMode)} disabled={isBotRunning} className={`relative w-8 h-4 rounded-full transition-colors ${loopVirtualMode ? 'bg-[#FF9F0A]' : 'bg-border'}`}><span className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white transition-transform ${loopVirtualMode ? 'translate-x-4' : ''}`} /></button>
                </div>

                <div className="flex items-center justify-between mb-2">
                  <label className="text-[12px] text-[#FF9F0A] uppercase tracking-wide font-semibold">Virtual Loss Jump</label>
                  <button onClick={() => setVirtualLossJumpEnabled(!virtualLossJumpEnabled)} disabled={isBotRunning} className={`relative w-8 h-4 rounded-full transition-colors ${virtualLossJumpEnabled ? 'bg-[#FF9F0A]' : 'bg-border'}`}><span className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white transition-transform ${virtualLossJumpEnabled ? 'translate-x-4' : ''}`} /></button>
                </div>

                {(virtualLossJumpEnabled || startInVirtualMode || loopVirtualMode) && (
                    <div className="flex flex-col gap-3 mt-4 bg-black/20 p-3 rounded-[4px] border border-white/[0.05]">
                        {virtualLossJumpEnabled && (
                          <div className="flex items-center justify-between">
                              <span className="text-[11px] text-text-dim">Jump after loss:</span>
                              <input type="number" min="1" step="1" value={pauseAfterLosses} onChange={e => setPauseAfterLosses(parseInt(e.target.value)||1)} disabled={isBotRunning} className="w-12 bg-card-bg border border-border rounded-[4px] px-1 py-1 font-mono text-[12px] text-[#FF9F0A] text-center" />
                          </div>
                        )}
                        <div className="flex items-center justify-between">
                            <span className="text-[11px] text-text-dim">Wins to switch:</span>
                            <input type="number" min="1" step="1" value={virtualWinsTarget} onChange={e => setVirtualWinsTarget(parseInt(e.target.value)||1)} disabled={isBotRunning} className="w-12 bg-card-bg border border-border rounded-[4px] px-1 py-1 font-mono text-[12px] text-[#FF9F0A] text-center" />
                        </div>
                    </div>
                )}
              </CollapsibleSection>

              <CollapsibleSection title="Advanced Execution" icon={Zap}>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[12px] text-text-dim mb-2 uppercase tracking-wide">Max Retries</label>
                    <input 
                      type="number" 
                      min="0" step="1"
                      value={maxRetries}
                      onChange={(e) => setMaxRetries(parseInt(e.target.value) || 0)}
                      disabled={isBotRunning}
                      className="w-full bg-card-bg border border-border rounded-[4px] px-3 py-2 font-mono text-[14px] text-accent focus:outline-none focus:border-accent disabled:opacity-50"
                    />
                  </div>
                  <div>
                    <label className="block text-[12px] text-text-dim mb-2 uppercase tracking-wide">Execution Delay (ms)</label>
                    <input 
                      type="number" 
                      min="0" step="50"
                      value={executionDelay}
                      onChange={(e) => setExecutionDelay(parseInt(e.target.value) || 0)}
                      disabled={isBotRunning}
                      className="w-full bg-card-bg border border-border rounded-[4px] px-3 py-2 font-mono text-[14px] text-accent focus:outline-none focus:border-accent disabled:opacity-50"
                    />
                  </div>
                </div>
                <div className="text-[10px] text-text-dim leading-relaxed bg-[#1A1A1D] p-2 rounded-[2px] border border-white/[0.02] mb-1">
                  Delay of 0ms enables "Mid-air" immediate execution on next available tick.
                </div>

                {/* Telegram Notifications Subsection */}
                <div className="border-t border-white/[0.05] mt-4 pt-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Send className="w-4 h-4 text-[#24A1DE] shrink-0" />
                      <div>
                        <span className="text-[12px] text-text-main font-semibold uppercase tracking-wider block">Telegram Push Notifications</span>
                        <span className="text-[10px] text-text-dim">Get real-time updates for trades and balance changes</span>
                      </div>
                    </div>
                    <button 
                      onClick={() => setTelegramEnabled(!telegramEnabled)}
                      className={`relative w-8 h-4 rounded-full transition-colors ${telegramEnabled ? 'bg-[#24A1DE]' : 'bg-border'}`}
                    >
                      <span className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full bg-white transition-transform ${telegramEnabled ? 'translate-x-4' : ''}`} />
                    </button>
                  </div>

                  {telegramEnabled && (
                    <div className="space-y-4 bg-black/25 p-3 rounded-[4px] border border-white/[0.05] animate-fade-in">
                      <div>
                        <label className="block text-[11px] text-text-dim mb-1 uppercase tracking-wide">Telegram Bot Token</label>
                        <input 
                          type="password" 
                          value={telegramBotToken}
                          onChange={(e) => setTelegramBotToken(e.target.value)}
                          className="w-full bg-[#141416] border border-border rounded-[4px] px-3 py-2 font-mono text-[12px] text-accent focus:outline-none focus:border-accent"
                          placeholder="e.g. 123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] text-text-dim mb-1 uppercase tracking-wide">Telegram Chat ID</label>
                          <input 
                            type="text" 
                            value={telegramChatId}
                            onChange={(e) => setTelegramChatId(e.target.value)}
                            className="w-full bg-[#141416] border border-border rounded-[4px] px-3 py-2 font-mono text-[12px] text-accent focus:outline-none focus:border-accent"
                            placeholder="e.g. 987654321"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-text-dim mb-1 uppercase tracking-wide">Min Balance Notify ($)</label>
                          <input 
                            type="number" 
                            min="0.01" step="0.5"
                            value={telegramMinBalanceChange}
                            onChange={(e) => setTelegramMinBalanceChange(Math.max(0.01, parseFloat(e.target.value) || 0))}
                            className="w-full bg-[#141416] border border-border rounded-[4px] px-3 py-2 font-mono text-[12px] text-accent focus:outline-none focus:border-accent"
                            placeholder="e.g. 10.00"
                          />
                        </div>
                      </div>

                      <div className="flex gap-2 pt-1">
                        <button
                          type="button"
                          onClick={sendTestTelegramMessage}
                          disabled={telegramStatus === 'sending'}
                          className={`flex-1 flex items-center justify-center gap-1.5 font-bold uppercase tracking-wider text-[10px] py-2 rounded-[2px] transition-all border ${
                            telegramStatus === 'success' 
                              ? 'bg-success/20 border-success text-success' 
                              : telegramStatus === 'error'
                              ? 'bg-loss/20 border-loss text-loss'
                              : 'bg-[#24A1DE] hover:bg-[#2092c9] text-white border-transparent'
                          }`}
                        >
                          <Send className="w-3 h-3" />
                          {telegramStatus === 'sending' ? 'Sending...' : telegramStatus === 'success' ? 'Test Sent Successfully!' : 'Send Test Notification'}
                        </button>
                      </div>

                      {telegramError && (
                        <p className="text-[10px] text-loss leading-snug mt-1 italic">
                          ⚠️ Error: {telegramError}
                        </p>
                      )}

                      <div className="bg-[#1A1A1D] p-2 rounded-[2px] border border-white/[0.02]">
                        <p className="text-[9px] text-text-dim leading-normal">
                          💡 <b>Setup Tutorial:</b> (1) Message <a href="https://t.me/BotFather" target="_blank" rel="noopener noreferrer" className="text-accent underline">@BotFather</a> to create a bot & get the <i>Token</i>. (2) Message your newly created bot, then search <a href="https://t.me/userinfobot" target="_blank" rel="noopener noreferrer" className="text-accent underline font-mono">@userinfobot</a> to find your numeric <i>Chat ID</i>. (3) Trigger tests above!
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CollapsibleSection>

              <div className="pt-4 mt-2">
                <div className="text-[12px] text-text-dim mb-1 uppercase tracking-wide">Current Target Stake</div>
                <div className="text-[28px] font-mono text-accent leading-none">${currentStake.toFixed(2)}</div>
              </div>

              <div className="flex flex-col gap-2 mt-6">
                <button
                  onClick={toggleBot}
                  disabled={(!isConnected && !isBotRunning) || isBacktesting}
                  className={`h-[60px] w-full font-semibold tracking-[1px] uppercase transition-colors border ${
                    ((!isConnected && !isBotRunning) || isBacktesting)
                      ? 'bg-[#1A1A1D] border-border text-text-dim cursor-not-allowed'
                      : isBotRunning
                        ? 'bg-accent border-accent text-bg'
                        : 'bg-[#1A1A1D] border-accent text-accent hover:bg-accent hover:text-bg'
                  }`}
                >
                  {isBotRunning ? 'Stop Auto-Trader' : 'Start Auto-Trader'}
                </button>
                
                <button
                  onClick={() => setShowBacktestModal(true)}
                  disabled={isBotRunning || isBacktesting}
                  className={`h-[40px] w-full text-[11px] font-semibold tracking-[1px] uppercase transition-colors border ${
                    (isBotRunning || isBacktesting)
                      ? 'bg-[#1A1A1D] border-border text-text-dim cursor-not-allowed'
                      : 'bg-transparent border-border text-text-dim hover:text-accent hover:border-accent'
                  }`}
                >
                  Launch Backtester
                </button>

                <button
                  onClick={() => setShowMultiBacktestModal(true)}
                  disabled={isBotRunning || isBacktesting}
                  className={`h-[40px] w-full text-[11px] font-semibold tracking-[1px] uppercase transition-colors border flex items-center justify-center gap-2 ${
                    (isBotRunning || isBacktesting)
                      ? 'bg-[#1A1A1D] border-border text-text-dim cursor-not-allowed'
                      : 'bg-accent/5 border-accent/20 text-accent hover:bg-accent/10 hover:border-accent'
                  }`}
                >
                  <BarChart3 className="w-3.5 h-3.5" />
                  Strategy Comparison
                </button>

                <button
                  onClick={() => setShowHistoryModal(true)}
                  className="h-[40px] w-full text-[11px] font-semibold tracking-[1px] uppercase transition-colors border flex items-center justify-center gap-2 bg-white/5 border-white/10 text-text-main hover:bg-white/10 hover:border-white/20"
                >
                  <History className="w-3.5 h-3.5" />
                  Trade Ledger
                </button>
              </div>
            </div>

            {/* Panel 2: Chart & Market */}
          <div className="bg-bg p-[30px] flex flex-col min-h-[300px]">
            <h2 className="text-[10px] uppercase tracking-[2px] text-text-dim font-bold mb-[24px]">Market Intelligence</h2>
            
            <div className="flex justify-between items-start mb-6">
              <div>
                <div className="font-mono text-[42px] tracking-[-2px] leading-none mb-[10px] text-accent">
                  {ticks.length > 0 ? ticks[ticks.length - 1].quote.toFixed(4) : '---'}
                </div>
                <div className="text-[12px] text-text-dim uppercase tracking-widest font-bold">
                  {symbol === 'R_10' ? 'Volatility 10 Index' :
                   symbol === 'R_25' ? 'Volatility 25 Index' :
                   symbol === 'R_50' ? 'Volatility 50 Index' :
                   symbol === 'R_75' ? 'Volatility 75 Index' :
                   symbol === 'R_100' ? 'Volatility 100 Index' :
                   symbol === '1HZ10V' ? 'Volatility 10 (1s) Index' :
                   symbol === '1HZ25V' ? 'Volatility 25 (1s) Index' :
                   symbol === '1HZ50V' ? 'Volatility 50 (1s) Index' :
                   symbol === '1HZ75V' ? 'Volatility 75 (1s) Index' :
                   symbol === '1HZ100V' ? 'Volatility 100 (1s) Index' :
                   symbol}
                </div>
              </div>
              <div className="flex gap-6 text-right">
                <div className="flex flex-col items-end">
                  <div className="text-[10px] uppercase text-text-dim tracking-widest font-bold mb-1">Market Volatility</div>
                  <div className="text-[18px] font-mono text-text-main mb-1">{marketAnalysis.volatility}%</div>
                  <div className="w-[100px] h-1 bg-muted rounded-full overflow-hidden">
                    <div className="h-full transition-all duration-300 bg-[#FF9F0A]" style={{ width: `${marketAnalysis.volatility}%` }} />
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <div className="text-[10px] uppercase text-text-dim tracking-widest font-bold mb-1">Win Probability</div>
                  <div className="text-[18px] font-mono text-profit mb-1">{adjustedStrength}%</div>
                  <div className="w-[100px] h-1 bg-muted rounded-full overflow-hidden">
                    <div className="h-full transition-all duration-300 bg-profit" style={{ width: `${adjustedStrength}%` }} />
                  </div>
                </div>
                <div className="flex flex-col items-end border-l border-border pl-6">
                  <div className="text-[10px] uppercase text-text-dim tracking-widest font-bold mb-1">Target Strategy</div>
                  <div className="flex items-center gap-2">
                    <select 
                      value={strategy}
                      onChange={(e) => setStrategy(e.target.value as any)}
                      disabled={isBotRunning}
                      className="bg-transparent border-none text-[18px] font-mono text-accent text-right outline-none cursor-pointer appearance-none min-w-[120px] pb-1"
                    >
                      {[
                        'Even', 'Odd', 'Even/Odd', 'Alternate', 'Smart O/U', 
                        'Flow Market', 'Python Logic', 'Python Bias O/U', 
                        'Sniper Switch', 'Python Fast E/O', 'Python Safe E/O', 
                        'Python Ultimate E/O', 'Momentum Rise/Fall', 'Reversal Rise/Fall', 'Forex Scalper Pro',
                        'Digit Diff', 'Digit Match'
                      ].map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                    <button 
                      onClick={() => setShowBotCodeModal(true)}
                      className="p-1 text-accent hover:bg-accent/10 rounded transition-colors"
                      title="View Bot Code"
                    >
                      <Terminal className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="text-[9px] text-text-dim mt-1 uppercase tracking-widest">Rec: {marketAnalysis.bestBot}</div>
                </div>
              </div>
            </div>

            {/* TECHNICAL INDICATORS */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="bg-[#111114] border border-border p-3 flex flex-col justify-between">
                <div className="text-[10px] uppercase text-text-dim tracking-widest font-bold mb-2">RSI (14)</div>
                <div className={`text-[20px] font-mono leading-none ${marketAnalysis.rsi > 70 ? 'text-[#ff6b6b]' : marketAnalysis.rsi < 30 ? 'text-[#00ff88]' : 'text-text-main'}`}>
                  {marketAnalysis.rsi.toFixed(2)}
                </div>
                <div className="text-[9px] text-text-dim uppercase tracking-wider mt-2">
                  {marketAnalysis.rsi > 70 ? 'Overbought' : marketAnalysis.rsi < 30 ? 'Oversold' : 'Neutral'}
                </div>
              </div>
              <div className="bg-[#111114] border border-border p-3 flex flex-col justify-between">
                <div className="text-[10px] uppercase text-text-dim tracking-widest font-bold mb-2">SMA (20)</div>
                <div className="text-[20px] font-mono text-text-main leading-none">
                  {marketAnalysis.sma.toFixed(4)}
                </div>
                <div className="text-[9px] text-text-dim uppercase tracking-wider mt-2">
                  Trend Baseline
                </div>
              </div>
              <div className="bg-[#111114] border border-border p-3 flex flex-col justify-between">
                <div className="text-[10px] uppercase text-text-dim tracking-widest font-bold mb-2">MACD (12,26,9)</div>
                <div className={`text-[20px] font-mono leading-none ${marketAnalysis.macd.hist > 0 ? 'text-[#00ff88]' : marketAnalysis.macd.hist < 0 ? 'text-[#ff6b6b]' : 'text-text-main'}`}>
                  {marketAnalysis.macd.macd.toFixed(4)}
                </div>
                <div className={`text-[9px] uppercase tracking-wider mt-2 ${marketAnalysis.macd.hist > 0 ? 'text-[#00ff88]/70' : 'text-[#ff6b6b]/70'}`}>
                  {marketAnalysis.macd.hist > 0 ? 'Bullish Histogram' : 'Bearish Histogram'}
                </div>
              </div>
            </div>

            {/* STRATEGY MONITOR & RISK TRACKER */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className={`transition-all duration-300 p-4 rounded-[4px] border ${
                isTrading 
                  ? 'bg-accent/10 border-accent animate-pulse shadow-[0_0_15px_rgba(var(--color-accent-rgb),0.2)]' 
                  : 'bg-card-bg border-border shadow-none'
              }`}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Zap className={`w-3 h-3 ${isTrading ? 'text-accent' : 'text-text-dim'}`} />
                    <div className="text-[10px] uppercase text-text-dim tracking-wide font-bold">
                      {isTrading ? 'EXECUTION IN PROGRESS' : 'Strategy Signal Indicator'}
                    </div>
                  </div>
                  <div className={`w-2.5 h-2.5 rounded-full ${
                    isTrading ? 'bg-accent animate-ping' :
                    signalStatus.status === 'success' ? 'bg-profit' : 
                    signalStatus.status === 'warning' ? 'bg-[#FF9F0A]' : 'bg-text-dim'
                  }`} />
                </div>
                <div className={`text-[14px] font-mono mb-3 ${isTrading ? 'text-accent font-bold' : 'text-text-main'}`}>
                  {isTrading ? 'HUB: ANALYZING CONTRACT SETTLEMENT...' : signalStatus.message}
                </div>
                <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-500 ${
                        isTrading ? 'bg-accent shadow-[0_0_10px_#64D2FF]' :
                        signalStatus.status === 'success' ? 'bg-profit' : 
                        signalStatus.status === 'warning' ? 'bg-[#FF9F0A]' : 'bg-accent'
                    }`}
                    style={{ width: isTrading ? '100%' : `${signalStatus.progress}%` }} 
                  />
                </div>
                {isTrading && (
                  <div className="mt-2 text-[10px] font-mono text-accent text-right flex items-center justify-end gap-1">
                    <span className="w-1 h-1 bg-accent rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                    <span className="w-1 h-1 bg-accent rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                    <span className="w-1 h-1 bg-accent rounded-full animate-bounce"></span>
                    SYNCING REAL-TIME MARKET DATA
                  </div>
                )}
              </div>

              <div className="bg-card-bg p-4 rounded-[4px] border border-border">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-[10px] uppercase text-text-dim tracking-wide font-bold">Session Target Tracker (Stop)</div>
                  <div className="text-[10px] font-mono text-text-dim">
                    {sessionProfit >= 0 ? `${((sessionProfit / (takeProfit || 1)) * 100).toFixed(0)}% to TP` : `${((Math.abs(sessionProfit) / (stopLoss || 1)) * 100).toFixed(0)}% to SL`}
                  </div>
                </div>
                <div className="flex justify-between items-end mb-1">
                  <div className="text-[12px] font-mono text-loss">-${stopLoss} SL</div>
                  <div className={`text-[16px] font-mono ${sessionProfit >= 0 ? 'text-profit' : 'text-loss'}`}>
                    ${sessionProfit.toFixed(2)}
                  </div>
                  <div className="text-[12px] font-mono text-profit">+${takeProfit} TP</div>
                </div>
                <div className="relative h-1.5 w-full bg-muted rounded-full overflow-hidden">
                   {/* Center divider */}
                  <div className="absolute left-1/2 top-0 bottom-0 w-px bg-white/20 z-10" />
                  
                  {/* SL Progress (Red, growing left) */}
                  {sessionProfit < 0 && (
                    <div 
                      className="absolute right-1/2 top-0 bottom-0 bg-loss transition-all duration-500" 
                      style={{ width: `${Math.min((Math.abs(sessionProfit) / (stopLoss || 1)) * 50, 50)}%` }} 
                    />
                  )}

                  {/* TP Progress (Green, growing right) */}
                  {sessionProfit >= 0 && (
                    <div 
                      className="absolute left-1/2 top-0 bottom-0 bg-profit transition-all duration-500" 
                      style={{ width: `${Math.min((sessionProfit / (takeProfit || 1)) * 50, 50)}%` }} 
                    />
                  )}
                </div>
              </div>
            </div>

            {/* PREDICTION ENGINE DASHBOARD */}
            <div className="flex gap-4 mt-2 mb-4 bg-card-bg p-3 rounded-[4px] border border-border shrink-0">
              <div className="flex-1">
                 <div className="text-[10px] uppercase text-text-dim mb-1">Momentum</div>
                 <div className={`font-mono text-[14px] ${predictionObj?.trend === 'UP' ? 'text-profit' : predictionObj?.trend === 'DOWN' ? 'text-loss' : 'text-text-main'}`}>
                   {predictionObj?.trend || '...'}
                 </div>
              </div>
              <div className="flex-1 border-l border-[rgba(255,255,255,0.05)] pl-4">
                 <div className="text-[10px] uppercase text-text-dim mb-1" title="Algorithmically Predicted Next Digit">Next Algo Digit</div>
                 <div className="font-mono text-[14px] text-accent">
                   {predictionObj ? predictionObj.digit : '-'}
                 </div>
              </div>
              <div className="flex-1 border-l border-[rgba(255,255,255,0.05)] pl-4">
                 <div className="text-[10px] uppercase text-text-dim mb-1">Live Signal</div>
                 <div className={`font-mono text-[14px] whitespace-nowrap ${predictionObj?.trend === 'UP' ? 'text-profit' : predictionObj?.trend === 'DOWN' ? 'text-loss' : 'text-text-main'}`}>
                   {strategy === 'Smart O/U' ? (predictionObj?.signal || 'WAIT') : 'INACTIVE'}
                 </div>
              </div>
            </div>

            <div className="flex-1 w-full mt-2 h-[220px] min-h-[220px] relative rounded-[4px] overflow-hidden">
               {/* Trade Execution Portal Overlay */}
               <AnimatePresence>
                 {isTrading && (
                   <motion.div 
                     initial={{ opacity: 0 }}
                     animate={{ opacity: 1 }}
                     exit={{ opacity: 0 }}
                     className="absolute inset-0 z-20 bg-accent/5 backdrop-blur-[1px] flex items-center justify-center pointer-events-none"
                   >
                     <div className="bg-bg/90 border border-accent/30 px-6 py-4 rounded-[4px] flex flex-col items-center gap-2 shadow-[0_0_30px_rgba(var(--color-accent-rgb),0.2)]">
                        <div className="flex items-center gap-3">
                           <div className="relative">
                              <div className="w-8 h-8 rounded-full border-2 border-accent/20"></div>
                              <div className="absolute inset-0 w-8 h-8 rounded-full border-t-2 border-accent animate-spin"></div>
                           </div>
                           <span className="text-accent font-mono text-[14px] font-bold tracking-widest uppercase animate-pulse">Position Active</span>
                        </div>
                        <div className="text-[10px] text-text-dim uppercase tracking-wider">Syncing with Exchange...</div>
                     </div>
                   </motion.div>
                 )}
               </AnimatePresence>

               {isMounted && ticks.length > 0 ? (
                 <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                  <LineChart data={ticks} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" vertical={false} />
                    <XAxis dataKey="time" hide />
                    <YAxis domain={['auto', 'auto']} hide />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'var(--color-card-bg)', border: '1px solid var(--color-border)', borderRadius: '4px' }}
                      itemStyle={{ color: 'var(--color-accent)', fontFamily: 'var(--font-mono)' }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="quote" 
                      stroke="var(--color-accent)" 
                      strokeWidth={2}
                      dot={false}
                      animationDuration={300}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-text-dim border border-border border-dashed">
                  <p className="text-[12px] uppercase tracking-[1px]">{isMounted ? 'Waiting for connection' : 'Synchronizing...'}</p>
                </div>
              )}
            </div>

            <div className="mt-6 bg-[#0D0D0F] border border-border rounded-[4px] p-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-[10px] uppercase tracking-[2px] text-text-dim font-bold">Order Depth & Liquidity</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-profit animate-pulse" />
                    <span className="text-[9px] text-text-dim uppercase tracking-wider">Simulated Market Pressure (Intensity: {marketAnalysis.volatility.toFixed(1)}%)</span>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="text-right">
                    <div className="text-[9px] uppercase text-profit tracking-tighter">Bids (Buy)</div>
                    <div className="text-[12px] font-mono font-bold text-profit">SYNCED</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[9px] uppercase text-loss tracking-tighter">Asks (Sell)</div>
                    <div className="text-[12px] font-mono font-bold text-loss">SYNCED</div>
                  </div>
                </div>
              </div>
              <MarketDepthChart 
                currentPrice={ticks.length > 0 ? ticks[ticks.length - 1].quote : 0} 
                intensity={marketAnalysis.volatility} 
              />
              <div className="mt-2 flex justify-between text-[9px] text-text-dim font-mono uppercase tracking-widest border-t border-white/[0.05] pt-2">
                <span>Lower Price Range</span>
                <span>Market Price Equilibrium</span>
                <span>Higher Price Range</span>
              </div>
            </div>

            <div className="mt-6">
              <div className="text-[10px] uppercase tracking-[2px] text-text-dim font-bold mb-3">Live Digit Tape</div>
              <div className="flex gap-1 overflow-x-hidden">
                {ticks.slice(-12).map((t, i) => {
                  const isEven = t.lastDigit % 2 === 0;
                  return (
                    <div 
                      key={t.epoch + i} 
                      className={`flex-1 flex items-center justify-center h-[32px] bg-card-bg border border-border font-mono text-[14px] ${isEven ? 'text-[#64D2FF]' : 'text-[#FF9F0A]'}`}
                    >
                      {t.lastDigit}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Panel 3: Session Analytics & Logs */}
          <div className="bg-bg flex flex-col h-full border-l border-border">
            <div className="p-4 lg:p-[30px] border-b border-border bg-[#0a0a0c]">
              <div className="flex items-center justify-between mb-[24px]">
                <h2 className="text-[10px] uppercase tracking-[2px] text-text-dim font-bold">Realtime Performance</h2>
                <button 
                  onClick={handleResetRequest}
                  className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-text-dim hover:text-accent transition-colors border border-[rgba(255,255,255,0.05)] bg-[#141417] px-2 py-1 rounded-[2px]"
                  title="Reset Metrics"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset</span>
                </button>
              </div>
              
              <div className="mb-6 flex justify-between items-end">
                <div>
                  <div className="text-[10px] text-text-dim mb-1 uppercase tracking-wide">Session Net Return</div>
                  <div className={`text-[32px] font-mono leading-none ${sessionProfit >= 0 ? 'text-profit' : 'text-loss'}`}>
                    {sessionProfit >= 0 ? '+' : ''}{sessionProfit.toFixed(2)}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="bg-[#141417] p-3 rounded-[4px] border border-[rgba(255,255,255,0.02)]">
                  <div className="text-[10px] text-text-dim mb-1 uppercase tracking-wide">Pips / Trades</div>
                  <div className="text-[15px] font-mono">
                    <span className="text-profit">{isBacktesting ? backtestResults.wins : sessionStats.wins}W</span>
                    <span className="text-text-dim mx-1">/</span>
                    <span className="text-loss">{isBacktesting ? backtestResults.losses : sessionStats.losses}L</span>
                  </div>
                </div>
                
                <div className="bg-[#141417] p-3 rounded-[4px] border border-[rgba(255,255,255,0.02)]">
                  <div className="text-[10px] text-text-dim mb-1 uppercase tracking-wide">Win Rate</div>
                  <div className={`text-[15px] font-mono ${(isBacktesting ? backtestResults.trades : sessionStats.totalTrades) > 0 && ((isBacktesting ? backtestResults.wins : sessionStats.wins) / (isBacktesting ? backtestResults.trades : sessionStats.totalTrades)) >= 0.5 ? 'text-profit' : 'text-text-main'}`}>
                    {(isBacktesting ? backtestResults.trades : sessionStats.totalTrades) > 0 
                      ? Math.round(((isBacktesting ? backtestResults.wins : sessionStats.wins) / (isBacktesting ? backtestResults.trades : sessionStats.totalTrades)) * 100) + '%' 
                      : '--%'}
                  </div>
                </div>

                {(strategy === 'Python Ultimate E/O' || strategy === 'Even/Odd') && (
                  <>
                    <div className="bg-[#141417] p-3 rounded-[4px] border border-[rgba(0,255,136,0.1)]">
                      <div className="text-[10px] text-[#00ff88] mb-1 uppercase tracking-wide font-bold">Even Wins</div>
                      <div className="text-[15px] font-mono text-[#00ff88]">{isBacktesting ? backtestResults.evenWins : sessionStats.evenWins}</div>
                    </div>
                    <div className="bg-[#141417] p-3 rounded-[4px] border border-[rgba(255,107,107,0.1)]">
                      <div className="text-[10px] text-[#ff6b6b] mb-1 uppercase tracking-wide font-bold">Odd Wins</div>
                      <div className="text-[15px] font-mono text-[#ff6b6b]">{isBacktesting ? backtestResults.oddWins : sessionStats.oddWins}</div>
                    </div>
                  </>
                )}

                <div className="bg-[#141417] p-3 rounded-[4px] border border-[rgba(255,255,255,0.02)]">
                  <div className="text-[10px] text-text-dim mb-1 uppercase tracking-wide">Simulator Status</div>
                  <div className={`text-[11px] font-mono uppercase tracking-[2px] mt-1 ${isBacktesting ? 'text-[#FF9F0A] animate-pulse' : 'text-text-dim'}`}>
                    {isBacktesting ? 'Engine Running' : 'Idle'}
                  </div>
                </div>

                <div className="bg-[#141417] p-3 rounded-[4px] border border-[rgba(255,255,255,0.02)]">
                  <div className="text-[10px] text-text-dim mb-1 uppercase tracking-wide" title={`Max: ${isBacktesting ? backtestResults.maxWinStreak : sessionStats.maxWinStreak}W / ${isBacktesting ? backtestResults.maxLossStreak : sessionStats.maxLossStreak}L`}>Streak Length</div>
                  <div className={`text-[15px] font-mono ${(isBacktesting ? backtestResults.streak : sessionStats.currentStreak) > 0 ? 'text-profit bg-[rgba(0,230,118,0.1)] inline-block px-2 rounded-sm' : (isBacktesting ? backtestResults.streak : sessionStats.currentStreak) < 0 ? 'text-loss bg-[rgba(255,82,82,0.1)] inline-block px-2 rounded-sm' : 'text-text-dim'}`}>
                    {(isBacktesting ? backtestResults.streak : sessionStats.currentStreak) > 0 ? `${isBacktesting ? backtestResults.streak : sessionStats.currentStreak} WINS` : (isBacktesting ? backtestResults.streak : sessionStats.currentStreak) < 0 ? `${Math.abs(isBacktesting ? backtestResults.streak : sessionStats.currentStreak)} LOSSES` : '-'}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="px-4 lg:px-[30px] flex-none border-b border-border py-4">
              <h2 className="text-[10px] uppercase tracking-[2px] text-text-dim font-bold mb-[12px]">Profit Velocity</h2>
              <div className="w-full h-[120px] relative">
                {isMounted && (
                  <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                    <AreaChart data={profitTrend} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={sessionProfit >= 0 ? '#00ff41' : '#ff0044'} stopOpacity={0.2}/>
                          <stop offset="95%" stopColor={sessionProfit >= 0 ? '#00ff41' : '#ff0044'} stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <XAxis dataKey="trade" hide />
                      <YAxis domain={['auto', 'auto']} hide />
                      <Area 
                        type="step" 
                        dataKey="profit" 
                        stroke={sessionProfit >= 0 ? '#00ff41' : '#ff0044'} 
                        strokeWidth={1.5}
                        fillOpacity={1}
                        fill="url(#colorProfit)"
                        animationDuration={300}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                )}
              </div>
            </div>

            <div className="px-4 pt-4 lg:px-[30px] lg:pt-[4px] flex-1 flex flex-col pb-4 min-h-0 mt-4">
              <div className="flex items-center justify-between mb-[12px]">
                <h2 className="text-[10px] uppercase tracking-[2px] text-text-dim font-bold">Activity Pulse</h2>
                <div className="text-[9px] text-accent/50 animate-pulse font-mono flex items-center gap-1">
                  <div className="w-1 h-1 bg-accent rounded-full"/>
                  ENCRYPTED STREAM
                </div>
              </div>
              
              <div className="flex-1 w-full bg-black/40 border border-border rounded-[4px] overflow-hidden flex flex-col min-h-0">
                <div className="flex-1 overflow-y-auto custom-scrollbar p-2 font-mono text-[11px] space-y-1.5" id="log-container">
                  {logs.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-text-dim/30 italic">
                      Waiting for engine signals...
                    </div>
                  ) : (
                    logs.map(log => (
                      <div key={log.id} className="animate-in fade-in slide-in-from-left-2 duration-300">
                        <div className="flex gap-3">
                          <span className="text-text-dim shrink-0">[{log.timestamp}]</span>
                          <span className={`
                            ${log.severity === 'success' ? 'text-profit' : 
                              log.severity === 'error' || log.severity === 'critical' ? 'text-loss' : 
                              log.severity === 'warning' ? 'text-[#FF9F0A]' : 
                              log.severity === 'trade-loss' ? 'text-loss opacity-80' : 'text-text-main'}
                          `}>
                            {log.message}
                          </span>
                        </div>
                        {log.advice && (
                          <div className="ml-16 mt-0.5 text-[10px] text-text-dim leading-tight italic border-l border-white/5 pl-2">
                             &gt; {log.advice}
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      </main>

      {/* Custom styles for scrollbar */}
      <style dangerouslySetInnerHTML={{__html: `
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
          height: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.08);
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.15);
        }
      `}} />

      {/* Confirmation Modal */}
      <MultiStrategyBacktestModal 
        isOpen={showMultiBacktestModal}
        onClose={() => setShowMultiBacktestModal(false)}
        initialStake={initialStake}
        martingaleMultiplier={martingaleMultiplier}
        symbol={symbol}
      />
      <TradeHistoryModal 
        isOpen={showHistoryModal}
        onClose={() => setShowHistoryModal(false)}
        trades={trades}
        currency={stateRef.current.currency || '$'}
      />
      {(showStartConfirm || showResetConfirm || showBacktestModal || showDiagnosticModal) && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className={`bg-[#141417] border border-border shadow-2xl rounded-[4px] w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200 ${showDiagnosticModal ? 'max-w-xl' : 'max-w-md'}`}>
            {showStartConfirm ? (
              <div className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <AlertCircle className="w-6 h-6 text-accent" />
                  <h3 className="text-[16px] font-bold text-text-main uppercase tracking-wide">Confirm Execution</h3>
                </div>
                <p className="text-[13px] text-text-dim mb-6 leading-relaxed">
                  Are you sure you want to enable the Auto-Trader? The system will immediately begin analyzing the market and executing trades using your balance according to the configured strategy.
                </p>
                <div className="flex items-center justify-end gap-3">
                  <button 
                    onClick={() => setShowStartConfirm(false)}
                    className="px-4 py-2 text-[12px] font-semibold uppercase tracking-wide border border-border bg-transparent text-text-dim hover:bg-card-bg transition-colors rounded-[4px]"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={confirmStartBot}
                    className="px-4 py-2 text-[12px] font-semibold uppercase tracking-wide border border-accent bg-accent text-bg hover:bg-[#a68962] transition-colors rounded-[4px]"
                  >
                    Confirm & Start
                  </button>
                </div>
              </div>
            ) : showResetConfirm ? (
              <div className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <RotateCcw className="w-6 h-6 text-loss" />
                  <h3 className="text-[16px] font-bold text-text-main uppercase tracking-wide">Reset Session Analytics</h3>
                </div>
                <p className="text-[13px] text-text-dim mb-6 leading-relaxed">
                  Are you sure you want to reset all current session tracking metrics? This will zero out your win rate statistics and session returns.
                </p>
                <div className="flex items-center justify-end gap-3">
                  <button 
                    onClick={() => setShowResetConfirm(false)}
                    className="px-4 py-2 text-[12px] font-semibold uppercase tracking-wide border border-border bg-transparent text-text-dim hover:bg-card-bg transition-colors rounded-[4px]"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={confirmResetSession}
                    className="px-4 py-2 text-[12px] font-semibold uppercase tracking-wide border border-loss bg-[rgba(255,82,82,0.1)] text-loss hover:bg-loss hover:text-bg transition-colors rounded-[4px]"
                  >
                    Reset Metrics
                  </button>
                </div>
              </div>
            ) : showBacktestModal ? (
              <div className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Activity className="w-6 h-6 text-accent" />
                  <h3 className="text-[16px] font-bold text-text-main uppercase tracking-wide">Engine Backtester</h3>
                </div>
                <p className="text-[13px] text-text-dim mb-6 leading-relaxed">
                  Run a rapid simulation over 1,500 historical ticks using your exact current configuration parameters.
                  This process runs synchronously and may take a moment to compute standard payout metrics.
                </p>
                <div className="flex items-center justify-end gap-3">
                  <button 
                    onClick={() => setShowBacktestModal(false)}
                    className="px-4 py-2 text-[12px] font-semibold uppercase tracking-wide border border-border bg-transparent text-text-dim hover:bg-card-bg transition-colors rounded-[4px]"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={startBacktestDemo}
                    className="px-4 py-2 text-[12px] font-semibold uppercase tracking-wide border border-accent bg-accent text-bg hover:bg-[#a68962] transition-colors rounded-[4px]"
                  >
                    Run Simulation
                  </button>
                </div>
              </div>
            ) : showDiagnosticModal ? (
              <div className="p-6 flex flex-col h-[85vh] max-h-[640px]">
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-white/[0.05]">
                  <div className="flex items-center gap-3">
                    <Activity className={`w-5 h-5 ${isDiagnosticRunning ? 'text-[#FF9F0A] animate-pulse' : 'text-accent'}`} />
                    <div>
                      <h3 className="text-[15px] font-bold text-text-main uppercase tracking-wide">Network Diagnostic Audit</h3>
                      <p className="text-[10px] text-text-dim uppercase tracking-wider">Gateway status check & probe telemetry</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowDiagnosticModal(false)}
                    className="text-text-dim hover:text-text-main transition-colors text-[18px] font-mono select-none"
                    title="Close"
                  >
                    &times;
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto custom-scrollbar pr-1 space-y-4">
                  <p className="text-[11px] text-text-dim leading-relaxed">
                    This audit analyzes standard web request lifecycles and launches isolated Secure Sockets (WSS) to Deriv's primary routing nodes to test reachability, latency, and detect country-level ISP blocks or firewalls.
                  </p>

                  <div className="space-y-2.5">
                    {diagnosticSteps.map((step, idx) => (
                      <div 
                        key={idx} 
                        className="bg-black/20 border border-white/[0.03] p-2.5 rounded-[4px] space-y-1.5 transition-all text-[11px]"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            {step.status === 'success' ? (
                              <CheckCircle className="w-3.5 h-3.5 text-profit shrink-0" />
                            ) : step.status === 'failed' ? (
                              <XCircle className="w-3.5 h-3.5 text-loss shrink-0" />
                            ) : step.status === 'running' ? (
                              <span className="w-2 h-2 rounded-full bg-accent animate-ping shrink-0 m-0.5" />
                            ) : (
                              <span className="w-2 h-2 rounded-full bg-text-dim/30 shrink-0 m-0.5" />
                            )}
                            <span className="text-text-main font-semibold">{step.name}</span>
                          </div>
                          
                          <span className={`font-mono text-[10px] uppercase font-bold tracking-tight ${
                            step.status === 'success' ? 'text-profit' : 
                            step.status === 'failed' ? 'text-loss' : 
                            step.status === 'running' ? 'text-[#FF9F0A] animate-pulse' : 'text-text-dim/40'
                          }`}>
                            {step.status === 'running' ? 'PROBING...' : step.result || 'PENDING'}
                          </span>
                        </div>

                        {step.details && (
                          <div className="text-[10px] text-text-dim/75 bg-black/30 p-2 border border-white/[0.03] rounded font-mono leading-relaxed break-words overflow-x-auto custom-scrollbar">
                            {step.details}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  {diagnosticSummary && (
                    <div className={`p-3.5 rounded-[4px] border border-dashed text-[11px] leading-relaxed transition-all ${
                      diagnosticSummary.startsWith('🟢') ? 'bg-profit/5 border-profit/20 text-text-main' :
                      diagnosticSummary.startsWith('🟡') ? 'bg-accent/5 border-accent/20 text-text-main' :
                      'bg-loss/5 border-loss/20 text-text-main'
                    }`}>
                      <span className="font-bold uppercase block mb-1 tracking-wider text-[10px]">Diagnostics Verdict</span>
                      {diagnosticSummary}
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-end gap-3 mt-4 pt-3 border-t border-white/[0.05]">
                  <button 
                    onClick={() => setShowDiagnosticModal(false)}
                    className="px-4 py-2 text-[11px] font-bold uppercase tracking-wider border border-border bg-transparent text-text-dim hover:bg-card-bg transition-colors rounded-[4px]"
                  >
                    Close
                  </button>
                  <button 
                    onClick={runDiagnostics}
                    disabled={isDiagnosticRunning}
                    className="px-4 py-2 text-[11px] font-bold uppercase tracking-wider border border-accent bg-accent text-bg hover:bg-accent/90 transition-with-all disabled:opacity-50 flex items-center gap-1.5 rounded-[4px]"
                  >
                    {isDiagnosticRunning ? (
                      <>
                        <span className="w-2.5 h-2.5 rounded-full border border-bg border-t-transparent animate-spin inline-block" />
                        Auditing...
                      </>
                    ) : (
                      'Run Diagnostics'
                    )}
                  </button>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* Lil Assistant Bot */}
      <div className={`fixed bottom-4 right-4 z-50 flex flex-col items-end pointer-events-none`}>
        {/* Chat Window */}
        <div className={`pointer-events-auto transition-all duration-300 origin-bottom-right ${isLilOpen ? 'opacity-100 scale-100 mb-4' : 'opacity-0 scale-95 pointer-events-none absolute bottom-16'}`}>
          <div className="bg-card-bg border border-accent/30 w-[350px] shadow-[0_0_20px_rgba(0,255,65,0.1)] rounded overflow-hidden flex flex-col h-[450px]">
             {/* Header */}
             <div className="bg-bg border-b border-border p-3 flex justify-between items-center bg-black/40">
               <div className="flex items-center gap-2">
                 <div className="w-2 h-2 rounded-full bg-accent animate-pulse"/>
                 <span className="font-mono text-accent text-[12px] uppercase font-bold tracking-widest">Lil Assistant</span>
               </div>
               <button onClick={() => setIsLilOpen(false)} className="text-text-dim hover:text-loss transition-colors">
                 <XCircle className="w-4 h-4" />
               </button>
             </div>
             {/* Chat History */}
             <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
               {lilMessages.map((msg, idx) => (
                 <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                   <div className={`max-w-[85%] p-3 rounded text-[12px] font-mono leading-relaxed ${msg.role === 'user' ? 'bg-accent/10 border border-accent/20 text-accent' : 'bg-black/30 border border-border text-text-main'}`}>
                      {msg.content}
                   </div>
                 </div>
               ))}
               {isLilTyping && (
                 <div className="flex justify-start">
                   <div className="bg-black/30 border border-border text-text-main p-3 rounded text-[12px] font-mono flex gap-1 items-center">
                     <span className="w-1.5 h-1.5 bg-accent rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                     <span className="w-1.5 h-1.5 bg-accent rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                     <span className="w-1.5 h-1.5 bg-accent rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                   </div>
                 </div>
               )}
             </div>
             {/* Input Area */}
             <div className="p-3 border-t border-border bg-black/40 flex gap-2">
               <input
                 type="text"
                 value={lilInput}
                 onChange={(e) => setLilInput(e.target.value)}
                 onKeyDown={(e) => e.key === 'Enter' && handleSendLilMessage()}
                 placeholder="Ask Lil anything..."
                 className="flex-1 bg-black/50 border border-border rounded px-3 py-2 text-[12px] font-mono text-text-main focus:outline-none focus:border-accent placeholder:text-text-dim/50"
               />
               <button
                 onClick={handleSendLilMessage}
                 disabled={isLilTyping || !lilInput.trim()}
                 className="bg-accent/10 text-accent border border-accent/30 rounded px-3 flex items-center justify-center hover:bg-accent/20 disabled:opacity-50"
               >
                 <ChevronRight className="w-4 h-4" />
               </button>
             </div>
          </div>
        </div>

        {/* Floating Button */}
        <button
          onClick={() => setIsLilOpen(!isLilOpen)}
          className={`pointer-events-auto bg-bg border border-accent/40 w-12 h-12 rounded-full flex items-center justify-center text-accent hover:bg-accent hover:text-bg transition-all shadow-[0_0_15px_rgba(0,255,65,0.2)] ${isLilOpen ? 'rotate-180 scale-90' : ''}`}
        >
          {isLilOpen ? <XCircle className="w-5 h-5" /> : <Activity className="w-5 h-5" />}
        </button>
      </div>

      <BotCodeModal
        isOpen={showBotCodeModal}
        onClose={() => setShowBotCodeModal(false)}
        strategy={strategy}
      />

    <footer className="mt-auto py-6 px-4 md:px-6 lg:px-8 border-t border-border bg-[#141417] relative z-10 shrink-0">
      <div className="w-full flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-accent" />
            <span className="text-[14px] font-logo text-accent uppercase tracking-wider">Jimna.Hub AutoTrade Compliance</span>
          </div>
          <p className="text-[10px] text-text-dim max-w-2xl leading-relaxed">
            <strong>Legal Warning:</strong> Trading entails significant risk. This analytical interface is for educational purposes. Jimna.Hub facilitates official Deriv API communication but does not guarantee profits. Automated trading should only be performed after thorough testing and with capital you can afford to lose.
          </p>
        </div>
        <div className="flex flex-wrap gap-4 text-[10px] text-text-dim uppercase tracking-wider font-bold">
          <div className="flex items-center gap-2 text-accent bg-accent/5 px-3 py-1 rounded border border-accent/20">
            <Activity className="w-3 h-3" />
            <span>Status: {currentStatus}</span>
          </div>
          <span className="hover:text-accent transition-colors cursor-pointer">Official API</span>
          <span className="hover:text-accent transition-colors cursor-pointer">Terms</span>
          <span className="text-accent/50">© 2026 Jimna.Hub</span>
        </div>
      </div>
    </footer>
    </>
    )}
    </div>
  );
}

