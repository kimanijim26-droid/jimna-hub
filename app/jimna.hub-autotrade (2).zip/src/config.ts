export const KENYA_CONFIG = {
  appId: "33ySFYbvralU62iTFqFXL",
  accountId: "CR12345",
  apiToken: "your_api_token",
  endpoint: "wss://frontend.binaryws.com/websockets/v3",
  useOTPConnection: false,
  maxRetries: 5,
  retryDelay: 2000,
  enableEvenOdd: true,
  enableRiseFall: true,
  stake: 10
};
