import express from "express";
import path from "path";
import OpenAI from "openai";
import dotenv from "dotenv";
import { WebSocketServer, WebSocket as NodeWS } from "ws";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // REST Proxy for Deriv API (to bypass CORS/Origin blocks)
  app.all(/^\/api\/deriv-rest-proxy\/(.*)/, async (req, res) => {
    const prefix = "/api/deriv-rest-proxy/";
    const pathArg = req.params[0] || (req.path.startsWith(prefix) ? req.path.substring(prefix.length) : "");
    const appId = (req.query.app_id || req.headers['deriv-app-id'] || "33ySFYbvralU62iTFqFXL") as string;
    
    console.log(`[REST Proxy] Request: ${req.method} ${pathArg} (AppID: ${appId})`);
    
    // Construct the target URL - strip internal proxy params from forwarded query
    const targetSearchParams = new URLSearchParams(req.query as any);
    targetSearchParams.delete('origin'); // Don't send proxy-only param to Deriv
    targetSearchParams.delete('app_id'); // We send this in headers
    const queryString = targetSearchParams.toString();
    const targetUrl = `https://api.derivws.com/${pathArg}${queryString ? '?' + queryString : ''}`;
    
    console.log(`[REST Proxy] Forwarding to: ${targetUrl}`);
    
    let originHeader = (req.query.origin as string) || "";
    
    // If no explicit origin provided in query, try to get it from headers
    if (!originHeader) {
      if (req.headers.origin) {
        originHeader = req.headers.origin as string;
      } else if (req.headers.referer) {
        try {
          const refUrl = new URL(req.headers.referer);
          originHeader = refUrl.origin;
        } catch (e) {}
      }
    }
    
    const host = req.headers.host || 'localhost:3000';
    if (!originHeader) {
      const protocol = req.headers['x-forwarded-proto'] || ((req.socket as any)?.encrypted ? 'https' : 'http');
      originHeader = `${protocol}://${host}`;
    }

    const officialAppIds = ["1085", "1089", "36544", "1170", "1168", "19111", "33778"];
    
    // Respect explicit origin query param if provided
    const explicitOrigin = req.query.origin as string;
    
    if (officialAppIds.includes(appId)) {
      // For official IDs, we must often spoof the origin to match where they are registered (usually deriv.app)
      // especially when running on random preview domains like run.app
      originHeader = "https://deriv.app";
      console.log(`[REST Proxy] Official App ID ${appId} - Forcing Origin: ${originHeader}`);
    } else if (explicitOrigin) {
      originHeader = explicitOrigin;
      console.log(`[REST Proxy] Using explicit origin from query: ${originHeader}`);
    } else {
      // For custom IDs, we use the actual origin/host to avoid breaking their manual registration
      console.log(`[REST Proxy] Custom App ID ${appId} - Using Native Origin: ${originHeader}`);
    }

    // Safe user-agent fallbacks to avoid blocking by CDN/WAF layers
    const rawUserAgent = req.headers["user-agent"] || "";
    const userAgent = rawUserAgent && !rawUserAgent.toLowerCase().includes("node") && !rawUserAgent.toLowerCase().includes("fetch")
      ? rawUserAgent
      : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36";

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Origin': originHeader,
      'User-Agent': userAgent
    };

    if (req.headers['authorization']) {
      headers['Authorization'] = req.headers['authorization'] as string;
    } else if (req.query.token) {
      // Fallback: Support token in query param for some clients
      headers['Authorization'] = `Bearer ${req.query.token}`;
    }
    if (appId) {
      headers['Deriv-App-ID'] = appId;
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000); // 20s internal timeout

    try {
      const response = await fetch(targetUrl, {
        method: req.method,
        headers,
        body: ['POST', 'PUT', 'PATCH'].includes(req.method) ? JSON.stringify(req.body) : undefined,
        signal: controller.signal as any
      });
      clearTimeout(timeout);

      const responseText = await response.text();
      console.log(`[REST Proxy] Response from Deriv (${response.status}): ${responseText.substring(0, 500)}`);
      
      let data;
      try {
        data = JSON.parse(responseText);
      } catch (e) {
        // If parsing fails, create a structured error response
        console.error(`[REST Proxy] JSON Parse Failure. Status ${response.status}. Body preview: ${responseText.substring(0, 100)}`);
        
        if (response.status === 401 || response.status === 403 || response.status === 404 || response.status === 503) {
           const bodyPreview = responseText.substring(0, 200).replace(/<[^>]*>/g, '').trim();
           data = { 
             error: {
               status: response.status,
               code: response.status === 403 ? "Forbidden" : (response.status === 401 ? "InvalidToken" : "ServiceUnavailable"),
               message: response.status === 401 
                 ? `Deriv API rejected the token (401). This usually means the App ID (${appId}) is not registered for origin ${originHeader}, or the token is invalid. Raw error: ${bodyPreview || 'No detail available'}` 
                 : `Deriv API returned ${response.status}. Message: ${bodyPreview || 'No detail available'}`,
               details: `Origin: ${originHeader}, AppID: ${appId}, Response: ${responseText.substring(0, 500)}`
             }
           };
        } else {
           data = { 
             error: "Non-JSON response", 
             status: response.status,
             text: responseText.substring(0, 500) 
           };
        }
      }
      
      res.status(response.status).json(data);
    } catch (error: any) {
      clearTimeout(timeout);
      if (error.name === 'AbortError') {
        console.error(`[REST Proxy] Timeout for ${targetUrl}`);
        return res.status(504).json({ error: "Gateway Timeout", message: "Deriv API took too long to respond via proxy." });
      }
      console.error(`[REST Proxy] Error for ${targetUrl}:`, error);
      res.status(500).json({ error: "REST Proxy failure", message: error.message });
    }
  });

  // AI endpoint using DeepSeek (Server-side proxy to hide API Key)
  app.post("/api/chat", async (req, res) => {
    const { messages } = req.body;
    
    // Log requested headers for debugging/compliance
    const authHeader = req.headers['authorization'];
    const derivAppIdHeader = req.headers['deriv-app-id'];
    console.log(`[API/Chat] Received Auth: ${authHeader ? 'YES' : 'NO'}, App-ID: ${derivAppIdHeader || 'NONE'}`);

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "Messages array is required." });
    }

    const apiKey = process.env.DEEPSEEK_API_KEY;
    if (!apiKey || apiKey.includes('****')) {
      return res.status(401).json({ 
        error: "DeepSeek API key is missing or invalid. Falling back to Gemini..." 
      });
    }

    try {
      const openai = new OpenAI({
        baseURL: "https://api.deepseek.com",
        apiKey,
      });

      const systemPrompt = {
        role: "system",
        content: "You are Lil, a helpful, enthusiastic, and knowledgeable AI assistant bot. You guide users through the Jimna.Hub platform which is an AutoTrader application. Provide friendly, concise, and futuristic-themed responses."
      };

      const completion = await openai.chat.completions.create({
        messages: [systemPrompt, ...messages],
        model: "deepseek-chat",
      });

      res.json({ message: completion.choices[0].message });
    } catch (error: any) {
      console.error("DeepSeek API error:", error);
      
      const status = error.status || 500;
      const message = error.message || "An error occurred while generating a response.";
      
      res.status(status).json({ error: message });
    }
  });

  // API routes FIRST
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Deriv OAuth Callback Route for PKCE Flow
  app.get(["/auth/callback", "/auth/callback/"], (req, res) => {
    const { code, state, error, error_description } = req.query;
    
    if (error) {
      console.error(`[Auth Service] Deriv Authentication Error: ${error} - ${error_description}`);
      return res.send(`
        <html>
          <body style="background-color: #0b0c10; color: #c5c6c7; font-family: sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; margin: 0; text-align: center;">
            <div style="padding: 20px; border: 1px solid #ff4a4a; border-radius: 8px; background-color: #1f2833; max-width: 400px;">
              <h2 style="color: #ff4a4a; margin-top: 0;">Authentication Failed</h2>
              <p>${error_description || error}</p>
              <button onclick="window.close()" style="background-color: #ff4a4a; color: #fff; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: bold; margin-top: 15px;">Close Window</button>
            </div>
          </body>
        </html>
      `);
    }

    // Send the code and state back to the parent iframe and close popup
    res.send(`
      <html>
        <body style="background-color: #0b0c10; color: #c5c6c7; font-family: sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; margin: 0; text-align: center;">
          <div style="padding: 25px; border: 1px solid #00ff41; border-radius: 12px; background-color: #11141a; max-width: 400px; box-shadow: 0 0 20px rgba(0, 255, 65, 0.1);">
            <h2 style="color: #00ff41; margin-top: 0; letter-spacing: 1px;">AUTHENTICATED</h2>
            <p style="font-size: 14px; color: #a8b2c1; line-height: 1.5; margin-bottom: 20px;">Your accounts are linked securely. Connecting Jimna.Hub terminal...</p>
            <div style="margin: 10px 0; border: 2px solid #00ff41; border-top-color: transparent; border-radius: 50%; width: 24px; height: 24px; animation: spin 1s linear infinite; display: inline-block;"></div>
            <style>
              @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
            </style>
          </div>
          <script>
            if (window.opener) {
              window.opener.postMessage({ 
                type: 'DERIV_AUTH_CODE', 
                code: "${code || ''}", 
                state: "${state || ''}" 
              }, '*');
              setTimeout(() => {
                window.close();
              }, 1200);
            } else {
              window.location.href = '/?code=' + encodeURIComponent("${code || ''}") + '&state=' + encodeURIComponent("${state || ''}");
            }
          </script>
        </body>
      </html>
    `);
  });

  // Token exchange route
  app.post("/api/auth/exchange", async (req, res) => {
    const { code, code_verifier, redirect_uri } = req.body;
    const clientId = "33ySFYbvralU62iTFqFXL"; // Our registered client/app id from Deriv
    
    if (!code || !code_verifier || !redirect_uri) {
      return res.status(400).json({ error: "Missing required params: code, code_verifier, redirect_uri" });
    }

    try {
      const params = new URLSearchParams({
        grant_type: "authorization_code",
        client_id: clientId,
        code,
        code_verifier,
        redirect_uri
      });

      console.log(`[Auth Service] Exchanging code via token endpoint...`);

      const response = await fetch("https://auth.deriv.com/oauth2/token", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: params.toString()
      });

      const responseText = await response.text();
      console.log(`[Auth Service] Exchange response (${response.status}) received.`);

      if (!response.ok) {
        return res.status(response.status).json({
          error: "Failed to exchange authorization code for token",
          details: responseText
        });
      }

      const data = JSON.parse(responseText);
      res.json(data);
    } catch (error: any) {
      console.error("[Auth Service] Exchange failure:", error);
      res.status(500).json({ error: "Internal Auth Service failure", message: error.message });
    }
  });

  console.log(`[BOOT] Starting server initialization...`);
  console.log(`[BOOT] NODE_ENV: ${process.env.NODE_ENV}`);

  // Helper for static file serving
  const serveStatic = () => {
    const distPath = path.join(process.cwd(), 'dist');
    console.log(`[BOOT] Serving static files from: ${distPath}`);
    app.use(express.static(distPath));
    app.get(/(.*)/, (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  };

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    try {
      console.log("[BOOT] Attempting to load Vite...");
      const { createServer: createViteServer } = await import("vite");
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: "spa",
      });
      app.use(vite.middlewares);
      console.log("[BOOT] Vite middleware mounted.");
    } catch (e) {
      console.warn("[BOOT] Vite could not be loaded, falling back to static mode:", e);
      serveStatic();
    }
  } else {
    serveStatic();
  }

  app.use((err: any, req: any, res: any, next: any) => {
    console.error("[Global Error Handler]", err);
    res.status(500).json({ error: "Internal Server Error" });
  });

  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`[READY] Server operational at http://0.0.0.0:${PORT}`);
    console.log(`[ENV] NODE_ENV: ${process.env.NODE_ENV || 'development'}`);
  });

  // Setup WebSocket Proxy Server
  const wss = new WebSocketServer({ noServer: true });

  wss.on("error", (err) => {
    console.error("[Proxy] WebSocketServer Error:", err);
  });

  server.on("upgrade", (request, socket, head) => {
    const url = request.url || "";
    if (url.includes("/api/deriv-ws-proxy")) {
      wss.handleUpgrade(request, socket, head, (wsClient) => {
        wss.emit("connection", wsClient, request);
      });
    }
  });

  wss.on("connection", (wsClient, request) => {
    try {
      const requestUrl = new URL(request.url || "", `http://${request.headers.host || "localhost"}`);
      const appId = (requestUrl.searchParams.get("app_id") || "33ySFYbvralU62iTFqFXL").trim();
      const host = requestUrl.searchParams.get("host") || "ws.derivws.com";
      const pathParam = requestUrl.searchParams.get("path") || "/websockets/v3";
      const otp = requestUrl.searchParams.get("otp");
      
      const targetUrl = `wss://${host}${pathParam}?app_id=${appId}${otp ? `&otp=${otp}` : ''}`;
      console.log(`[Proxy] Target: ${targetUrl}`);
      
      let originHeader = requestUrl.searchParams.get("origin") || "";
      
      if (!originHeader) {
          if (request.headers.origin) {
              originHeader = request.headers.origin as string;
          } else if (request.headers.referer) {
              try {
                  const refUrl = new URL(request.headers.referer);
                  originHeader = refUrl.origin;
              } catch (e) {}
          }
      }
      
      const hostHeader = request.headers.host || 'localhost:3000';
      if (!originHeader) {
        const protocol = request.headers['x-forwarded-proto'] || 'https';
        originHeader = `${protocol}://${hostHeader}`;
      }
      
      // Official check
      const officialAppIds = ["1085", "1089", "36544", "1170", "1168", "19111", "33778"];
      
      // Respect explicit origin param if provided
      const explicitOriginWS = requestUrl.searchParams.get("origin");
      
      if (officialAppIds.includes(appId)) {
        // Special origin spoofing for official app IDs to allow them to work on subdomains/previews
        originHeader = "https://deriv.app";
        console.log(`[Proxy] Official App ID ${appId} - Forcing Origin: ${originHeader}`);
      } else if (explicitOriginWS) {
        originHeader = explicitOriginWS;
        console.log(`[Proxy] Using explicit origin from query: ${originHeader}`);
      } else {
        // Custom app IDs should use requested or default origin
        console.log(`[Proxy] Custom App ID ${appId} - Using Native Origin: ${originHeader}`);
      }

      // Safe user-agent fallbacks to avoid blocking by CDN/WAF layers
      const rawUserAgent = request.headers["user-agent"] || "";
      const userAgent = rawUserAgent && !rawUserAgent.toLowerCase().includes("node") && !rawUserAgent.toLowerCase().includes("fetch")
        ? rawUserAgent
        : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36";

      const derivSocket = new NodeWS(targetUrl, {
        origin: originHeader,
        headers: {
          "user-agent": userAgent,
        }
      });
      let isClosed = false;

      const closeAll = (code: number, reason: string) => {
        if (isClosed) return;
        isClosed = true;
        console.log(`[Proxy] Tear-down link tunnel. Reason: ${reason}`);

        try {
          if (wsClient) {
            wsClient.removeAllListeners();
            wsClient.on("error", () => {}); // Catch-all to prevent unhandled 'error' events on client socket
            if (wsClient.readyState === wsClient.OPEN || wsClient.readyState === wsClient.CONNECTING) {
              wsClient.close(code, reason);
            }
          }
        } catch (e) {}

        try {
          if (derivSocket) {
            derivSocket.removeAllListeners();
            derivSocket.on("error", () => {}); // Catch-all to prevent unhandled 'error' events on target proxy socket
            derivSocket.onopen = null;
            derivSocket.onmessage = null;
            derivSocket.onerror = null;
            derivSocket.onclose = null;
            if (derivSocket.readyState === derivSocket.OPEN || derivSocket.readyState === derivSocket.CONNECTING) {
              derivSocket.close();
            }
          }
        } catch (e) {}
      };

      derivSocket.on("open", () => {
        console.log(`[Proxy] Real-time loop connected to Deriv server: ${host}`);
      });

      derivSocket.on("message", (data) => {
        try {
          if (wsClient.readyState === wsClient.OPEN) {
            wsClient.send(data.toString());
          }
        } catch (err) {
          console.error("[Proxy] Client transmit crash:", err);
          closeAll(1011, "Proxy transfer failure");
        }
      });

      derivSocket.on("error", (err: any) => {
        if (isClosed || err?.message?.includes("closed before the connection was established")) {
          return;
        }
        console.error("[Proxy] Outbound node error:", err);
        closeAll(1011, `Server connection socket error: ${err.message}`);
      });

      derivSocket.on("close", (code, reason) => {
        console.log(`[Proxy] Outbound node closed. Code: ${code}, Reason: ${reason}`);
        closeAll(code || 1000, reason.toString() || "Server closed connection");
      });

      wsClient.on("message", (message) => {
        try {
          if (derivSocket && derivSocket.readyState === derivSocket.OPEN) {
            derivSocket.send(message.toString());
          } else {
            const checkAndSend = setInterval(() => {
              if (derivSocket && derivSocket.readyState === derivSocket.OPEN) {
                derivSocket.send(message.toString());
                clearInterval(checkAndSend);
              } else if (!derivSocket || derivSocket.readyState === derivSocket.CLOSED || isClosed) {
                clearInterval(checkAndSend);
              }
            }, 100);
            setTimeout(() => clearInterval(checkAndSend), 5000);
          }
        } catch (err) {
          console.error("[Proxy] Outbound target transmit crash:", err);
          closeAll(1011, "Proxy server to Deriv transmission error");
        }
      });

      wsClient.on("error", (err) => {
        console.error("[Proxy] Inbound client error:", err);
        closeAll(1011, "Internal pipeline error");
      });

      wsClient.on("close", (code, reason) => {
        console.log(`[Proxy] Inbound client closed. Code: ${code}, Reason: ${reason}`);
        closeAll(code || 1000, reason.toString() || "Client aborted");
      });

    } catch (e: any) {
      console.error("[Proxy] Failed initialization:", e);
      try { wsClient.close(1011, "Failed setup proxy pipeline"); } catch (_) {}
    }
  });
}

startServer().catch(err => {
  console.error("CRITICAL: Server failed to start:", err);
  process.exit(1);
});
